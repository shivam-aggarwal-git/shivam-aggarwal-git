from lifeos import create_app

app = create_app()
