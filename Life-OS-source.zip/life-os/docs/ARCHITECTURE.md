# Life OS architecture — implementation contract

## Estimate and release policy
Full requested production release: estimated 12–20 weeks with a small engineering team. This estimate includes domain workflows, independent security review, real-provider tests, performance tests and restore drills. A working source package is not proof of production readiness. REQUIREMENTS.md is the authoritative per-point delivery status; repeated prose in the brief maps to the original 1–106 numbers.

## Functional reference
Independently authored Python; no PHP or Vtiger source is incorporated.
Reference concepts: entity modules, field blocks, sharing access, related lists and configurable filters.
- https://community.vtiger.com/help/vtigercrm/developers/extensions/entity-module.html
- https://community.vtiger.com/help/vtigercrm/developers/vtlib/module-sharing-access.html
- https://community.vtiger.com/help/vtigercrm/developers/vtlib/module-related-list.html
- https://flask.palletsprojects.com/en/stable/web-security/
- https://flask.palletsprojects.com/en/stable/deploying/

## Boundaries
Flask application factory and versioned /api/v1 routes. Browser uses same-origin JSON APIs. SQLAlchemy unit of work owns atomic writes, audit events and integration outbox entries. Authentication, metadata, records, file services, reporting and connectors are separate Python modules. A worker drains the outbox; external calls never run inside a record transaction. Services can later be extracted without changing entity identifiers.

## Data placement
PostgreSQL: users, roles, grants, hashed sessions, recovery codes, modules, module_fields, reusable fields, views, module_relationships, globally identified records, record links, audit events, integration configurations, outbox, reports and file metadata. Metadata and custom structured scalar values use SQL JSON (PostgreSQL JSONB variant). This avoids DDL on every field edit while preserving relational ownership and entity references. Decimal values are canonical strings to avoid floating point rounding. Purpose-built journal tables support balanced ledger posting; generic Finance modules alone do not constitute accounting software.
MongoDB: versioned JSON document payloads only, keyed by record ID and immutable payload ID. SQL stores the pointer, never a duplicate payload. Mongo write precedes SQL commit; failed SQL writes can leave an unreferenced payload for maintenance cleanup. Do not claim distributed atomicity. Files: private filesystem volume; SQL metadata and controlled download endpoint. Production requires malware scanning before downloads.
SQLite: explicit local/test fallback only. Docker defaults to PostgreSQL. Supabase: standard PostgreSQL SQLAlchemy URL with TLS; no service-role key needed. Database connection changes require managed restart/migration; do not expose live database switching in ordinary web administration.

## Metadata and integrity
Module -> fields and views. Global reusable definitions can be attached to modules. Fields have stable internal identifiers, type, scope, order and validated settings. Changes to types or names of existing fields are restricted to avoid silent data loss. Records carry UUID, module FK, owner FK, version and timestamps. Relationship definitions identify both endpoint modules and cardinality. Record links use FKs, unique pair and cardinality slot constraints enforced by SQL, not just UI checks. Delete is restricted for linked records. Optimistic locking rejects stale updates. Permissions are deny-by-default; role grants combine module actions, own/all scope and field access. Field permissions must be applied to serialization, writes, exports and reports. Secrets are encrypted and never included in ordinary reads.

## Security
Argon2id password hashes; opaque bearer/session tokens hashed in SQL; HttpOnly SameSite cookies; CSRF on cookie-authenticated mutations including login; TOTP and single-use hashed recovery codes; MFA challenge enforced before session issuance. Redis-backed login/API rate limiting in production. Fernet encryption keys supplied separately through environment or *_FILE secrets. No defaults for encryption/session keys; production startup rejects insecure configuration. TLS termination at reverse proxy; trusted-host allowlist and explicit proxy trust. Restrictive CSP, nosniff, frame denial and no permissive CORS. ORM bind parameters; bounded validation and regex timeout; formulas use an AST allowlist, never eval. File types are allowlisted and content inspected. Secrets are omitted from audit events, errors and webhooks.

## API contract
/api/v1 versioning; consistent {data,meta} or {error:{code,message}}. Pagination bounded to 100. Authentication through same-origin cookie + CSRF or explicit Bearer token. Record updates require version. Configuration endpoints require administrator privileges. Sensitive operations must be audited. OpenAPI generated from routes with documented schemas and examples; coverage must be checked against routes.

## Integrations
Encrypted credentials separated from public settings. Outbound webhook delivery signs timestamp + exact bytes with HMAC SHA256, carries stable delivery ID and uses retries/backoff. Receivers must deduplicate. Inbound callbacks require signature, timestamp freshness and unique event ID. Network destinations restricted to explicit trusted host allowlist and public HTTPS; redirects disabled. An external egress firewall is required for production DNS-rebinding protection. SMTP uses TLS; Telegram uses official HTTPS Bot API. Tableau consumes permission-filtered CSV exports. Google Sheets and OAuth require provider-specific lifecycle validation before production certification.

## Operations
Versioned Alembic migrations, Gunicorn, PostgreSQL, MongoDB, Redis, worker and reverse proxy in Compose; non-root application container, private service network, mounted data and secrets, health endpoints. Backup SQL, MongoDB, uploads and key material separately; restore into an isolated deployment before upgrading. Audit logs exclude field values by design. Deletion of user accounts disables identity rather than removing audit provenance. No native mobile app is implied by a responsive web UI.
