# Deployment and recovery runbook

This document describes the intended operating procedure. It is not evidence that a production deployment or recovery drill has occurred.

## Production deployment

1. Review REQUIREMENTS.md; complete outstanding functional/security release gates.
2. Generate private configuration. Use mounted secrets or your cloud secret manager for encryption keys and credentials. Supply an explicit trusted-host allowlist and an egress allowlist.
3. Provision a real domain with DNS pointing to the deployment host. Set DOMAIN and TRUSTED_HOSTS; include localhost for container readiness probes.
4. Use `docker compose -f compose.yaml -f compose.production.yaml up -d --build`. The production overlay enables secure cookies, proxy trust, ClamAV and Caddy TLS.
5. Keep the localhost-bound web port protected; expose only Caddy publicly. Never enable ProxyFix for an untrusted/directly exposed upstream.
6. Wait for ClamAV signatures and all healthchecks. Verify a real certificate, HTTP-to-HTTPS redirect, secure cookie flags and Host-header rejection.
7. Replace initial Compose database-owner/root users with least-privilege runtime database accounts. Use a separate migration principal. Default Compose is suitable for local bootstrap, not the final least-privilege production identity design.
8. Restrict outbound traffic through a firewall/proxy. Application hostname/IP checks alone are insufficient protection against DNS rebinding.
9. Pin reviewed container image digests. Run dependency/CVE checks before deployment and upgrades. Python dependencies are locked to the build environment, not independently security-certified.

Supabase uses a normal PostgreSQL connection URL with psycopg. Use provider-recommended direct/session-pooler details and verified TLS certificates. URL-encode credentials. Never disable certificate verification to make a connection work. MongoDB URI must name the default database (for example lifeos); use authenticated TLS outside the isolated local Compose network.

## Backup boundary

A recoverable backup consists of four separately controlled parts:

- PostgreSQL logical backup (or provider snapshot/PITR).
- MongoDB record_documents collection and metadata.
- Private attachment volume.
- Encryption keys and environment configuration, backed up separately with restricted access.

Redis stores rate-limit counters and is not the source of record data. The SQL outbox is part of the PostgreSQL backup.

For consistent local backups, stop web and worker writes before taking SQL, Mongo and file snapshots. Resume only after all components are captured. For an online production strategy use coordinated snapshot boundaries and documented recovery semantics; no distributed transaction spans SQL, MongoDB and the filesystem.

Example SQL backup, run from the project directory:

```bash
mkdir -p backups
docker compose stop web worker
docker compose exec -T postgres pg_dump -U lifeos -Fc lifeos > backups/lifeos.dump
```

Use MongoDB database tools with credentials in a mounted protected config file, not copied into scripts or terminal history. Back up the uploads volume through the deployment platform's volume snapshot facility. Encrypt backup archives and store off-host. Resume services after all backups succeed:

```bash
docker compose start web worker
```

No automatic backup scheduler or backup UI is implemented. Configure one in your deployment environment and test its output.

## Restore drill

Restore into an isolated deployment with no outbound integration delivery:

1. Create fresh volumes and restore SQL to a dedicated empty PostgreSQL database.
2. Restore MongoDB payloads and the attachment volume from the same backup boundary.
3. Restore encryption keys separately. Without them, secrets and TOTP seeds cannot be decrypted.
4. Disable external integration delivery before starting workers. Restore may reintroduce pending events; receivers must deduplicate delivery IDs.
5. Run migrations to the intended version and inspect readiness.
6. Verify login and MFA recovery, record counts, references, a sample encrypted secret internally, JSON document reads, attachment hashes and journal totals.
7. Record actual recovery duration and data loss; set RTO/RPO from measured results.

There is no supported production downgrade workflow yet. Prefer a tested forward migration or a complete pre-upgrade backup restore. Do not run destructive Alembic downgrade casually.

## Upgrades and key rotation

Back up before upgrades, stop writes, apply migrations using the migration service, seed idempotently, restart services and run smoke checks. Review all migration SQL on PostgreSQL before applying.

ENCRYPTION_KEYS accepts a comma-separated key ring. Place a new key first to encrypt new writes; retain previous keys so old values still decrypt. Re-encryption of existing data and removal of retired keys require a controlled migration that is not implemented in the UI. Do not discard old keys until every affected encrypted value and backup has a documented recovery path.

## Monitoring and limitations

`/health/live` verifies the web process. `/health/ready` verifies SQL and configured Mongo/Redis connectivity. Production configuration requires ClamAV, but readiness does not currently probe its signature freshness. Worker heartbeat, queue age, disk capacity, dead-letter alerts and error-rate monitoring require external observability configuration.

Application logs include a request ID, method, route template and status. They omit raw paths, queries, bodies and exception messages to avoid sensitive values. Audit events omit record values. This reduces leakage but also means the audit table is not a complete record-version history or restore mechanism. Configure audit retention and restricted log access at the deployment layer.

A SQL failure after a MongoDB payload insert or a crash during file commit can leave orphaned data. Reconciliation/garbage-collection tooling remains a release gap; do not delete payloads merely because a transient database lookup fails.
