# API conventions

Version prefix: `/api/v1`. Success: `{ "data": ..., "meta": ... }`. Error: `{ "error": { "code": "...", "message": "..." } }`.

Swagger at `/api/docs` provides the implemented route inventory. Request shapes are documented in OpenAPI; metadata settings and dynamic response bodies require the conventions below. Swagger is read-only by default to avoid accidental mutations; use a trusted client for requests.

## Authentication

1. GET `/auth/bootstrap` supplies a pre-authentication CSRF value and sets its HttpOnly cookie.
2. POST `/auth/setup` once, supplying setup_token, username, email and a 12–256 character password. Send `X-CSRF-Token`.
3. POST `/auth/login` with username/password and optional TOTP or recovery `code`. Send the bootstrap CSRF value. A session cookie is issued only after MFA succeeds.
4. GET `/auth/me` gives current user and session CSRF. Send this CSRF on cookie-authenticated mutations.
5. POST `/auth/tokens` with password and, when enabled, MFA code to issue an expiring bearer token. This token is displayed once. Use `Authorization: Bearer <token>` on external requests. Bearer requests do not require CSRF.
6. Revoke sessions through DELETE `/auth/sessions/{id}`. Disabling a user or changing a password revokes appropriate sessions.

Recovery endpoints return generic account-existence responses. Password recovery needs enabled SMTP and the worker. Reset email contains a single-use token with 20-minute expiry. Reset does not bypass enabled MFA; use TOTP or a recovery code.

## Module metadata

POST `/modules`:

```json
{
  "name": "reading_log", "label": "Reading log", "plural": "Reading logs",
  "category": "Personal", "description": "Books and reading notes",
  "settings": {"visible": true, "searchable": true, "attachments": true, "api_enabled": true}
}
```

Every module gets a required `name` field and a default list view. `name` is a stable lowercase identifier, not SQL table interpolation. Module internal identifiers cannot be renamed through ordinary metadata editing.

POST `/modules/reading_log/fields`:

```json
{
  "name": "pages", "label": "Pages", "kind": "number", "scope": "module", "position": 1,
  "settings": {"required": false, "min": 0, "max": 100000, "width": "half", "visible": true}
}
```

Field settings consumed by the server: required, default, visible, visible_when, read_only, editable, min, max, max_length, regex, options, parent_field, options_by_parent, formula. UI also consumes width and placeholder. Description is stored; some contextual help presentations remain incomplete.

A condition is `{"field":"status","equals":"Active"}`. A nested dropdown uses `parent_field` and `options_by_parent`, for example `{"India":["Maharashtra","Karnataka"]}`. Parent fields are validated before nested children. Parent-only edits cannot leave an invalid stored child selection. Multiple cascading levels still need topological dependency validation.

Formulas allow field names, numeric literals, parentheses and `+ - * / %`. No function calls, attributes, imports, exponentiation or arbitrary Python execution. Formula values are computed on save and returned as decimal strings. Circular or unknown dependencies fail. Formula results are hidden if dependencies are unreadable. Formula fields are excluded from report/export selection in this release.

Global definitions: POST `/global-fields` with a field definition, then POST `/modules/{name}/fields` with `global_id`. Attachments reuse definitions but do not automatically propagate later definition changes.

## Records

POST `/modules/{name}/records` accepts `{"values":{"name":"A record","pages":40}}`.

Response: UUID `id`, module_id, owner_id, values, integer version, created_at and updated_at. Secrets return only `{ "configured": true }`. JSON document fields return a document_id pointer; GET `/records/{id}/documents/{field_name}` reads its payload after permission checks.

PATCH `/records/{id}` requires current version and changed values:

```json
{"version": 1, "values": {"pages": 60}}
```

A stale update returns 409. DELETE requires an `If-Match` header containing the plain current version. Linked records, attached records and referenced accounting accounts cannot be deleted until dependent references are resolved.

GET `/modules/{name}/records` accepts page, per_page (maximum 100), q, view_id, sort, direction and filters. Filters are a URL-encoded JSON array. Supported operators: eq, ne, gt, lt. Numeric fields use numeric sorting/filtering. Search does not inspect secrets, JSON payloads or unreadable fields.

POST `/modules/{name}/import`: `{"rows":[{"name":"First"},{"name":"Second"}]}`. At most 500 rows; SQL changes are atomic. A MongoDB payload written before a failed SQL commit may remain unreferenced. GET `/modules/{name}/export` returns CSV limited to 10,000 matching rows. Spreadsheet formula prefixes are neutralised; negative numeric CSV values may import as text and require explicit typing in analytical tools.

## Permissions

Role definition example:

```json
{
  "name":"Personal editor",
  "grants":{
    "people":{
      "actions":["create","read","update","attach"],
      "scope":"own",
      "fields":{"name":["read","write"],"email":["read","write"]}
    }
  }
}
```

Module `*` and field `*` are wildcards. Missing module grants deny access. Own scope includes explicitly shared records for allowed actions; a share does not grant module access by itself. Field permissions are enforced in the service, not just hidden UI controls. Platform administrators can manage configuration. Delegating configure/administer to ordinary roles is not implemented despite those names being recognised actions.

Sharing: POST `/records/{id}/shares` with user_id and actions. Allowed share actions: read, update, attach, export. Supplying an empty actions array effectively revokes a share. Current UI supports adding a share; full share inventory/revocation UI remains.

## Relationships and files

Create `/relationships` with name, source_module_id, target_module_id and cardinality. Link `/links` with relationship_id, source_id and target_id. Both endpoints need update permission. SQL unique slots enforce cardinality even when requests race; real PostgreSQL concurrency tests remain required.

Upload multipart `file` to `/records/{id}/files`. Optional previous_id creates a version. Download `/files/{id}/download` always uses attachment disposition. Accepted extensions: PDF, PNG/JPEG/WebP, TXT, CSV and JSON; up to 10 MB. Production requires ClamAV and rejects unscanned downloads.

## Integration settings

Create `/integrations` with name, kind, enabled, public settings and write-only secrets. Blank credentials on an edit preserve existing credentials; explicit `{}` clears them.

| Provider | Public settings | Secret fields |
|---|---|---|
| n8n/webhook/REST | url, events, module_ids | webhook_secret; optional token |
| Telegram | chat_id, events, module_ids | bot_token |
| SMTP | host, port, tls (`ssl`/`starttls`), username, sender, reply_to | password |
| Google Sheets | spreadsheet_id, range, events, module_ids | access_token |
| Tableau | description/site for configuration catalogue | No native publishing adapter; use CSV export |
| Supabase/MongoDB | Configuration catalogue only | Runtime database URLs use protected environment configuration |
| OAuth | Configuration catalogue only | Full consent/refresh/revocation lifecycle not implemented |

An event subscription requires exact module UUIDs and events such as record.created, record.updated or record.deleted. Outbound requests sign exact JSON bytes with:

`HMAC-SHA256(secret, timestamp + "." + raw_body)`

Headers: X-LifeOS-Timestamp, X-LifeOS-Signature, X-LifeOS-Delivery. Consumers must deduplicate the delivery ID. Retries can cause duplicate delivery, particularly after worker crashes. Backoff starts at 60 seconds and caps at 3,600 seconds; five attempts, then manual retry.

POST `/webhooks/{integration_id}` accepts signed JSON with unique event_id. Timestamp must be within 300 seconds. This acknowledges and audits inbound events; it is not a general workflow interpreter. To modify a record from n8n, call normal authenticated CRUD APIs with an authorised bearer token.

## Reports and accounting

POST `/reports`: name, module_id and settings `{ "aggregate":"sum", "value_field":"amount", "group_by":"category", "filters":[], "chart":"bar" }`. GET `/reports/{id}/run` returns group/value/count. Reports are private to their creator and permission-checked on every run. This release limits runs to 10,000 records and computes grouped aggregates in application memory.

POST `/accounting/journals` supplies reference, three-letter currency, and 2–100 lines. Each line contains an Accounts record ID and one positive debit or credit. Totals must balance exactly; six decimal places maximum. Journals are append-only through these APIs. This does not implement period close, reversal workflows, tax, multi-currency revaluation or reconciliation.
