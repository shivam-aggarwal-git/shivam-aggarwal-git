# Life OS

Independent Python + Flask personal information platform, using Vtiger Community Edition concepts as a functional reference. No PHP or Vtiger code is included.

**This is a working development release, not the complete production-ready system requested.** Read [the 106-point status register](docs/REQUIREMENTS.md) before using it for personal data. The register explicitly distinguishes completed functionality, partial features and unverified deployment integrations.

Estimated complete delivery effort: **12–20 weeks with a small engineering team**, including the remaining functionality, live integration testing, independent security review and operational qualification.

## Run locally with Docker

Prerequisites: Docker with the Compose plugin, and Python 3 for the one-time configuration generator.

```bash
cd life-os
python scripts/configure.py
docker compose up -d --build
```

Open **http://localhost:8000**. Read `SETUP_TOKEN` from your generated `.env` file and use it on the first-run screen to create your administrator. Choose your own username, email and password. There are **no default login credentials**.

Compose starts PostgreSQL, MongoDB, Redis, migrations, the application and the integration worker. Files and databases use persistent volumes. Database services have no host-exposed ports.

```bash
docker compose ps
docker compose logs --tail=100 web worker migrate
docker compose down
```

`docker compose down` preserves your data volumes. Do not add `-v` unless you intend to delete all stored data. Keep `.env` secure; losing encryption keys can make encrypted credentials unrecoverable.

**Docker was not available in the build environment.** The configuration is supplied for local verification; a successful Compose deployment is not claimed here.

## Run in VS Code / an existing Python virtual environment

Use Python 3.12. Activate your existing environment, open a terminal in `life-os`, then:

```bash
python -m pip install -r requirements.lock
python scripts/configure.py
python -m flask --app wsgi db upgrade
python -m flask --app wsgi seed
python -m flask --app wsgi run --host 127.0.0.1 --port 8000
```

If `.env` already exists, skip `configure.py`; it deliberately refuses to overwrite existing keys. In this mode SQLite is used by default, at `instance/lifeos.db`. SQLite is for development/testing. Without MongoDB, JSON document fields return a clear dependency error. Configure `DATABASE_URL`, `MONGO_URI` and `REDIS_URL` to use running services.

Run the worker in a second activated terminal when testing integrations:

```bash
python -m lifeos.worker
```

The Flask development server is for local use only. Docker uses Gunicorn.

## First steps in the application

1. Open **Security & sessions**. Enrol an authenticator, then store the one-time recovery codes separately.
2. Open **Module & form builders** → **New module**. Set singular/plural names and a stable internal identifier.
3. Add fields from the form palette. Drag to reorder, or use the move-up button. Configure validation, required fields, choices and arithmetic formulas.
4. Open **View manager** to choose columns, order, filters and form fields. Use a default filter such as `[{"field":"status","op":"eq","value":"Active"}]`.
5. Open a module and add records. Manage attachments and linked records from the record detail page.
6. Create relationship definitions before linking records. Both endpoints must be editable by the person creating the link.
7. Create roles and users. Non-administrators have no access until granted module actions. A role can restrict access to owned/shared records and individual fields.
8. Create reports with count/sum/average/min/max and an optional group field. Reports only include permitted records and readable fields.
9. Configure integrations and subscribe them to module IDs and record events. Enable the worker before sending a connection test.

The seeded finance, calendar, inventory and projection modules are configurable records, not complete specialist applications. Balanced journal posting is a separate API under `/api/v1/accounting/journals`; its advanced UI, reversal controls and period closing are not implemented.

## API and integrations

- Swagger documentation: **http://localhost:8000/api/docs**
- OpenAPI JSON: **http://localhost:8000/api/openapi.json**
- [API conventions, schemas and examples](docs/API.md)
- [Architecture and database placement](docs/ARCHITECTURE.md)
- [Deployment, backup and recovery](docs/OPERATIONS.md)
- [Complete requirement status](docs/REQUIREMENTS.md)

Authentication uses HttpOnly SameSite cookies with CSRF headers or expiring bearer tokens. Integration credentials are encrypted and write-only. Never put tokens in public settings, source code or URLs.

n8n receives signed events with a delivery ID. Events contain record IDs, module IDs and versions, not personal field values. n8n can fetch/update records through a narrowly permissioned Life OS API account. Inbound signed webhooks acknowledge and deduplicate event IDs; they do not execute arbitrary commands. API tokens expire; configure an appropriate session lifetime and rotation procedure.

SMTP supports SSL or STARTTLS. Telegram supports outbound bot alerts. Google Sheets supports event append using an operator-supplied access token. Tableau can consume a downloaded permission-filtered CSV. Full OAuth lifecycle, Telegram commands and native Tableau publishing remain incomplete.

## Configuration

All application-level secret variables support a `NAME_FILE` equivalent for mounted secret files. Keep private keys separate from database and upload backups.

| Variable | Purpose |
|---|---|
| `SECRET_KEY` | Random 32+ character application key; no default |
| `ENCRYPTION_KEYS` | Comma-separated Fernet keys, newest first |
| `SETUP_TOKEN` | One-time bootstrap authorisation; setup closes after first user |
| `DATABASE_URL` | SQLAlchemy URL; default local SQLite; production PostgreSQL |
| `MONGO_URI` | Mongo URI including default database |
| `REDIS_URL` | Shared production rate-limit storage |
| `COOKIE_SECURE` | `true` for HTTPS deployments |
| `TRUSTED_HOSTS` | Comma-separated permitted Host headers; include localhost for healthchecks |
| `TRUST_PROXY` | Trust exactly one controlled reverse proxy when `true` |
| `SESSION_HOURS` | Session and bearer-token lifetime; default 8 hours |
| `UPLOAD_DIR` | Private attachment volume |
| `CLAMAV_HOST` | Malware scanner; required in production |
| `INTEGRATION_ALLOWED_HOSTS` | Exact outbound host allowlist; public IPs and HTTPS required |
| `PORT` | Local Compose port, default 8000 |
| `DOMAIN` | Production Caddy hostname |

## Verification

```bash
python -m pip install -r requirements-dev.txt
python -m pytest -q
python -m flask --app wsgi db check
```

Build-environment results: **21 tests passed**, initial migration applied and schema-drift check passed on SQLite. Python compilation and JavaScript syntax check passed. No live provider, Docker, PostgreSQL, MongoDB, visual browser or native mobile validation is claimed.

## Source layout

```text
lifeos/             Flask services, ORM models, security and web UI
migrations/         Explicit versioned Alembic schema
scripts/            Initial environment configuration
tests/              Authentication, integrity and API regression tests
deploy/             Reverse-proxy configuration
docs/               Architecture, API, operations and requirement register
compose.yaml        Local PostgreSQL/MongoDB/Redis deployment
compose.production.yaml  HTTPS/ClamAV production overlay
```
