import io, json, time, hmac, hashlib
import pyotp
from lifeos.models import *
from lifeos.security import decrypt
from .conftest import login


def post(c, path, data, headers):
    return c.post("/api/v1" + path, json=data, headers=headers)


def test_auth_csrf_bootstrap(client, owner):
    assert client.post("/api/v1/modules", json={}).status_code == 403
    assert post(client, "/auth/setup", {}, owner).status_code in (403, 409)
    assert client.get("/api/v1/auth/me").json["data"]["user"]["username"] == "owner"
    assert (
        client.get("/").headers["Content-Security-Policy"].find("script-src 'self'")
        >= 0
    )


def test_dynamic_module_formula_versioning(client, owner):
    m = post(
        client,
        "/modules",
        {"name": "reading_log", "label": "Reading log", "plural": "Reading logs"},
        owner,
    )
    assert m.status_code == 201, m.json
    for name, kind, settings in [
        ("pages", "number", {}),
        ("minutes", "decimal", {}),
        ("pace", "formula", {"formula": "pages / minutes"}),
    ]:
        assert (
            post(
                client,
                "/modules/reading_log/fields",
                {"name": name, "label": name, "kind": kind, "settings": settings},
                owner,
            ).status_code
            == 201
        )
    r = post(
        client,
        "/modules/reading_log/records",
        {"values": {"name": "A book", "pages": 40, "minutes": "20"}},
        owner,
    )
    assert r.status_code == 201, r.json
    record = r.json["data"]
    assert record["values"]["pace"] == "2"
    assert (
        client.patch(
            "/api/v1/records/" + record["id"],
            json={"values": {"pages": 60}, "version": record["version"]},
            headers=owner,
        ).status_code
        == 200
    )
    assert (
        client.patch(
            "/api/v1/records/" + record["id"],
            json={"values": {"pages": 80}, "version": record["version"]},
            headers=owner,
        ).status_code
        == 409
    )
    assert (
        post(
            client,
            "/modules/reading_log/records",
            {"values": {"name": "Invalid", "pages": 40, "minutes": 0}},
            owner,
        ).status_code
        == 400
    )


def test_secret_at_rest_masked_and_not_exported(client, owner, app):
    post(
        client,
        "/modules/people/fields",
        {"name": "private_key", "label": "Private key", "kind": "secret"},
        owner,
    )
    r = post(
        client,
        "/modules/people/records",
        {"values": {"name": "Person", "private_key": "sensitive-test-value"}},
        owner,
    ).json["data"]
    assert r["values"]["private_key"] == {"configured": True}
    with app.app_context():
        raw = db.session.get(Record, r["id"]).values["private_key"]["encrypted"]
        assert "sensitive-test-value" not in raw
        assert decrypt(raw) == "sensitive-test-value"
    assert (
        b"sensitive-test-value" not in client.get("/api/v1/modules/people/export").data
    )
    assert b"private_key" not in client.get("/api/v1/modules/people/export").data
    assert b"sensitive-test-value" not in client.get("/api/v1/audit-logs").data


def test_relationship_cardinality_and_delete(client, owner):
    mods = client.get("/api/v1/modules").json["data"]
    ids = {m["name"]: m["id"] for m in mods}
    rel = post(
        client,
        "/relationships",
        {
            "name": "Person primary account",
            "source_module_id": ids["people"],
            "target_module_id": ids["accounts"],
            "cardinality": "one_to_one",
        },
        owner,
    ).json["data"]
    person = post(
        client, "/modules/people/records", {"values": {"name": "A"}}, owner
    ).json["data"]
    accounts = [
        post(client, "/modules/accounts/records", {"values": {"name": n}}, owner).json[
            "data"
        ]
        for n in ("One", "Two")
    ]
    assert (
        post(
            client,
            "/links",
            {
                "relationship_id": rel["id"],
                "source_id": person["id"],
                "target_id": accounts[0]["id"],
            },
            owner,
        ).status_code
        == 201
    )
    assert (
        post(
            client,
            "/links",
            {
                "relationship_id": rel["id"],
                "source_id": person["id"],
                "target_id": accounts[1]["id"],
            },
            owner,
        ).status_code
        == 409
    )
    assert (
        client.delete(
            "/api/v1/records/" + person["id"], headers={**owner, "If-Match": "1"}
        ).status_code
        == 409
    )


def test_rbac_ownership_fields_reports(client, owner, app):
    record = post(
        client,
        "/modules/people/records",
        {"values": {"name": "Private person", "email": "private@example.test"}},
        owner,
    ).json["data"]
    role = post(
        client,
        "/roles",
        {
            "name": "Own records",
            "grants": {
                "people": {
                    "actions": ["read", "create", "update", "export"],
                    "scope": "own",
                    "fields": {"name": ["read", "write"], "email": ["write"]},
                }
            },
        },
        owner,
    ).json["data"]
    post(
        client,
        "/users",
        {
            "username": "limited",
            "email": "limited@example.test",
            "password": "Limited password 456!",
            "role_ids": [role["id"]],
        },
        owner,
    )
    other = app.test_client()
    logged = login(other, "limited", "Limited password 456!")
    h = {"X-CSRF-Token": logged.json["data"]["csrf"]}
    assert other.get("/api/v1/records/" + record["id"]).status_code == 403
    assert other.get("/api/v1/modules/people/records").json["meta"]["total"] == 0
    assert other.get("/api/v1/users").status_code == 403
    own = post(
        other,
        "/modules/people/records",
        {"values": {"name": "My person", "email": "hidden@example.test"}},
        h,
    )
    assert own.status_code == 201, own.json
    assert "email" not in own.json["data"]["values"]
    assert (
        other.get("/api/v1/modules/people/records?q=hidden").json["meta"]["total"] == 0
    )
    assert b"hidden@example.test" not in other.get("/api/v1/modules/people/export").data


def test_mfa_required_recovery_single_use(client, owner, app):
    secret = post(
        client, "/auth/mfa/setup", {"password": "A secure test password 987!"}, owner
    ).json["data"]["secret"]
    codes = post(
        client, "/auth/mfa/confirm", {"code": pyotp.TOTP(secret).now()}, owner
    ).json["data"]["recovery_codes"]
    c = app.test_client()
    assert login(c).status_code == 401
    assert login(c, code=codes[0]).status_code == 200
    assert login(app.test_client(), code=codes[0]).status_code == 401


def test_upload_validation_private_download(client, owner, app):
    r = post(
        client, "/modules/documents/records", {"values": {"name": "Document"}}, owner
    ).json["data"]
    bad = client.post(
        "/api/v1/records/" + r["id"] + "/files",
        data={"file": (io.BytesIO(b"<script>alert(1)</script>"), "bad.html")},
        headers=owner,
    )
    assert bad.status_code == 400
    good = client.post(
        "/api/v1/records/" + r["id"] + "/files",
        data={"file": (io.BytesIO(b"hello"), "note.txt")},
        headers=owner,
    )
    assert good.status_code == 201, good.json
    id = good.json["data"]["id"]
    assert app.test_client().get("/api/v1/files/" + id + "/download").status_code == 401
    assert (
        client.get("/api/v1/files/" + id + "/download")
        .headers["Content-Disposition"]
        .startswith("attachment;")
    )


def test_signed_inbound_replay(client, owner):
    secret = "a-long-test-signing-secret"
    i = post(
        client,
        "/integrations",
        {
            "name": "n8n test",
            "kind": "n8n",
            "enabled": True,
            "secrets": {"webhook_secret": secret},
        },
        owner,
    ).json["data"]
    payload = json.dumps({"event_id": "event-123"}).encode()
    stamp = str(int(time.time()))
    signature = hmac.new(
        secret.encode(), stamp.encode() + b"." + payload, hashlib.sha256
    ).hexdigest()
    headers = {
        **owner,
        "Content-Type": "application/json",
        "X-LifeOS-Timestamp": stamp,
        "X-LifeOS-Signature": signature,
    }
    url = "/api/v1/webhooks/" + i["id"]
    assert client.post(url, data=payload, headers=headers).status_code == 202
    assert (
        client.post(url, data=payload, headers=headers).json["data"]["duplicate"]
        is True
    )
    headers["X-LifeOS-Signature"] = "incorrect"
    assert client.post(url, data=payload, headers=headers).status_code == 401


def test_atomic_import_and_formula_injection(client, owner):
    res = post(
        client,
        "/modules/people/import",
        {"rows": [{"name": "Valid"}, {"unknown": "Invalid"}]},
        owner,
    )
    assert res.status_code == 400
    assert client.get("/api/v1/modules/people/records").json["meta"]["total"] == 0
    from lifeos.validation import formula
    from lifeos.common import ApiError
    import pytest

    with pytest.raises(ApiError):
        formula('__import__("os").system("id")', {})
    with pytest.raises(ApiError):
        formula("2 ** 999999999", {})


def test_balanced_accounting(client, owner):
    a = [
        post(client, "/modules/accounts/records", {"values": {"name": n}}, owner).json[
            "data"
        ]["id"]
        for n in ("Bank", "Salary")
    ]
    payload = {
        "reference": "Salary received",
        "currency": "INR",
        "lines": [
            {"account_id": a[0], "debit": "100.25"},
            {"account_id": a[1], "credit": "100.25"},
        ],
    }
    assert post(client, "/accounting/journals", payload, owner).status_code == 201
    payload["lines"][1]["credit"] = "100.24"
    assert post(client, "/accounting/journals", payload, owner).status_code == 400
    assert client.get("/api/v1/accounting/journals").json["meta"]["total"] == 1


def test_outbox_commits_with_record(client, owner, app):
    mods = client.get("/api/v1/modules").json["data"]
    people = next(m for m in mods if m["name"] == "people")
    post(
        client,
        "/integrations",
        {
            "name": "Events",
            "kind": "n8n",
            "enabled": True,
            "settings": {"events": ["record.created"], "module_ids": [people["id"]]},
            "secrets": {"webhook_secret": "test"},
        },
        owner,
    )
    post(
        client, "/modules/people/records", {"values": {"name": "Sensitive name"}}, owner
    )
    with app.app_context():
        job = Outbox.query.one()
        assert job.event["type"] == "record.created"
        assert "Sensitive name" not in json.dumps(job.event)


def test_numeric_report_and_view(client, owner):
    for n, amount in [("First", "9"), ("Second", "100")]:
        post(
            client,
            "/modules/expenses/records",
            {"values": {"name": n, "amount": amount}},
            owner,
        )
    rows = client.get(
        "/api/v1/modules/expenses/records?sort=amount&direction=asc"
    ).json["data"]
    assert rows[0]["values"]["amount"] == "9"
    m = next(
        x for x in client.get("/api/v1/modules").json["data"] if x["name"] == "expenses"
    )
    r = post(
        client,
        "/reports",
        {
            "name": "Total expenses",
            "module_id": m["id"],
            "settings": {"aggregate": "sum", "value_field": "amount"},
        },
        owner,
    ).json["data"]
    result = client.get("/api/v1/reports/" + r["id"] + "/run")
    assert result.status_code == 200, result.json
    assert result.json["data"][0]["value"] == "109"


def test_secret_metadata_default_rejected(client, owner):
    r = post(
        client,
        "/modules/people/fields",
        {
            "name": "bad_secret",
            "label": "Secret",
            "kind": "secret",
            "settings": {"default": "never-public"},
        },
        owner,
    )
    assert r.status_code == 400


def test_reusable_field_and_layout(client, owner):
    f = post(
        client,
        "/global-fields",
        {"name": "reference_code", "label": "Reference code", "kind": "text"},
        owner,
    ).json["data"]
    for module in ("people", "contacts"):
        assert (
            post(
                client, f"/modules/{module}/fields", {"global_id": f["id"]}, owner
            ).status_code
            == 201
        )
    schema = client.get("/api/v1/modules/people/schema").json["data"]
    ids = [f["id"] for f in schema["fields"]][::-1]
    assert (
        client.put(
            "/api/v1/modules/people/form-layout", json={"field_ids": ids}, headers=owner
        ).status_code
        == 200
    )
    assert (
        client.get("/api/v1/modules/people/schema").json["data"]["fields"][0]["id"]
        == ids[0]
    )
    assert (
        client.put(
            "/api/v1/modules/people/form-layout",
            json={"field_ids": ids[:-1]},
            headers=owner,
        ).status_code
        == 400
    )


def test_invalid_regex_and_validation_timeout(client, owner):
    assert (
        post(
            client,
            "/modules/people/fields",
            {
                "name": "code",
                "label": "Code",
                "kind": "text",
                "settings": {"regex": "["},
            },
            owner,
        ).status_code
        == 400
    )
    post(
        client,
        "/modules/people/fields",
        {
            "name": "code",
            "label": "Code",
            "kind": "text",
            "settings": {"regex": "[A-Z]{3}"},
        },
        owner,
    )
    assert (
        post(
            client,
            "/modules/people/records",
            {"values": {"name": "A", "code": "bad"}},
            owner,
        ).status_code
        == 400
    )
    assert (
        post(
            client,
            "/modules/people/records",
            {"values": {"name": "A", "code": "ABC"}},
            owner,
        ).status_code
        == 201
    )


def test_session_revocation_and_bearer(client, owner, app):
    token = post(
        client, "/auth/tokens", {"password": "A secure test password 987!"}, owner
    ).json["data"]["token"]
    other = app.test_client()
    bearer = {"Authorization": "Bearer " + token}
    assert (
        post(
            other, "/modules/people/records", {"values": {"name": "API record"}}, bearer
        ).status_code
        == 201
    )
    sessions = client.get("/api/v1/auth/sessions").json["data"]
    target = next(s for s in sessions if not s["current"])
    assert (
        client.delete(
            "/api/v1/auth/sessions/" + target["id"], headers=owner
        ).status_code
        == 200
    )
    assert other.get("/api/v1/auth/me", headers=bearer).status_code == 401


def test_json_document_requires_mongo(client, owner):
    post(
        client,
        "/modules/notes/fields",
        {"name": "payload", "label": "Payload", "kind": "json"},
        owner,
    )
    assert (
        post(
            client,
            "/modules/notes/records",
            {"values": {"name": "A", "payload": {"test": True}}},
            owner,
        ).status_code
        == 503
    )
    assert client.get("/api/v1/modules/notes/records").json["meta"]["total"] == 0


def test_formula_hidden_input_not_exposed(client, owner, app):
    post(
        client,
        "/modules/people/fields",
        {"name": "salary", "label": "Salary", "kind": "currency"},
        owner,
    )
    post(
        client,
        "/modules/people/fields",
        {
            "name": "annual",
            "label": "Annual",
            "kind": "formula",
            "settings": {"formula": "salary * 12"},
        },
        owner,
    )
    record = post(
        client,
        "/modules/people/records",
        {"values": {"name": "Confidential", "salary": "100000"}},
        owner,
    ).json["data"]
    role = post(
        client,
        "/roles",
        {
            "name": "Name only",
            "grants": {
                "people": {
                    "actions": ["read"],
                    "scope": "all",
                    "fields": {"name": ["read"], "annual": ["read"]},
                }
            },
        },
        owner,
    ).json["data"]
    post(
        client,
        "/users",
        {
            "username": "reader",
            "email": "reader@example.test",
            "password": "Reader password 456!",
            "role_ids": [role["id"]],
        },
        owner,
    )
    other = app.test_client()
    login(other, "reader", "Reader password 456!")
    result = other.get("/api/v1/records/" + record["id"]).json["data"]
    assert "annual" not in result["values"] and "salary" not in result["values"]


def test_permission_revoked_immediately(client, owner, app):
    role = post(
        client,
        "/roles",
        {"name": "Reader", "grants": {"people": {"actions": ["read"], "scope": "all"}}},
        owner,
    ).json["data"]
    post(
        client,
        "/users",
        {
            "username": "viewer",
            "email": "viewer@example.test",
            "password": "Viewer password 123!",
            "role_ids": [role["id"]],
        },
        owner,
    )
    other = app.test_client()
    login(other, "viewer", "Viewer password 123!")
    assert other.get("/api/v1/modules/people/records").status_code == 200
    client.patch("/api/v1/roles/" + role["id"], json={"grants": {}}, headers=owner)
    assert other.get("/api/v1/modules/people/records").status_code == 403


def test_production_rejects_insecure_configuration(app):
    from lifeos import create_app
    import pytest

    with pytest.raises(RuntimeError):
        create_app(
            {
                "SECRET_KEY": app.config["SECRET_KEY"],
                "ENCRYPTION_KEYS": app.config["ENCRYPTION_KEYS"],
                "ENVIRONMENT": "production",
                "COOKIE_SECURE": False,
            }
        )


def test_nested_dropdown_revalidates_parent_changes(client, owner):
    post(
        client,
        "/modules/people/fields",
        {
            "name": "country",
            "label": "Country",
            "kind": "dropdown",
            "settings": {"options": ["India", "UK"]},
        },
        owner,
    )
    post(
        client,
        "/modules/people/fields",
        {
            "name": "state",
            "label": "State",
            "kind": "nested_dropdown",
            "settings": {
                "parent_field": "country",
                "options_by_parent": {"India": ["Maharashtra"], "UK": ["England"]},
            },
        },
        owner,
    )
    created = post(
        client,
        "/modules/people/records",
        {"values": {"name": "Person", "state": "Maharashtra", "country": "India"}},
        owner,
    )
    assert created.status_code == 201, created.json
    record = created.json["data"]
    changed = client.patch(
        "/api/v1/records/" + record["id"],
        json={"version": record["version"], "values": {"country": "UK"}},
        headers=owner,
    )
    assert changed.status_code == 400
