import secrets
import pytest
from cryptography.fernet import Fernet
from lifeos import create_app
from lifeos.models import db
from lifeos.seed import seed


@pytest.fixture
def app(tmp_path):
    app = create_app(
        {
            "TESTING": True,
            "SECRET_KEY": secrets.token_urlsafe(48),
            "ENCRYPTION_KEYS": Fernet.generate_key().decode(),
            "SETUP_TOKEN": "test-setup-token",
            "SQLALCHEMY_DATABASE_URI": "sqlite:///" + str(tmp_path / "test.db"),
            "UPLOAD_DIR": str(tmp_path / "uploads"),
            "MONGO_URI": None,
            "RATELIMIT_ENABLED": False,
            "COOKIE_SECURE": False,
            "ENVIRONMENT": "development",
        }
    )
    with app.app_context():
        db.create_all()
        seed()
    yield app
    with app.app_context():
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


def login(client, username="owner", password="A secure test password 987!", code=""):
    csrf = client.get("/api/v1/auth/bootstrap").json["data"]["csrf"]
    r = client.post(
        "/api/v1/auth/login",
        json={"username": username, "password": password, "code": code},
        headers={"X-CSRF-Token": csrf},
    )
    return r


@pytest.fixture
def owner(client):
    csrf = client.get("/api/v1/auth/bootstrap").json["data"]["csrf"]
    r = client.post(
        "/api/v1/auth/setup",
        json={
            "setup_token": "test-setup-token",
            "username": "owner",
            "email": "owner@example.test",
            "password": "A secure test password 987!",
        },
        headers={"X-CSRF-Token": csrf},
    )
    assert r.status_code == 201, r.json
    r = login(client)
    assert r.status_code == 200, r.json
    return {"X-CSRF-Token": r.json["data"]["csrf"]}
