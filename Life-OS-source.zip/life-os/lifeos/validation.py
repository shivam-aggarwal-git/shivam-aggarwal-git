"""Bounded, server-side typed fields and safe decimal expressions."""

import ast, operator, json, re
from decimal import Decimal, InvalidOperation
from datetime import date, datetime, time
from urllib.parse import urlsplit
import regex, bleach
from flask import g
from .common import fail, get
from .models import Record, Module, File
from .security import field_allowed, allowed, encrypt

NUMERIC = {"number", "decimal", "currency", "formula"}
SECRET = {"secret"}
OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
}


def formula(expression, values):
    if not isinstance(expression, str) or len(expression) > 500:
        fail("Formula must be at most 500 characters")
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError:
        fail("Invalid formula")
    if len(list(ast.walk(tree))) > 100:
        fail("Formula is too complex")

    def run(node):
        if isinstance(node, ast.Expression):
            return run(node.body)
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            return Decimal(str(node.value))
        if isinstance(node, ast.Name):
            return Decimal(str(values.get(node.id, 0) or 0))
        if isinstance(node, ast.BinOp) and type(node.op) in OPS:
            return OPS[type(node.op)](run(node.left), run(node.right))
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
            return run(node.operand) * (1 if isinstance(node.op, ast.UAdd) else -1)
        fail("Formula supports field names, numbers, parentheses and + - * / % only")

    try:
        value = run(tree)
        if not value.is_finite() or abs(value) > Decimal("1e24"):
            fail("Formula result exceeds supported range")
        return str(value)
    except (InvalidOperation, ZeroDivisionError, ValueError):
        fail("Formula contains an invalid numeric value or division by zero")


def visible(field, values):
    c = field.settings.get("visible_when")
    return field.settings.get("visible", True) and (
        not c or values.get(c.get("field")) == c.get("equals")
    )


def validate_values(module, incoming, existing=None):
    if not isinstance(incoming, dict):
        fail("values must be an object")
    fields = {f.name: f for f in module.fields}
    if set(incoming) - fields.keys():
        fail("Unknown fields: " + ", ".join(sorted(set(incoming) - fields.keys())))
    values = dict(existing or {})
    for name, value in sorted(
        incoming.items(), key=lambda item: fields[item[0]].kind == "nested_dropdown"
    ):
        f = fields[name]
        s = f.settings
        if not field_allowed(module, f, "write"):
            fail("Field write denied: " + name, 403)
        if f.kind == "formula" or s.get("read_only") or s.get("editable") is False:
            fail("Field is read-only: " + name)
        values[name] = validate_field(f, value, values, module)
    for f in module.fields:
        if f.name not in values and "default" in f.settings and f.kind != "formula":
            values[f.name] = validate_field(f, f.settings["default"], values, module)
        if (
            f.settings.get("required")
            and visible(f, values)
            and values.get(f.name) in (None, "", [])
        ):
            fail(f.label + " is required")
    pending = {f.name: f for f in module.fields if f.kind == "formula"}
    for _ in range(len(pending) + 1):
        progress = False
        for name, f in list(pending.items()):
            expression = f.settings.get("formula", "0")
            try:
                deps = {
                    n.id
                    for n in ast.walk(ast.parse(expression, mode="eval"))
                    if isinstance(n, ast.Name)
                }
            except SyntaxError:
                fail("Invalid formula")
            if deps - fields.keys():
                fail("Formula references an unknown field")
            if any(fields[d].kind in SECRET or fields[d].kind == "json" for d in deps):
                fail("Formula cannot reference secrets or documents")
            if not deps & pending.keys():
                values[name] = formula(expression, values)
                del pending[name]
                progress = True
        if not pending:
            break
        if not progress:
            fail("Circular formula dependency")
    # Parent-only edits cannot leave a formerly valid child selection invalid.
    for f in module.fields:
        if f.kind == "nested_dropdown" and values.get(f.name) is not None:
            validate_field(f, values[f.name], values, module)
    return values


def validate_field(f, value, values, module):
    s = f.settings
    kind = f.kind
    if value is None or value == "":
        return None
    if kind in ("linked_record", "linked_list"):
        ids = value if kind == "linked_list" else [value]
        if not isinstance(ids, list) or len(ids) > 100:
            fail("Invalid linked record list")
        # References are stored only in record_links, ensuring FK integrity.
        fail(
            "Use Related records to create links; linked fields are relationship displays"
        )
    if kind in ("file", "attachment", "image"):
        fail("Use the record attachment manager for file uploads")
    if kind == "json":
        if not isinstance(value, (dict, list)):
            fail(f.label + " must be a JSON object or array")
        if len(json.dumps(value)) > 500000:
            fail("JSON payload too large")
        return value
    if kind == "checkbox":
        if not isinstance(value, bool):
            fail(f.label + " must be true or false")
        return value
    if kind in ("number", "decimal", "currency"):
        try:
            v = Decimal(str(value))
        except InvalidOperation:
            fail(f.label + " must be numeric")
        if not v.is_finite() or abs(v) > Decimal("1e24"):
            fail("Numeric value out of range")
        if (
            "min" in s
            and v < Decimal(str(s["min"]))
            or "max" in s
            and v > Decimal(str(s["max"]))
        ):
            fail(f.label + " is outside the allowed range")
        if kind == "number":
            if v != v.to_integral():
                fail(f.label + " must be a whole number")
            return int(v)
        return str(v)
    if kind == "multiselect":
        if not isinstance(value, list) or any(
            x not in s.get("options", []) for x in value
        ):
            fail("Invalid selected values")
        return list(dict.fromkeys(value))
    if not isinstance(value, str) or len(value) > min(
        50000, int(s.get("max_length", 5000))
    ):
        fail(f.label + " is too long or has an invalid type")
    if kind in ("dropdown", "radio", "searchable") and value not in s.get(
        "options", []
    ):
        fail("Invalid option for " + f.label)
    if kind == "nested_dropdown":
        options = s.get("options_by_parent", {}).get(
            str(values.get(s.get("parent_field"))), []
        )
        if value not in options:
            fail("Invalid nested selection")
    if kind in ("date", "datetime", "time"):
        try:
            {"date": date, "datetime": datetime, "time": time}[kind].fromisoformat(
                value
            )
        except ValueError:
            fail("Invalid " + kind + " format")
    if kind == "email" and not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value):
        fail("Invalid email")
    if kind == "url" and (
        urlsplit(value).scheme not in ("http", "https") or not urlsplit(value).hostname
    ):
        fail("Only valid HTTP(S) URLs are allowed")
    if kind == "phone" and not re.fullmatch(r"[+0-9 ()-]{6,30}", value):
        fail("Invalid phone number")
    if s.get("regex"):
        try:
            matched = regex.fullmatch(s["regex"], value, timeout=0.03)
        except (TimeoutError, regex.error):
            fail("Validation expression failed or exceeded time limit")
        if not matched:
            fail(f.label + " does not match the validation rule")
    if kind == "richtext":
        return bleach.clean(
            value,
            tags=["p", "br", "strong", "em", "ul", "ol", "li", "a"],
            attributes={"a": ["href", "title"]},
            protocols=["http", "https"],
            strip=True,
        )
    if kind == "secret":
        return {"encrypted": encrypt(value)}
    return value
