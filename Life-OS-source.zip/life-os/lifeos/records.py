import json, csv, io
from flask import Blueprint, g, request, Response, current_app
from sqlalchemy import or_
from .models import *
from .common import *
from .metadata import module_by_name
from .security import *
from .validation import validate_values, NUMERIC

bp = Blueprint("records", __name__, url_prefix="/api/v1")


def serialize(record, module):
    values = {}
    # Formula fields inherit read restrictions of all referenced inputs.
    import ast

    fields = {f.name: f for f in module.fields}

    def readable(f, seen=None):
        seen = seen or set()
        if f.name in seen or not field_allowed(module, f, "read"):
            return False
        if f.kind == "formula":
            seen = seen | {f.name}
            try:
                deps = {
                    n.id
                    for n in ast.walk(
                        ast.parse(f.settings.get("formula", "0"), mode="eval")
                    )
                    if isinstance(n, ast.Name)
                }
            except SyntaxError:
                return False
            return all(n in fields and readable(fields[n], seen) for n in deps)
        return True

    for f in module.fields:
        if f.name in record.values and readable(f):
            values[f.name] = (
                {"configured": bool(record.values[f.name])}
                if f.kind == "secret"
                else record.values[f.name]
            )
    return {
        "id": record.id,
        "module_id": record.module_id,
        "owner_id": record.owner_id,
        "values": values,
        "version": record.version,
        "created_at": record.created_at.isoformat(),
        "updated_at": record.updated_at.isoformat(),
    }


def record_context(id, action="read"):
    r = get(Record, id)
    m = get(Module, r.module_id)
    require(m, action, r)
    if m.settings.get("api_enabled") is False and g.bearer:
        fail("Module API access disabled", 403)
    return r, m


def store_documents(module, values, changed, record_id):
    client = current_app.extensions.get("mongo")
    for f in module.fields:
        if f.kind == "json" and f.name in changed and values.get(f.name) is not None:
            if client is None:
                fail("MongoDB must be configured for JSON document fields", 503)
            payload_id = uid()
            client.get_default_database()["record_documents"].insert_one(
                {
                    "_id": payload_id,
                    "record_id": record_id,
                    "field_id": f.id,
                    "payload": values[f.name],
                    "created_at": now(),
                }
            )
            values[f.name] = {"document_id": payload_id}
    return values


def emit(event, record):
    for integration in Integration.query.filter_by(enabled=True).all():
        settings = integration.settings
        if event in settings.get("events", []) and record.module_id in settings.get(
            "module_ids", []
        ):
            db.session.add(
                Outbox(
                    integration_id=integration.id,
                    event={
                        "type": event,
                        "record_id": record.id,
                        "module_id": record.module_id,
                        "version": record.version,
                    },
                )
            )


def filtered_query(module, action="read", settings=None):
    settings = settings or {}
    q = scoped_query(module, action)
    fields = {
        f.name: f
        for f in module.fields
        if field_allowed(module, f, "read")
        and f.kind not in ("secret", "json", "formula")
    }
    search = request.args.get("q", "").strip()
    if len(search) > 200:
        fail("Search is too long")
    if search and module.settings.get("searchable", True):
        clauses = [
            Record.values[f.name]
            .as_string()
            .ilike(
                "%"
                + search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
                + "%",
                escape="\\",
            )
            for f in fields.values()
            if f.kind in ("text", "email", "phone", "textarea")
        ]
        q = q.filter(or_(*clauses)) if clauses else q.filter(db.false())
    filters = settings.get("filters", [])
    if request.args.get("filters"):
        try:
            filters = json.loads(request.args["filters"])
        except ValueError:
            fail("Invalid filters JSON")
    if not isinstance(filters, list) or len(filters) > 20:
        fail("At most 20 filters are allowed")
    for f in filters:
        name = f.get("field")
        op = f.get("op", "eq")
        value = f.get("value")
        if name not in fields:
            fail("Filter field unavailable")
        col = Record.values[name].as_string()
        if fields[name].kind in NUMERIC:
            from decimal import Decimal, InvalidOperation

            try:
                value = Decimal(str(value))
            except InvalidOperation:
                fail("Numeric filter value required")
            col = db.cast(col, db.Numeric(30, 6))
        if op == "eq":
            q = q.filter(col == value)
        elif op == "ne":
            q = q.filter(col != value)
        elif op == "gt":
            q = q.filter(col > value)
        elif op == "lt":
            q = q.filter(col < value)
        else:
            fail("Unsupported filter operator")
    sort = request.args.get("sort", settings.get("sort", "created_at"))
    direction = request.args.get("direction", settings.get("direction", "desc"))
    if sort in ("created_at", "updated_at"):
        col = getattr(Record, sort)
    elif sort in fields:
        col = Record.values[sort].as_string()
        if fields[sort].kind in NUMERIC:
            col = db.cast(col, db.Numeric(30, 6))
    else:
        fail("Sort field unavailable")
    return q.order_by(col.desc() if direction == "desc" else col.asc(), Record.id)


@bp.get("/modules/<name>/records")
@login_required
def records(name):
    m = module_by_name(name)
    if m.settings.get("api_enabled") is False and g.bearer:
        fail("Module API access disabled", 403)
    v = None
    if request.args.get("view_id"):
        v = get(View, request.args["view_id"])
        if v.module_id != m.id:
            fail("View belongs to a different module")
    return paged(
        filtered_query(m, settings=v.settings if v else {}), lambda r: serialize(r, m)
    )


@bp.post("/modules/<name>/records")
@login_required
def create_record(name):
    m = module_by_name(name)
    require(m, "create")
    d = body()
    if m.settings.get("api_enabled") is False and g.bearer:
        fail("Module API access disabled", 403)
    r = Record(id=uid(), module_id=m.id, owner_id=g.user.id)
    values = validate_values(m, d.get("values", {}))
    r.values = store_documents(m, values, values, r.id)
    db.session.add(r)
    db.session.flush()
    audit("record.created", r.id, module=m.name)
    emit("record.created", r)
    db.session.commit()
    return ok(serialize(r, m), 201)


@bp.get("/records/<id>")
@login_required
def record(id):
    r, m = record_context(id)
    return ok(serialize(r, m))


@bp.patch("/records/<id>")
@login_required
def update_record(id):
    r, m = record_context(id, "update")
    d = body()
    if d.get("version") != r.version:
        fail("This record changed. Reload before saving.", 409, "version_conflict")
    values = validate_values(m, d.get("values", {}), r.values)
    r.values = store_documents(m, values, d.get("values", {}), r.id)
    db.session.flush()
    audit("record.updated", r.id, module=m.name)
    emit("record.updated", r)
    db.session.commit()
    return ok(serialize(r, m))


@bp.delete("/records/<id>")
@login_required
def delete_record(id):
    r, m = record_context(id, "delete")
    if request.headers.get("If-Match") != str(r.version):
        fail("If-Match must contain the current record version", 409)
    if (
        Link.query.filter(or_(Link.source_id == id, Link.target_id == id)).first()
        or File.query.filter_by(record_id=id).first()
    ):
        fail("Unlink related records and remove attachments first", 409)
    Share.query.filter_by(record_id=id).delete()
    audit("record.deleted", id, module=m.name)
    emit("record.deleted", r)
    db.session.delete(r)
    db.session.commit()
    return ok()


@bp.get("/records/<id>/documents/<field_name>")
@login_required
def document(id, field_name):
    r, m = record_context(id)
    f = next((f for f in m.fields if f.name == field_name), None)
    if not f or f.kind != "json" or not field_allowed(m, f, "read"):
        fail("Document not found", 404)
    ref = r.values.get(field_name) or {}
    client = current_app.extensions.get("mongo")
    if client is None:
        fail("MongoDB unavailable", 503)
    doc = client.get_default_database()["record_documents"].find_one(
        {"_id": ref.get("document_id"), "record_id": id, "field_id": f.id}
    )
    if not doc:
        fail("Document not found", 404)
    return ok(doc["payload"])


@bp.get("/records/<id>/links")
@login_required
def links(id):
    r, m = record_context(id)
    result = []
    for link in Link.query.filter(
        or_(Link.source_id == id, Link.target_id == id)
    ).all():
        other = get(Record, link.target_id if link.source_id == id else link.source_id)
        mod = get(Module, other.module_id)
        if allowed(mod, "read", other):
            result.append(
                {
                    "id": link.id,
                    "relationship_id": link.relationship_id,
                    "record": serialize(other, mod),
                    "module": mod.label,
                }
            )
    return ok(result)


@bp.post("/links")
@login_required
def create_link():
    d = body()
    rel = get(Relationship, d.get("relationship_id"))
    source, sm = record_context(d.get("source_id"), "update")
    target, tm = record_context(d.get("target_id"), "update")
    if (
        source.module_id != rel.source_module_id
        or target.module_id != rel.target_module_id
    ):
        fail("Relationship endpoint modules do not match")
    link = Link(
        relationship_id=rel.id,
        source_id=source.id,
        target_id=target.id,
        source_slot=(
            rel.id + ":" + source.id
            if rel.cardinality in ("one_to_one", "many_to_one")
            else None
        ),
        target_slot=(
            rel.id + ":" + target.id
            if rel.cardinality in ("one_to_one", "one_to_many")
            else None
        ),
    )
    db.session.add(link)
    db.session.flush()
    audit("record.linked", source.id, relationship=rel.id)
    db.session.commit()
    return ok({"id": link.id}, 201)


@bp.delete("/links/<id>")
@login_required
def delete_link(id):
    link = get(Link, id)
    record_context(link.source_id, "update")
    record_context(link.target_id, "update")
    db.session.delete(link)
    audit("record.unlinked", id)
    db.session.commit()
    return ok()


@bp.post("/records/<id>/shares")
@login_required
def share(id):
    r, m = record_context(id, "share")
    d = body()
    get(User, d.get("user_id"))
    actions = d.get("actions", ["read"])
    if not isinstance(actions, list) or set(actions) - {
        "read",
        "update",
        "attach",
        "export",
    }:
        fail("Invalid share actions")
    s = Share.query.filter_by(record_id=id, user_id=d["user_id"]).first()
    if not s:
        s = Share(record_id=id, user_id=d["user_id"])
        db.session.add(s)
    s.actions = actions
    audit("record.shared", id)
    db.session.commit()
    return ok()


@bp.get("/modules/<name>/export")
@login_required
def export(name):
    m = module_by_name(name)
    require(m, "read")
    q = filtered_query(m, "export")
    rows = q.limit(10001).all()
    if len(rows) > 10000:
        fail("Filter export to 10,000 records or fewer")
    fields = [
        f
        for f in m.fields
        if field_allowed(m, f, "read") and f.kind not in ("secret", "json", "formula")
    ]
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["id"] + [f.name for f in fields])

    def safe(v):
        text = "" if v is None else str(v)
        return (
            "'" + text
            if text.lstrip().startswith(("=", "+", "-", "@", "\t", "\r"))
            else text
        )

    for r in rows:
        if not allowed(m, "read", r):
            continue
        writer.writerow([r.id] + [safe(r.values.get(f.name)) for f in fields])
    audit("record.exported", m.id, count=len(rows))
    db.session.commit()
    return Response(
        out.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{m.name}.csv"'},
    )


@bp.post("/modules/<name>/import")
@login_required
def import_records(name):
    m = module_by_name(name)
    require(m, "import")
    require(m, "create")
    rows = body().get("rows")
    if not isinstance(rows, list) or len(rows) > 500:
        fail("Provide at most 500 rows")
    ids = []
    for row in rows:
        r = Record(id=uid(), module_id=m.id, owner_id=g.user.id)
        values = validate_values(m, row)
        r.values = store_documents(m, values, values, r.id)
        db.session.add(r)
        db.session.flush()
        emit("record.created", r)
        audit("record.created", r.id, module=m.name)
        ids.append(r.id)
    audit("record.imported", m.id, count=len(ids))
    db.session.commit()
    return ok({"ids": ids}, 201)
