import secrets, hmac
from datetime import timedelta
import pyotp
from flask import Blueprint, g, request, current_app, make_response, jsonify
from .models import (
    db,
    User,
    Role,
    Session,
    RecoveryCode,
    ResetToken,
    Integration,
    Outbox,
    now,
)
from .common import body, ok, fail, required, audit, get, paged
from .security import *

bp = Blueprint("auth", __name__, url_prefix="/api/v1")


def user_json(u):
    return {
        "id": u.id,
        "username": u.username,
        "email": u.email,
        "active": u.active,
        "admin": u.admin,
        "mfa_enabled": bool(u.mfa_secret),
        "role_ids": [r.id for r in u.roles],
    }


def preauth_csrf():
    cookie = request.cookies.get("lifeos_pre_csrf", "")
    if not cookie or not hmac.compare_digest(
        cookie, request.headers.get("X-CSRF-Token", "")
    ):
        fail("Refresh the sign-in page and try again", 403)


@bp.get("/auth/bootstrap")
def bootstrap():
    csrf = secrets.token_urlsafe(32)
    response = make_response(
        jsonify(data={"setup_required": User.query.count() == 0, "csrf": csrf}, meta={})
    )
    response.set_cookie(
        "lifeos_pre_csrf",
        csrf,
        secure=current_app.config["COOKIE_SECURE"],
        httponly=True,
        samesite="Strict",
        max_age=1800,
    )
    return response


@bp.post("/auth/setup")
def setup():
    preauth_csrf()
    d = body()
    if User.query.count():
        fail("Setup is already complete", 409)
    expected = current_app.config.get("SETUP_TOKEN", "")
    if not expected or not hmac.compare_digest(expected, str(d.get("setup_token", ""))):
        fail("Invalid setup token", 403)
    # A fixed primary key makes concurrent bootstrap requests mutually exclusive.
    u = User(
        id="00000000-0000-0000-0000-000000000001",
        username=required(d, "username"),
        email=required(d, "email", 254),
        password_hash=hash_password(d.get("password")),
        admin=True,
    )
    db.session.add(u)
    db.session.flush()
    audit("user.bootstrap", u.id)
    db.session.commit()
    return ok(user_json(u), 201)


@bp.post("/auth/login")
def login():
    preauth_csrf()
    d = body()
    u = User.query.filter_by(username=d.get("username")).first()
    valid = verify_password(d.get("password"), u.password_hash if u else DUMMY_HASH)
    if not valid or not u or not u.active or not check_mfa(u, d.get("code")):
        audit("auth.login_failed")
        db.session.commit()
        fail("Invalid credentials or verification code", 401)
    token, s = issue_session(u)
    g.user = u
    audit("auth.login", u.id)
    db.session.commit()
    response = make_response(
        jsonify(data={"user": user_json(u), "csrf": s.csrf}, meta={})
    )
    response.set_cookie(
        "lifeos_session",
        token,
        secure=current_app.config["COOKIE_SECURE"],
        httponly=True,
        samesite="Strict",
        max_age=current_app.config["SESSION_HOURS"] * 3600,
    )
    return response


@bp.get("/auth/me")
@login_required
def me():
    return ok({"user": user_json(g.user), "csrf": g.auth_session.csrf})


@bp.post("/auth/logout")
@login_required
def logout():
    db.session.delete(g.auth_session)
    audit("auth.logout", g.user.id)
    db.session.commit()
    r = make_response(jsonify(data={"signed_out": True}, meta={}))
    r.delete_cookie("lifeos_session")
    return r


@bp.post("/auth/tokens")
@login_required
def token():
    d = body()
    if not verify_password(d.get("password"), g.user.password_hash) or not check_mfa(
        g.user, d.get("code")
    ):
        fail("Reauthentication failed", 401)
    token, s = issue_session(g.user)
    audit("auth.token_created", s.id)
    db.session.commit()
    return ok({"token": token, "expires_at": s.expires_at.isoformat()}, 201)


@bp.get("/auth/sessions")
@login_required
def sessions():
    return ok(
        [
            {
                "id": s.id,
                "created_at": s.created_at.isoformat(),
                "expires_at": s.expires_at.isoformat(),
                "current": s.id == g.auth_session.id,
            }
            for s in Session.query.filter_by(user_id=g.user.id).all()
        ]
    )


@bp.delete("/auth/sessions/<id>")
@login_required
def revoke_session(id):
    s = get(Session, id)
    if s.user_id != g.user.id:
        fail("Permission denied", 403)
    db.session.delete(s)
    audit("auth.session_revoked", id)
    db.session.commit()
    return ok()


@bp.post("/auth/mfa/setup")
@login_required
def mfa_setup():
    if not verify_password(body().get("password"), g.user.password_hash):
        fail("Reauthentication failed", 401)
    if g.user.mfa_secret:
        fail("MFA is already enabled", 409)
    secret = pyotp.random_base32()
    g.user.mfa_pending = encrypt(secret)
    db.session.commit()
    return ok(
        {
            "secret": secret,
            "uri": pyotp.TOTP(secret).provisioning_uri(
                g.user.username, issuer_name="Life OS"
            ),
        }
    )


@bp.post("/auth/mfa/confirm")
@login_required
def mfa_confirm():
    d = body()
    if not g.user.mfa_pending or not pyotp.TOTP(decrypt(g.user.mfa_pending)).verify(
        str(d.get("code", ""))
    ):
        fail("Invalid code")
    g.user.mfa_secret = g.user.mfa_pending
    g.user.mfa_pending = None
    Session.query.filter(
        Session.user_id == g.user.id, Session.id != g.auth_session.id
    ).delete()
    codes = [secrets.token_hex(10) for _ in range(10)]
    RecoveryCode.query.filter_by(user_id=g.user.id).delete()
    for code in codes:
        db.session.add(RecoveryCode(user_id=g.user.id, code_hash=digest(code)))
    audit("auth.mfa_enabled", g.user.id)
    db.session.commit()
    return ok({"recovery_codes": codes})


@bp.delete("/auth/mfa")
@login_required
def mfa_disable():
    d = body()
    if not verify_password(d.get("password"), g.user.password_hash) or not check_mfa(
        g.user, d.get("code")
    ):
        fail("Reauthentication failed", 401)
    g.user.mfa_secret = None
    g.user.mfa_pending = None
    RecoveryCode.query.filter_by(user_id=g.user.id).delete()
    Session.query.filter(
        Session.user_id == g.user.id, Session.id != g.auth_session.id
    ).delete()
    audit("auth.mfa_disabled", g.user.id)
    db.session.commit()
    return ok()


@bp.post("/auth/password")
@login_required
def change_password():
    d = body()
    if not verify_password(
        d.get("current_password"), g.user.password_hash
    ) or not check_mfa(g.user, d.get("code")):
        fail("Reauthentication failed", 401)
    g.user.password_hash = hash_password(d.get("password"))
    Session.query.filter(
        Session.user_id == g.user.id, Session.id != g.auth_session.id
    ).delete()
    audit("auth.password_changed", g.user.id)
    db.session.commit()
    return ok()


@bp.post("/auth/forgot-password")
def forgot_password():
    preauth_csrf()
    d = body()
    u = User.query.filter_by(email=d.get("email"), active=True).first()
    smtp = Integration.query.filter_by(kind="smtp", enabled=True).first()
    if u and smtp:
        token = secrets.token_urlsafe(48)
        ResetToken.query.filter_by(user_id=u.id).delete()
        db.session.add(
            ResetToken(
                user_id=u.id,
                token_hash=digest(token),
                expires_at=now() + timedelta(minutes=20),
            )
        )
        db.session.add(
            Outbox(
                integration_id=smtp.id,
                event={
                    "type": "email",
                    "private": encrypt(
                        {
                            "to": u.email,
                            "subject": "Life OS password recovery",
                            "text": "Your single-use recovery token (valid for 20 minutes): "
                            + token,
                        }
                    ),
                },
            )
        )
        audit("auth.password_reset_requested", u.id)
        db.session.commit()
    return ok(
        {
            "message": "If the account exists and email is configured, a recovery email will be sent."
        }
    )


@bp.post("/auth/reset-password")
def reset_password():
    preauth_csrf()
    d = body()
    t = (
        ResetToken.query.filter_by(token_hash=digest(str(d.get("token", ""))))
        .with_for_update()
        .first()
    )
    if not t or t.expires_at <= now():
        fail("Invalid or expired recovery token")
    u = get(User, t.user_id)
    if not check_mfa(u, d.get("code")):
        fail("MFA code or recovery code required", 401)
    u.password_hash = hash_password(d.get("password"))
    Session.query.filter_by(user_id=u.id).delete()
    db.session.delete(t)
    audit("auth.password_reset", u.id)
    db.session.commit()
    return ok()


@bp.get("/users")
@admin_required
def users():
    return paged(User.query.order_by(User.username), user_json)


@bp.post("/users")
@admin_required
def create_user():
    d = body()
    u = User(
        username=required(d, "username"),
        email=required(d, "email", 254),
        password_hash=hash_password(d.get("password")),
        admin=bool(d.get("admin", False)),
    )
    u.roles = [get(Role, id) for id in d.get("role_ids", [])]
    db.session.add(u)
    db.session.flush()
    audit("user.created", u.id)
    db.session.commit()
    return ok(user_json(u), 201)


@bp.patch("/users/<id>")
@admin_required
def update_user(id):
    u = get(User, id)
    d = body()
    if u.id == g.user.id and (d.get("active") is False or d.get("admin") is False):
        fail("You cannot disable your own administrator access")
    for k in ("username", "email"):
        if k in d:
            setattr(u, k, required(d, k, 254 if k == "email" else 120))
    for k in ("active", "admin"):
        if k in d:
            setattr(u, k, bool(d[k]))
    if "role_ids" in d:
        u.roles = [get(Role, id) for id in d["role_ids"]]
    if d.get("password"):
        u.password_hash = hash_password(d["password"])
    Session.query.filter_by(user_id=u.id).delete()
    audit("user.updated", u.id)
    db.session.commit()
    return ok(user_json(u))


@bp.delete("/users/<id>")
@admin_required
def delete_user(id):
    if id == g.user.id:
        fail("Cannot delete your own account")
    u = get(User, id)
    u.active = False
    Session.query.filter_by(user_id=id).delete()
    audit("user.disabled", id)
    db.session.commit()
    return ok({"disabled": True})


def role_json(r):
    return {"id": r.id, "name": r.name, "grants": r.grants}


def validate_grants(grants):
    if not isinstance(grants, dict):
        fail("Grants must be an object")
    for name, v in grants.items():
        if (
            not isinstance(v, dict)
            or set(v.get("actions", [])) - ACTIONS
            or v.get("scope", "own") not in ("own", "all")
        ):
            fail("Invalid permission grant")
        if not isinstance(v.get("fields", {}), dict):
            fail("Invalid field permissions")
    return grants


@bp.get("/roles")
@admin_required
def roles():
    return ok([role_json(r) for r in Role.query.all()])


@bp.post("/roles")
@admin_required
def create_role():
    d = body()
    r = Role(name=required(d, "name"), grants=validate_grants(d.get("grants", {})))
    db.session.add(r)
    db.session.flush()
    audit("role.created", r.id)
    db.session.commit()
    return ok(role_json(r), 201)


@bp.patch("/roles/<id>")
@admin_required
def update_role(id):
    d = body()
    r = get(Role, id)
    if "name" in d:
        r.name = required(d, "name")
    if "grants" in d:
        r.grants = validate_grants(d["grants"])
    audit("role.updated", id)
    db.session.commit()
    return ok(role_json(r))


@bp.delete("/roles/<id>")
@admin_required
def delete_role(id):
    r = get(Role, id)
    for u in User.query.all():
        if r in u.roles:
            u.roles.remove(r)
    db.session.delete(r)
    audit("role.deleted", id)
    db.session.commit()
    return ok()
