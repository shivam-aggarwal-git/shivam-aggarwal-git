import signal, time
from . import create_app
from .integrations import process_one
from .models import db

running = True


def stop(*_):
    global running
    running = False


signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
app = create_app()
with app.app_context():
    while running:
        try:
            if not process_one():
                time.sleep(2)
        except Exception as exc:
            db.session.rollback()
            app.logger.error("worker_error type=%s", type(exc).__name__)
            time.sleep(5)
