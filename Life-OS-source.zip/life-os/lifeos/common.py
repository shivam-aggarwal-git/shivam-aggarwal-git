import re
from flask import jsonify, request, g
from .models import db, Audit


class ApiError(Exception):
    def __init__(self, message, status=400, code="invalid_request"):
        self.message, self.status, self.code = message, status, code


def fail(message, status=400, code="invalid_request"):
    raise ApiError(message, status, code)


def body():
    v = request.get_json(silent=True)
    if not isinstance(v, dict):
        fail("A JSON object is required")
    return v


def ok(data=None, status=200, **meta):
    return jsonify(data=data, meta=meta), status


def identifier(value):
    if not isinstance(value, str) or not re.fullmatch("[a-z][a-z0-9_]{0,63}", value):
        fail("Use a lowercase identifier with letters, numbers and underscores")
    return value


def required(data, key, limit=120):
    value = data.get(key)
    if not isinstance(value, str) or not value.strip() or len(value) > limit:
        fail(f"{key} is required and must be at most {limit} characters")
    return value.strip()


def get(model, id):
    obj = db.session.get(model, id)
    if obj is None:
        fail("Not found", 404, "not_found")
    return obj


def audit(action, entity_id=None, **details):
    db.session.add(
        Audit(
            actor_id=getattr(getattr(g, "user", None), "id", None),
            action=action,
            entity_id=entity_id,
            details=details,
        )
    )


def page(query):
    try:
        p = max(1, int(request.args.get("page", 1)))
        size = min(100, max(1, int(request.args.get("per_page", 25))))
    except ValueError:
        fail("Invalid pagination")
    return query.paginate(page=p, per_page=size, error_out=False)


def paged(query, serialize):
    p = page(query)
    return ok(
        [serialize(x) for x in p.items], total=p.total, page=p.page, per_page=p.per_page
    )
