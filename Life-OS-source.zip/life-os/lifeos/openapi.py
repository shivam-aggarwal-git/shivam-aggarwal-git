"""OpenAPI route inventory with explicit write contracts for implemented APIs."""

import re
from flask import jsonify, render_template, send_from_directory


def obj(properties, required=()):
    return {"type": "object", "properties": properties, "required": list(required)}


S = {"type": "string"}
B = {"type": "boolean"}
I = {"type": "integer"}
J = {"type": "object", "additionalProperties": True}
A = {"type": "array", "items": S}
SCHEMAS = {
    "Module": obj(
        {
            "name": {"type": "string", "pattern": "^[a-z][a-z0-9_]{0,63}$"},
            "label": S,
            "plural": S,
            "description": S,
            "category": S,
            "settings": J,
        },
        ["name", "label", "plural"],
    ),
    "Field": obj(
        {
            "name": S,
            "label": S,
            "kind": {
                "type": "string",
                "enum": [
                    "text",
                    "textarea",
                    "number",
                    "decimal",
                    "currency",
                    "date",
                    "datetime",
                    "time",
                    "checkbox",
                    "radio",
                    "dropdown",
                    "multiselect",
                    "searchable",
                    "linked_record",
                    "linked_list",
                    "nested_dropdown",
                    "file",
                    "attachment",
                    "image",
                    "url",
                    "email",
                    "phone",
                    "secret",
                    "richtext",
                    "json",
                    "formula",
                ],
            },
            "scope": {
                "type": "string",
                "enum": ["module", "global", "reusable", "private", "system"],
            },
            "position": I,
            "settings": J,
            "global_id": S,
        },
        ["name", "label", "kind"],
    ),
    "View": obj(
        {
            "name": S,
            "kind": {
                "type": "string",
                "enum": ["list", "detail", "create", "edit", "related"],
            },
            "settings": J,
        },
        ["name", "kind"],
    ),
    "Relationship": obj(
        {
            "name": S,
            "source_module_id": S,
            "target_module_id": S,
            "cardinality": {
                "type": "string",
                "enum": ["one_to_one", "one_to_many", "many_to_one", "many_to_many"],
            },
        },
        ["name", "source_module_id", "target_module_id", "cardinality"],
    ),
    "RecordWrite": obj({"values": J, "version": I}, ["values"]),
    "User": obj(
        {
            "username": S,
            "email": {"type": "string", "format": "email"},
            "password": {"type": "string", "format": "password", "minLength": 12},
            "active": B,
            "admin": B,
            "role_ids": A,
        },
        ["username", "email", "password"],
    ),
    "Role": obj({"name": S, "grants": J}, ["name"]),
    "Integration": obj(
        {
            "name": S,
            "kind": {
                "type": "string",
                "enum": [
                    "n8n",
                    "webhook",
                    "rest",
                    "telegram",
                    "smtp",
                    "google_sheets",
                    "tableau",
                    "supabase",
                    "mongodb",
                    "oauth",
                ],
            },
            "enabled": B,
            "settings": J,
            "secrets": {
                "type": "object",
                "writeOnly": True,
                "additionalProperties": {"type": "string"},
            },
        },
        ["name", "kind"],
    ),
    "Report": obj({"name": S, "module_id": S, "settings": J}, ["name", "module_id"]),
    "Journal": obj(
        {
            "reference": S,
            "currency": {"type": "string", "minLength": 3, "maxLength": 3},
            "lines": {
                "type": "array",
                "minItems": 2,
                "maxItems": 100,
                "items": obj(
                    {"account_id": S, "debit": S, "credit": S}, ["account_id"]
                ),
            },
        },
        ["reference", "currency", "lines"],
    ),
    "Envelope": obj({"data": {}, "meta": J}),
    "Error": obj(
        {"error": obj({"code": S, "message": S}, ["code", "message"])}, ["error"]
    ),
}
WRITE = {
    "auth.setup": obj(
        {"setup_token": S, "username": S, "email": S, "password": S},
        ["setup_token", "username", "email", "password"],
    ),
    "auth.login": obj(
        {"username": S, "password": S, "code": S}, ["username", "password"]
    ),
    "auth.token": obj({"password": S, "code": S}, ["password"]),
    "auth.mfa_setup": obj({"password": S}, ["password"]),
    "auth.mfa_confirm": obj({"code": S}, ["code"]),
    "auth.mfa_disable": obj({"password": S, "code": S}, ["password", "code"]),
    "auth.change_password": obj(
        {"current_password": S, "password": S, "code": S},
        ["current_password", "password"],
    ),
    "auth.forgot_password": obj({"email": S}, ["email"]),
    "auth.reset_password": obj(
        {"token": S, "password": S, "code": S}, ["token", "password"]
    ),
    "metadata.layout": obj({"field_ids": A}, ["field_ids"]),
    "records.create_link": obj(
        {"relationship_id": S, "source_id": S, "target_id": S},
        ["relationship_id", "source_id", "target_id"],
    ),
    "records.share": obj({"user_id": S, "actions": A}, ["user_id", "actions"]),
    "records.import_records": obj(
        {"rows": {"type": "array", "maxItems": 500, "items": J}}, ["rows"]
    ),
    "integrations.test_integration": obj({"to": {"type": "string", "format": "email"}}),
    "integrations.inbound": obj({"event_id": S}, ["event_id"]),
    "set_settings": obj(
        {
            "application_name": S,
            "timezone": S,
            "currency": S,
            "date_format": S,
            "dashboard_report_ids": A,
        }
    ),
}
for prefix, actions, schema in [
    ("auth", ["create_user", "update_user"], "User"),
    ("auth", ["create_role", "update_role"], "Role"),
    ("metadata", ["create_module", "update_module"], "Module"),
    ("metadata", ["create_field", "update_field", "create_global"], "Field"),
    ("metadata", ["create_view", "update_view"], "View"),
    ("metadata", ["create_relationship"], "Relationship"),
    ("records", ["create_record", "update_record"], "RecordWrite"),
    ("integrations", ["create_integration", "update_integration"], "Integration"),
    ("reporting", ["create_report", "update_report"], "Report"),
    ("reporting", ["post_journal"], "Journal"),
]:
    for action in actions:
        WRITE[prefix + "." + action] = {"$ref": "#/components/schemas/" + schema}


def spec(app):
    paths = {}
    for rule in app.url_map.iter_rules():
        if not rule.rule.startswith("/api/v1"):
            continue
        path = re.sub(r"<(?:[^:>]+:)?([^>]+)>", r"{\1}", rule.rule)
        params = [
            {"name": name, "in": "path", "required": True, "schema": S}
            for name in re.findall(r"{([^}]+)}", path)
        ]
        for method in sorted(rule.methods - {"HEAD", "OPTIONS"}):
            entry = {
                "operationId": rule.endpoint.replace(".", "_") + "_" + method.lower(),
                "summary": rule.endpoint.split(".")[-1].replace("_", " ").capitalize(),
                "tags": [rule.endpoint.split(".")[0]],
                "parameters": list(params),
                "security": [{"cookieAuth": []}, {"bearerAuth": []}],
                "responses": {
                    "200": {
                        "description": "Successful operation",
                        "content": {
                            "application/json": {
                                "schema": {"$ref": "#/components/schemas/Envelope"}
                            }
                        },
                    }
                },
            }
            for status, description in [
                ("400", "Invalid input"),
                ("401", "Authentication required"),
                ("403", "Permission or CSRF denied"),
                ("404", "Resource not found"),
                ("409", "Constraint or version conflict"),
                ("429", "Rate limited"),
                ("503", "Dependency unavailable"),
            ]:
                entry["responses"][status] = {
                    "description": description,
                    "content": {
                        "application/json": {
                            "schema": {"$ref": "#/components/schemas/Error"}
                        }
                    },
                }
            if method in ("POST", "PUT", "PATCH", "DELETE"):
                entry["parameters"].append(
                    {
                        "name": "X-CSRF-Token",
                        "in": "header",
                        "required": False,
                        "schema": S,
                        "description": "Required for cookie-authenticated mutations. Obtain from /auth/me or pre-login /auth/bootstrap.",
                    }
                )
                if rule.endpoint in WRITE:
                    entry["requestBody"] = {
                        "required": True,
                        "content": {
                            "application/json": {"schema": WRITE[rule.endpoint]}
                        },
                    }
            if method == "POST":
                entry["responses"].update(
                    {
                        "201": {"description": "Created"},
                        "202": {"description": "Queued or accepted"},
                    }
                )
            if method == "PATCH":
                entry["description"] = (
                    "Only supplied properties are modified. Creation-schema required properties do not apply to PATCH, except values/version for record updates."
                )
            if rule.endpoint == "records.update_record":
                entry["description"] = (
                    "Include the current version. Stale updates return 409. Send only changed field values."
                )
            if rule.endpoint == "records.delete_record":
                entry["parameters"].append(
                    {
                        "name": "If-Match",
                        "in": "header",
                        "required": True,
                        "schema": S,
                        "description": "Current record version as a decimal integer, without quotes.",
                    }
                )
            if method == "GET" and rule.endpoint in (
                "records.records",
                "auth.users",
                "audit_logs",
                "integrations.deliveries",
                "reporting.journals",
            ):
                entry["parameters"] += [
                    {
                        "name": n,
                        "in": "query",
                        "schema": {
                            "type": "integer",
                            "minimum": 1,
                            "maximum": 100 if n == "per_page" else 1000000,
                        },
                    }
                    for n in ("page", "per_page")
                ]
            if rule.endpoint == "records.records":
                entry["parameters"] += [
                    {"name": n, "in": "query", "schema": S}
                    for n in ("q", "sort", "direction", "view_id", "filters")
                ]
            if rule.endpoint == "files.upload":
                entry["requestBody"] = {
                    "required": True,
                    "content": {
                        "multipart/form-data": {
                            "schema": obj(
                                {
                                    "file": {"type": "string", "format": "binary"},
                                    "previous_id": S,
                                },
                                ["file"],
                            )
                        }
                    },
                }
            if rule.endpoint in ("files.download", "records.export"):
                entry["responses"]["200"] = {
                    "description": "Private attachment / CSV",
                    "content": {
                        "application/octet-stream": {
                            "schema": {"type": "string", "format": "binary"}
                        }
                    },
                }
            if "/auth/" in path and any(
                x in path
                for x in (
                    "bootstrap",
                    "login",
                    "setup",
                    "forgot-password",
                    "reset-password",
                )
            ):
                entry["security"] = []
            if "/webhooks/" in path:
                entry["security"] = []
                entry["description"] = (
                    "HMAC SHA256(secret, timestamp + dot + exact request bytes). Event ID is deduplicated. Timestamp window: 300 seconds."
                )
                entry["parameters"] += [
                    {"name": n, "in": "header", "required": True, "schema": S}
                    for n in ("X-LifeOS-Timestamp", "X-LifeOS-Signature")
                ]
            paths.setdefault(path, {})[method.lower()] = entry
    return {
        "openapi": "3.0.3",
        "info": {
            "title": "Life OS API",
            "version": "1.0.0",
            "description": "Cookie clients require X-CSRF-Token on mutations. Bearer tokens expire. Metadata settings details: docs/API.md. Response payloads are dynamic; fully typed response contracts are a release gap.",
        },
        "servers": [{"url": "/"}],
        "paths": paths,
        "components": {
            "securitySchemes": {
                "cookieAuth": {
                    "type": "apiKey",
                    "in": "cookie",
                    "name": "lifeos_session",
                },
                "bearerAuth": {"type": "http", "scheme": "bearer"},
            },
            "schemas": SCHEMAS,
        },
    }


def install_openapi(app):
    @app.get("/api/openapi.json")
    def openapi():
        return jsonify(spec(app))

    @app.get("/api/docs")
    def api_docs():
        return render_template("api.html")

    @app.get("/api/swagger-assets/<path:filename>")
    def swagger_asset(filename):
        from swagger_ui_bundle import swagger_ui_path

        return send_from_directory(swagger_ui_path, filename)
