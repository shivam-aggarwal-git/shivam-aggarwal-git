from collections import defaultdict
from decimal import Decimal, InvalidOperation
from flask import Blueprint, g
from .models import *
from .common import *
from .security import *
from .records import serialize, filtered_query, record_context
from .validation import NUMERIC

bp = Blueprint("reporting", __name__, url_prefix="/api/v1")


def report_json(r):
    return {
        "id": r.id,
        "name": r.name,
        "module_id": r.module_id,
        "settings": r.settings,
    }


@bp.get("/reports")
@login_required
def reports():
    return ok(
        [report_json(r) for r in Report.query.filter_by(owner_id=g.user.id).all()]
    )


@bp.post("/reports")
@login_required
def create_report():
    d = body()
    m = get(Module, d.get("module_id"))
    require(m, "read")
    s = d.get("settings", {})
    if not isinstance(s, dict) or s.get("aggregate", "count") not in (
        "count",
        "sum",
        "avg",
        "min",
        "max",
    ):
        fail("Invalid report configuration")
    r = Report(name=required(d, "name"), owner_id=g.user.id, module_id=m.id, settings=s)
    db.session.add(r)
    db.session.flush()
    audit("report.created", r.id)
    db.session.commit()
    return ok(report_json(r), 201)


@bp.patch("/reports/<id>")
@login_required
def update_report(id):
    r = get(Report, id)
    if r.owner_id != g.user.id:
        fail("Permission denied", 403)
    d = body()
    if "name" in d:
        r.name = required(d, "name")
    if "settings" in d:
        if not isinstance(d["settings"], dict):
            fail("Invalid settings")
        r.settings = d["settings"]
    audit("report.updated", id)
    db.session.commit()
    return ok(report_json(r))


@bp.delete("/reports/<id>")
@login_required
def delete_report(id):
    r = get(Report, id)
    if r.owner_id != g.user.id:
        fail("Permission denied", 403)
    db.session.delete(r)
    audit("report.deleted", id)
    db.session.commit()
    return ok()


@bp.get("/reports/<id>/run")
@login_required
def run_report(id):
    r = get(Report, id)
    if r.owner_id != g.user.id:
        fail("Permission denied", 403)
    m = get(Module, r.module_id)
    s = r.settings
    fields = {f.name: f for f in m.fields}
    group = s.get("group_by")
    value = s.get("value_field")
    aggregate = s.get("aggregate", "count")
    if aggregate not in ("count", "sum", "avg", "min", "max"):
        fail("Invalid aggregate")
    for name in (group, value):
        if name and (
            name not in fields
            or not field_allowed(m, fields[name], "read")
            or fields[name].kind in ("secret", "json", "formula")
        ):
            fail("Report field unavailable", 403)
    if aggregate != "count" and (not value or fields[value].kind not in NUMERIC):
        fail("A numeric value field is required")
    records = filtered_query(m, settings=s).limit(10001).all()
    if len(records) > 10000:
        fail("Filter the report to 10,000 records or fewer")
    groups = defaultdict(list)
    for record in records:
        values = serialize(record, m)["values"]
        key = str(values.get(group, "Unspecified")) if group else "All records"
        if aggregate == "count":
            groups[key].append(Decimal(1))
        elif values.get(value) is not None:
            groups[key].append(Decimal(str(values[value])))
    results = []
    for key, values in groups.items():
        n = len(values)
        v = {
            "count": lambda: Decimal(n),
            "sum": lambda: sum(values),
            "avg": lambda: sum(values) / n,
            "min": lambda: min(values),
            "max": lambda: max(values),
        }[aggregate]()
        results.append({"group": key, "value": str(v), "count": n})
    results.sort(key=lambda x: x["group"])
    return ok(results, chart=s.get("chart", "bar"), aggregate=aggregate)


@bp.get("/dashboard")
@login_required
def dashboard():
    result = []
    for m in Module.query.order_by(Module.category, Module.label).all():
        if allowed(m, "read"):
            result.append(
                {
                    "module_id": m.id,
                    "name": m.name,
                    "label": m.plural,
                    "category": m.category,
                    "count": scoped_query(m).count(),
                }
            )
    return ok(
        {
            "modules": result,
            "record_count": sum(x["count"] for x in result),
            "reports": [
                report_json(r) for r in Report.query.filter_by(owner_id=g.user.id).all()
            ],
        }
    )


@bp.post("/accounting/journals")
@login_required
def post_journal():
    from .metadata import module_by_name

    m = module_by_name("accounting")
    require(m, "create")
    d = body()
    lines = d.get("lines", [])
    if not isinstance(lines, list) or not 2 <= len(lines) <= 100:
        fail("A journal needs 2–100 lines")
    currency = required(d, "currency", 3).upper()
    if len(currency) != 3 or not currency.isalpha():
        fail("Use a three-letter currency code")
    j = Journal(
        owner_id=g.user.id, reference=required(d, "reference"), currency=currency
    )
    db.session.add(j)
    db.session.flush()
    total_debit = Decimal(0)
    total_credit = Decimal(0)
    for line in lines:
        account, mod = record_context(line.get("account_id"), "update")
        if mod.name != "accounts":
            fail("Journal lines must reference the Accounts module")
        try:
            debit = Decimal(str(line.get("debit", 0)))
            credit = Decimal(str(line.get("credit", 0)))
        except InvalidOperation:
            fail("Invalid journal amount")
        if (
            not debit.is_finite()
            or not credit.is_finite()
            or min(debit, credit) < 0
            or max(debit, credit) > Decimal("1e18")
            or (debit > 0) == (credit > 0)
        ):
            fail("Each line must have one positive debit or credit")
        if debit.as_tuple().exponent < -6 or credit.as_tuple().exponent < -6:
            fail("At most six decimal places allowed")
        total_debit += debit
        total_credit += credit
        db.session.add(
            JournalLine(
                journal_id=j.id, account_id=account.id, debit=debit, credit=credit
            )
        )
    if total_debit != total_credit:
        fail("Journal debits and credits must balance")
    audit("journal.posted", j.id)
    db.session.commit()
    return ok(
        {"id": j.id, "debits": str(total_debit), "credits": str(total_credit)}, 201
    )


@bp.get("/accounting/journals")
@login_required
def journals():
    from .metadata import module_by_name

    require(module_by_name("accounting"), "read")
    return paged(
        Journal.query.filter_by(owner_id=g.user.id).order_by(Journal.created_at.desc()),
        lambda j: {
            "id": j.id,
            "reference": j.reference,
            "currency": j.currency,
            "lines": [
                {
                    "account_id": l.account_id,
                    "debit": str(l.debit),
                    "credit": str(l.credit),
                }
                for l in JournalLine.query.filter_by(journal_id=j.id).all()
            ],
        },
    )
