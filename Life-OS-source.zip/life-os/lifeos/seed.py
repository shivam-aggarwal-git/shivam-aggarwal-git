from .models import db, Module, Field, View

GROUPS = {
    "People & places": [
        "People",
        "Contacts",
        "Organizations",
        "Locations",
        "Countries",
        "States",
    ],
    "Daily life": [
        "Tasks",
        "Activities",
        "Calendar",
        "Notes",
        "Documents",
        "Subscriptions",
        "Reminders",
        "Notifications",
        "Projects",
        "Personal Goals",
    ],
    "Money": [
        "Accounts",
        "Accounting",
        "Transactions",
        "Budget",
        "Expenses",
        "Income",
        "Finance",
        "Financial Projection",
        "Financial Modelling",
        "Assets",
        "Liabilities",
        "Investments",
        "Insurance",
        "Currency",
    ],
    "Things": ["Inventory", "Books", "Vehicles", "Travel"],
}
FIELDS = {
    "people": [
        ("email", "Email", "email", {}),
        ("phone", "Phone", "phone", {}),
        ("birthday", "Birthday", "date", {}),
    ],
    "contacts": [("email", "Email", "email", {}), ("phone", "Phone", "phone", {})],
    "locations": [
        ("address", "Address", "textarea", {}),
        ("city", "City", "text", {}),
        ("pincode", "Pincode", "text", {}),
    ],
    "tasks": [
        (
            "status",
            "Status",
            "dropdown",
            {"options": ["To do", "In progress", "Done"], "default": "To do"},
        ),
        (
            "priority",
            "Priority",
            "dropdown",
            {"options": ["Low", "Medium", "High"], "default": "Medium"},
        ),
        ("due_date", "Due date", "date", {}),
    ],
    "calendar": [
        ("starts_at", "Starts at", "datetime", {}),
        ("ends_at", "Ends at", "datetime", {}),
    ],
    "notes": [("content", "Content", "richtext", {})],
    "accounts": [
        (
            "account_type",
            "Account type",
            "dropdown",
            {"options": ["Asset", "Liability", "Equity", "Income", "Expense"]},
        ),
        ("currency", "Currency", "text", {"default": "INR"}),
    ],
    "subscriptions": [
        ("amount", "Amount", "currency", {}),
        ("renewal_date", "Renewal date", "date", {}),
        ("frequency", "Frequency", "dropdown", {"options": ["Monthly", "Yearly"]}),
    ],
    "insurance": [
        ("provider", "Provider", "text", {}),
        ("premium", "Premium", "currency", {}),
        ("renewal_date", "Renewal date", "date", {}),
    ],
    "books": [
        ("author", "Author", "text", {}),
        ("status", "Status", "dropdown", {"options": ["To read", "Reading", "Read"]}),
    ],
}


def seed():
    for category, labels in GROUPS.items():
        for label in labels:
            name = label.lower().replace(" ", "_")
            if Module.query.filter_by(name=name).first():
                continue
            m = Module(
                name=name,
                label=label,
                plural=label,
                category=category,
                description="",
                settings={
                    "visible": True,
                    "searchable": True,
                    "attachments": True,
                    "api_enabled": True,
                    "icon": "grid",
                    "navigation": category,
                    "ownership": "user",
                    "auditing": True,
                },
            )
            db.session.add(m)
            db.session.flush()
            fs = [("name", "Name", "text", {"required": True})] + FIELDS.get(name, [])
            if category == "Money" and name not in FIELDS:
                fs += [
                    ("amount", "Amount", "currency", {}),
                    ("date", "Date", "date", {}),
                    ("notes", "Notes", "textarea", {}),
                ]
            if len(fs) == 1:
                fs.append(("description", "Description", "textarea", {}))
            for pos, (key, title, kind, settings) in enumerate(fs):
                db.session.add(
                    Field(
                        module_id=m.id,
                        name=key,
                        label=title,
                        kind=kind,
                        position=pos,
                        settings=settings,
                    )
                )
            db.session.add(
                View(
                    module_id=m.id,
                    name="Default",
                    kind="list",
                    settings={
                        "columns": [x[0] for x in fs[:5]],
                        "sort": "created_at",
                        "direction": "desc",
                        "page_size": 25,
                    },
                )
            )
    db.session.commit()
