"""Relational source of truth. Custom structured values stay in SQL."""

import uuid
from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.postgresql import JSONB

db = SQLAlchemy()
JSON = db.JSON().with_variant(JSONB(), "postgresql")


def uid():
    return str(uuid.uuid4())


def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(db.Model):
    __abstract__ = True
    id = db.Column(db.String(36), primary_key=True, default=uid)
    created_at = db.Column(db.DateTime, nullable=False, default=now)


user_roles = db.Table(
    "user_roles",
    db.Column("user_id", db.ForeignKey("users.id"), primary_key=True),
    db.Column("role_id", db.ForeignKey("roles.id"), primary_key=True),
)


class User(Base):
    __tablename__ = "users"
    username = db.Column(db.String(120), unique=True, nullable=False)
    email = db.Column(db.String(254), unique=True, nullable=False)
    password_hash = db.Column(db.Text, nullable=False)
    active = db.Column(db.Boolean, default=True, nullable=False)
    admin = db.Column(db.Boolean, default=False, nullable=False)
    mfa_secret = db.Column(db.Text)
    mfa_pending = db.Column(db.Text)
    mfa_last_step = db.Column(db.BigInteger, default=-1, nullable=False)
    roles = db.relationship("Role", secondary=user_roles, lazy="selectin")


class Role(Base):
    __tablename__ = "roles"
    name = db.Column(db.String(100), unique=True, nullable=False)
    grants = db.Column(JSON, default=dict, nullable=False)


class Session(Base):
    __tablename__ = "auth_sessions"
    user_id = db.Column(db.ForeignKey("users.id"), nullable=False, index=True)
    token_hash = db.Column(db.String(64), unique=True, nullable=False)
    csrf = db.Column(db.String(128), nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False, index=True)
    user = db.relationship(User)


class RecoveryCode(Base):
    __tablename__ = "recovery_codes"
    user_id = db.Column(db.ForeignKey("users.id"), nullable=False)
    code_hash = db.Column(db.String(64), unique=True, nullable=False)


class ResetToken(Base):
    __tablename__ = "password_reset_tokens"
    user_id = db.Column(db.ForeignKey("users.id"), nullable=False)
    token_hash = db.Column(db.String(64), unique=True, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)


class Module(Base):
    __tablename__ = "modules"
    name = db.Column(db.String(64), unique=True, nullable=False)
    label = db.Column(db.String(120), nullable=False)
    plural = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, default="", nullable=False)
    category = db.Column(db.String(80), default="Personal", nullable=False)
    settings = db.Column(JSON, default=dict, nullable=False)
    fields = db.relationship(
        "Field", order_by="Field.position", cascade="all,delete-orphan"
    )


class GlobalField(Base):
    __tablename__ = "global_fields"
    name = db.Column(db.String(64), unique=True, nullable=False)
    definition = db.Column(JSON, nullable=False)


class Field(Base):
    __tablename__ = "module_fields"
    module_id = db.Column(db.ForeignKey("modules.id"), nullable=False, index=True)
    global_id = db.Column(db.ForeignKey("global_fields.id"))
    name = db.Column(db.String(64), nullable=False)
    label = db.Column(db.String(120), nullable=False)
    kind = db.Column(db.String(32), nullable=False)
    scope = db.Column(db.String(20), default="module", nullable=False)
    position = db.Column(db.Integer, default=0, nullable=False)
    settings = db.Column(JSON, default=dict, nullable=False)
    __table_args__ = (db.UniqueConstraint("module_id", "name"),)


class View(Base):
    __tablename__ = "module_views"
    module_id = db.Column(db.ForeignKey("modules.id"), nullable=False, index=True)
    name = db.Column(db.String(120), nullable=False)
    kind = db.Column(db.String(24), nullable=False)
    settings = db.Column(JSON, default=dict, nullable=False)
    __table_args__ = (db.UniqueConstraint("module_id", "name", "kind"),)


class Record(Base):
    __tablename__ = "records"
    module_id = db.Column(db.ForeignKey("modules.id"), nullable=False, index=True)
    owner_id = db.Column(db.ForeignKey("users.id"), nullable=False, index=True)
    values = db.Column(JSON, default=dict, nullable=False)
    version = db.Column(db.Integer, default=1, nullable=False)
    updated_at = db.Column(db.DateTime, default=now, onupdate=now, nullable=False)
    __mapper_args__ = {"version_id_col": version}
    __table_args__ = (db.Index("ix_records_module_owner", "module_id", "owner_id"),)


class Relationship(Base):
    __tablename__ = "module_relationships"
    name = db.Column(db.String(120), unique=True, nullable=False)
    source_module_id = db.Column(db.ForeignKey("modules.id"), nullable=False)
    target_module_id = db.Column(db.ForeignKey("modules.id"), nullable=False)
    cardinality = db.Column(db.String(20), nullable=False)
    __table_args__ = (
        db.CheckConstraint(
            "cardinality IN ('one_to_one','one_to_many','many_to_one','many_to_many')"
        ),
    )


class Link(Base):
    __tablename__ = "record_links"
    relationship_id = db.Column(
        db.ForeignKey("module_relationships.id"), nullable=False, index=True
    )
    source_id = db.Column(db.ForeignKey("records.id"), nullable=False, index=True)
    target_id = db.Column(db.ForeignKey("records.id"), nullable=False, index=True)
    source_slot = db.Column(db.String(80), unique=True)
    target_slot = db.Column(db.String(80), unique=True)
    __table_args__ = (db.UniqueConstraint("relationship_id", "source_id", "target_id"),)


class Share(Base):
    __tablename__ = "record_shares"
    record_id = db.Column(db.ForeignKey("records.id"), nullable=False)
    user_id = db.Column(db.ForeignKey("users.id"), nullable=False)
    actions = db.Column(JSON, nullable=False)
    __table_args__ = (db.UniqueConstraint("record_id", "user_id"),)


class Audit(Base):
    __tablename__ = "audit_logs"
    actor_id = db.Column(db.ForeignKey("users.id"))
    action = db.Column(db.String(100), nullable=False, index=True)
    entity_id = db.Column(db.String(120))
    details = db.Column(JSON, default=dict, nullable=False)


class Integration(Base):
    __tablename__ = "integrations"
    name = db.Column(db.String(120), unique=True, nullable=False)
    kind = db.Column(db.String(32), nullable=False)
    enabled = db.Column(db.Boolean, default=False, nullable=False)
    settings = db.Column(JSON, default=dict, nullable=False)
    secrets = db.Column(db.Text, nullable=False)


class Outbox(Base):
    __tablename__ = "integration_outbox"
    integration_id = db.Column(
        db.ForeignKey("integrations.id"), nullable=False, index=True
    )
    event = db.Column(JSON, nullable=False)
    status = db.Column(db.String(20), default="pending", nullable=False, index=True)
    attempts = db.Column(db.Integer, default=0, nullable=False)
    available_at = db.Column(db.DateTime, default=now, nullable=False)
    last_error = db.Column(db.String(80))


class Inbox(Base):
    __tablename__ = "integration_inbox"
    integration_id = db.Column(db.ForeignKey("integrations.id"), nullable=False)
    event_id = db.Column(db.String(128), nullable=False)
    __table_args__ = (db.UniqueConstraint("integration_id", "event_id"),)


class File(Base):
    __tablename__ = "attachments"
    record_id = db.Column(db.ForeignKey("records.id"), nullable=False, index=True)
    owner_id = db.Column(db.ForeignKey("users.id"), nullable=False)
    filename = db.Column(db.String(255), nullable=False)
    mime = db.Column(db.String(100), nullable=False)
    size = db.Column(db.BigInteger, nullable=False)
    sha256 = db.Column(db.String(64), nullable=False)
    storage_key = db.Column(db.String(36), unique=True, nullable=False)
    version = db.Column(db.Integer, default=1, nullable=False)
    previous_id = db.Column(db.ForeignKey("attachments.id"))
    scanned = db.Column(db.Boolean, default=False, nullable=False)


class Report(Base):
    __tablename__ = "reports"
    name = db.Column(db.String(120), nullable=False)
    owner_id = db.Column(db.ForeignKey("users.id"), nullable=False)
    module_id = db.Column(db.ForeignKey("modules.id"), nullable=False)
    settings = db.Column(JSON, nullable=False)


class Setting(Base):
    __tablename__ = "system_settings"
    key = db.Column(db.String(80), unique=True, nullable=False)
    value = db.Column(JSON, nullable=False)


class Journal(Base):
    __tablename__ = "journal_entries"
    owner_id = db.Column(db.ForeignKey("users.id"), nullable=False)
    reference = db.Column(db.String(120), nullable=False)
    currency = db.Column(db.String(3), nullable=False)
    posted_at = db.Column(db.DateTime, default=now, nullable=False)


class JournalLine(Base):
    __tablename__ = "journal_lines"
    journal_id = db.Column(
        db.ForeignKey("journal_entries.id"), nullable=False, index=True
    )
    account_id = db.Column(db.ForeignKey("records.id"), nullable=False)
    debit = db.Column(db.Numeric(24, 6), nullable=False, default=0)
    credit = db.Column(db.Numeric(24, 6), nullable=False, default=0)
    __table_args__ = (
        db.CheckConstraint(
            "debit >= 0 AND credit >= 0 AND ((debit > 0 AND credit = 0) OR (credit > 0 AND debit = 0))"
        ),
    )
