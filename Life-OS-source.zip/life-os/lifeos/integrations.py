"""Connector configuration, signed inbound events and durable delivery worker."""

import hashlib, hmac, json, time, socket, ipaddress, smtplib, ssl
from urllib.parse import urlsplit
from email.message import EmailMessage
from datetime import timedelta
import requests
from flask import Blueprint, current_app, request
from .models import *
from .common import *
from .security import admin_required, encrypt, decrypt

bp = Blueprint("integrations", __name__, url_prefix="/api/v1")
KINDS = {
    "n8n",
    "webhook",
    "rest",
    "telegram",
    "smtp",
    "google_sheets",
    "tableau",
    "supabase",
    "mongodb",
    "oauth",
}
PUBLIC_KEYS = {
    "url",
    "events",
    "module_ids",
    "host",
    "port",
    "tls",
    "username",
    "sender",
    "reply_to",
    "chat_id",
    "spreadsheet_id",
    "range",
    "description",
    "site",
    "database",
    "client_id",
    "scopes",
    "auth_url",
    "token_url",
}


def integration_json(i):
    return {
        "id": i.id,
        "name": i.name,
        "kind": i.kind,
        "enabled": i.enabled,
        "settings": i.settings,
        "credentials_configured": bool(decrypt(i.secrets)),
    }


def validate_settings(d):
    s = d.get("settings", {})
    if not isinstance(s, dict) or set(s) - PUBLIC_KEYS:
        fail("Unsupported public integration setting; credentials belong in secrets")
    return s


@bp.get("/integrations")
@admin_required
def integrations():
    return ok([integration_json(i) for i in Integration.query.all()])


@bp.post("/integrations")
@admin_required
def create_integration():
    d = body()
    if d.get("kind") not in KINDS:
        fail("Unsupported integration kind")
    if not isinstance(d.get("secrets", {}), dict):
        fail("Secrets must be an object")
    i = Integration(
        name=required(d, "name"),
        kind=d["kind"],
        settings=validate_settings(d),
        secrets=encrypt(d.get("secrets", {})),
        enabled=bool(d.get("enabled", False)),
    )
    db.session.add(i)
    db.session.flush()
    audit("integration.created", i.id)
    db.session.commit()
    return ok(integration_json(i), 201)


@bp.patch("/integrations/<id>")
@admin_required
def update_integration(id):
    d = body()
    i = get(Integration, id)
    if "name" in d:
        i.name = required(d, "name")
    if "settings" in d:
        i.settings = validate_settings(d)
    if "enabled" in d:
        i.enabled = bool(d["enabled"])
    if "secrets" in d:
        if not isinstance(d["secrets"], dict):
            fail("Secrets must be an object")
        i.secrets = encrypt(d["secrets"])
    audit("integration.updated", id)
    db.session.commit()
    return ok(integration_json(i))


@bp.delete("/integrations/<id>")
@admin_required
def delete_integration(id):
    i = get(Integration, id)
    i.enabled = False
    i.secrets = encrypt({})
    audit("integration.disabled", id)
    db.session.commit()
    return ok()


@bp.post("/integrations/<id>/test")
@admin_required
def test_integration(id):
    i = get(Integration, id)
    if not i.enabled:
        fail("Enable the integration before sending a test")
    if i.kind not in ("webhook", "n8n", "rest", "telegram", "smtp", "google_sheets"):
        fail(
            "This provider requires external configuration; no test adapter is implemented",
            422,
        )
    d = body()
    event = {"type": "integration.test", "message": "Life OS connection test"}
    if i.kind == "smtp":
        event = {
            "type": "email",
            "private": encrypt(
                {
                    "to": required(d, "to", 254),
                    "subject": "Life OS test email",
                    "text": "Life OS SMTP test.",
                }
            ),
        }
    job = Outbox(integration_id=id, event=event)
    db.session.add(job)
    db.session.flush()
    audit("integration.test_queued", id)
    db.session.commit()
    return ok({"delivery_id": job.id}, 202)


@bp.get("/deliveries")
@admin_required
def deliveries():
    return paged(
        Outbox.query.order_by(Outbox.created_at.desc()),
        lambda x: {
            "id": x.id,
            "integration_id": x.integration_id,
            "status": x.status,
            "attempts": x.attempts,
            "last_error": x.last_error,
            "created_at": x.created_at.isoformat(),
        },
    )


@bp.post("/deliveries/<id>/retry")
@admin_required
def retry(id):
    job = get(Outbox, id)
    if job.status not in ("failed", "pending"):
        fail("Only failed or pending deliveries can be retried")
    job.status = "pending"
    job.attempts = 0
    job.available_at = now()
    audit("integration.delivery_retried", id)
    db.session.commit()
    return ok()


def signed(secret, timestamp, raw):
    return hmac.new(
        secret.encode(), timestamp.encode() + b"." + raw, hashlib.sha256
    ).hexdigest()


@bp.post("/webhooks/<id>")
def inbound(id):
    i = get(Integration, id)
    if not i.enabled:
        fail("Webhook unavailable", 404)
    credentials = decrypt(i.secrets)
    secret = credentials.get("webhook_secret")
    if not secret:
        fail("Webhook unavailable", 404)
    stamp = request.headers.get("X-LifeOS-Timestamp", "")
    try:
        fresh = abs(time.time() - int(stamp)) <= 300
    except ValueError:
        fresh = False
    raw = request.get_data()
    if not fresh or not hmac.compare_digest(
        signed(secret, stamp, raw), request.headers.get("X-LifeOS-Signature", "")
    ):
        fail("Invalid webhook signature", 401)
    d = body()
    event_id = required(d, "event_id", 128)
    if Inbox.query.filter_by(integration_id=id, event_id=event_id).first():
        return ok({"duplicate": True})
    db.session.add(Inbox(integration_id=id, event_id=event_id))
    audit("integration.webhook_received", id, event_id=event_id)
    db.session.commit()
    return ok({"accepted": True, "event_id": event_id}, 202)


def trusted_host(host):
    allowed = current_app.config["INTEGRATION_ALLOWED_HOSTS"]
    if not host or host.lower() not in allowed:
        raise ValueError("destination_not_allowed")
    for addr in socket.getaddrinfo(host, None):
        if not ipaddress.ip_address(addr[4][0]).is_global:
            raise ValueError("private_destination_blocked")


def endpoint(url):
    u = urlsplit(url)
    if u.scheme != "https" or u.username or u.password or u.fragment:
        raise ValueError("https_required")
    trusted_host(u.hostname)
    return url


def deliver(i, job):
    s = i.settings
    credentials = decrypt(i.secrets)
    event = job.event
    if i.kind in ("webhook", "n8n", "rest"):
        raw = json.dumps(event, separators=(",", ":")).encode()
        stamp = str(int(time.time()))
        secret = credentials.get("webhook_secret")
        if not secret:
            raise ValueError("signing_secret_required")
        headers = {
            "Content-Type": "application/json",
            "X-LifeOS-Timestamp": stamp,
            "X-LifeOS-Signature": signed(secret, stamp, raw),
            "X-LifeOS-Delivery": job.id,
        }
        if credentials.get("token"):
            headers["Authorization"] = "Bearer " + credentials["token"]
        response = requests.post(
            endpoint(s["url"]),
            data=raw,
            headers=headers,
            timeout=(5, 20),
            allow_redirects=False,
        )
    elif i.kind == "telegram":
        token = credentials["bot_token"]
        if not __import__("re").fullmatch(r"[0-9]+:[A-Za-z0-9_-]+", token):
            raise ValueError("invalid_bot_token")
        response = requests.post(
            endpoint("https://api.telegram.org/bot" + token + "/sendMessage"),
            json={
                "chat_id": s["chat_id"],
                "text": event.get("message")
                or f"Life OS: {event.get('type')} ({event.get('record_id','')})",
            },
            timeout=(5, 20),
            allow_redirects=False,
        )
    elif i.kind == "smtp":
        trusted_host(s["host"])
        port = int(s.get("port", 465))
        mode = s.get("tls", "ssl")
        if mode not in ("ssl", "starttls"):
            raise ValueError("smtp_tls_required")
        content = (
            decrypt(event["private"])
            if event.get("private")
            else {
                "to": s.get("reply_to", s["sender"]),
                "subject": "Life OS notification",
                "text": str(event.get("type")),
            }
        )
        msg = EmailMessage()
        msg["From"] = s["sender"]
        msg["To"] = content["to"]
        msg["Subject"] = content["subject"]
        if s.get("reply_to"):
            msg["Reply-To"] = s["reply_to"]
        msg.set_content(content["text"])
        context = ssl.create_default_context()
        cls = smtplib.SMTP_SSL if mode == "ssl" else smtplib.SMTP
        options = {"context": context} if mode == "ssl" else {}
        with cls(s["host"], port, timeout=20, **options) as client:
            if mode == "starttls":
                client.ehlo()
                client.starttls(context=context)
                client.ehlo()
            if s.get("username"):
                client.login(s["username"], credentials["password"])
            client.send_message(msg)
        return
    elif i.kind == "google_sheets":
        # Access token is supplied by operator; full refresh/consent lifecycle is a release gap.
        from urllib.parse import quote

        sheet = quote(s["spreadsheet_id"], safe="")
        range_ = quote(s.get("range", "Sheet1!A:C"), safe="")
        url = f"https://sheets.googleapis.com/v4/spreadsheets/{sheet}/values/{range_}:append?valueInputOption=RAW"
        response = requests.post(
            endpoint(url),
            json={"values": [[event.get("type"), event.get("record_id", ""), job.id]]},
            headers={"Authorization": "Bearer " + credentials["access_token"]},
            timeout=(5, 20),
            allow_redirects=False,
        )
    else:
        raise ValueError("adapter_not_implemented")
    if not 200 <= response.status_code < 300:
        raise ValueError("provider_rejected")


def process_one():
    # PostgreSQL locks + skip_locked allow concurrent workers. Lease handles crashes.
    job = (
        Outbox.query.filter(
            Outbox.status.in_(["pending", "processing"]), Outbox.available_at <= now()
        )
        .order_by(Outbox.created_at)
        .with_for_update(skip_locked=True)
        .first()
    )
    if not job:
        db.session.rollback()
        return False
    job.status = "processing"
    job.attempts += 1
    job.available_at = now() + timedelta(minutes=5)
    id = job.id
    db.session.commit()
    job = db.session.get(Outbox, id)
    i = db.session.get(Integration, job.integration_id)
    try:
        if not i or not i.enabled:
            raise ValueError("integration_disabled")
        deliver(i, job)
        job.status = "delivered"
        job.last_error = None
        # Erase transient reset tokens/email bodies once delivered.
        if job.event.get("private"):
            job.event = {"type": job.event.get("type"), "redacted": True}
    except Exception as exc:
        job.status = "failed" if job.attempts >= 5 else "pending"
        job.available_at = now() + timedelta(seconds=min(3600, 30 * 2**job.attempts))
        job.last_error = type(exc).__name__
    db.session.commit()
    return True
