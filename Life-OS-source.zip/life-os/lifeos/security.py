import hashlib, secrets, json, hmac, time
from datetime import timedelta
from functools import wraps
from flask import request, g, current_app
from cryptography.fernet import Fernet, MultiFernet
from argon2 import PasswordHasher
from argon2.exceptions import VerificationError
import pyotp
from sqlalchemy import or_, select
from .models import db, User, Session, RecoveryCode, Share, Record, now
from .common import fail

hasher = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=4)
DUMMY_HASH = hasher.hash(secrets.token_urlsafe(32))
ACTIONS = {
    "create",
    "read",
    "update",
    "delete",
    "export",
    "import",
    "share",
    "attach",
    "configure",
    "administer",
}


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def cipher():
    return MultiFernet(
        [Fernet(k.encode()) for k in current_app.config["ENCRYPTION_KEYS"].split(",")]
    )


def encrypt(value):
    return cipher().encrypt(json.dumps(value).encode()).decode()


def decrypt(value):
    return json.loads(cipher().decrypt(value.encode()))


def hash_password(value):
    if not isinstance(value, str) or not 12 <= len(value) <= 256:
        fail("Password must contain 12–256 characters")
    return hasher.hash(value)


def verify_password(value, hashed):
    try:
        return (
            isinstance(value, str)
            and len(value) <= 256
            and hasher.verify(hashed, value)
        )
    except VerificationError:
        return False


def load_identity():
    token = None
    g.bearer = False
    g.user = None
    g.auth_session = None
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        token = auth[7:]
        g.bearer = True
    elif request.cookies.get("lifeos_session"):
        token = request.cookies["lifeos_session"]
    if token:
        session = Session.query.filter_by(token_hash=digest(token)).first()
        if session and session.expires_at > now() and session.user.active:
            g.auth_session = session
            g.user = session.user
    if request.method not in {"GET", "HEAD", "OPTIONS"} and g.user and not g.bearer:
        if not hmac.compare_digest(
            request.headers.get("X-CSRF-Token", ""), g.auth_session.csrf
        ):
            fail("CSRF validation failed", 403)


def login_required(fn):
    @wraps(fn)
    def wrapped(*a, **kw):
        if not g.user:
            fail("Sign in required", 401, "unauthenticated")
        return fn(*a, **kw)

    return wrapped


def admin_required(fn):
    @wraps(fn)
    @login_required
    def wrapped(*a, **kw):
        if not g.user.admin:
            fail("Administrator access required", 403, "forbidden")
        return fn(*a, **kw)

    return wrapped


def grants(module, action):
    if g.user.admin:
        return [{"scope": "all", "fields": {"*": ["read", "write"]}}]
    return [
        v
        for role in g.user.roles
        for key, v in role.grants.items()
        if key in (module.name, "*") and action in v.get("actions", [])
    ]


def allowed(module, action, record=None):
    gs = grants(module, action)
    if record is None:
        return bool(gs)
    if any(x.get("scope", "own") == "all" or record.owner_id == g.user.id for x in gs):
        return True
    share = Share.query.filter_by(record_id=record.id, user_id=g.user.id).first()
    return bool(gs and share and action in share.actions)


def require(module, action, record=None):
    if not allowed(module, action, record):
        fail("Permission denied", 403, "forbidden")


def field_allowed(module, field, mode):
    if g.user.admin:
        return True
    if field.scope in ("private", "system"):
        return False
    action = "read" if mode == "read" else "update"
    gs = grants(module, action) + (grants(module, "create") if mode == "write" else [])
    return any(
        mode
        in x.get("fields", {"*": ["read", "write"]}).get(
            field.name, x.get("fields", {"*": ["read", "write"]}).get("*", [])
        )
        for x in gs
    )


def scoped_query(module, action="read"):
    require(module, action)
    q = Record.query.filter_by(module_id=module.id)
    if not any(x.get("scope", "own") == "all" for x in grants(module, action)):
        ids = [
            s.record_id
            for s in Share.query.filter_by(user_id=g.user.id).all()
            if action in s.actions
        ]
        q = q.filter(or_(Record.owner_id == g.user.id, Record.id.in_(ids)))
    return q


def check_mfa(user, code):
    if not user.mfa_secret:
        return True
    # Lock identity for single-use TOTP/recovery consumption on PostgreSQL.
    db.session.execute(
        select(User).where(User.id == user.id).with_for_update()
    ).scalar_one()
    user = db.session.get(User, user.id, populate_existing=True)
    code = str(code or "")
    step = int(time.time() // 30)
    otp = pyotp.TOTP(decrypt(user.mfa_secret))
    for offset in (0, -1, 1):
        candidate = step + offset
        if candidate > user.mfa_last_step and hmac.compare_digest(
            otp.at(candidate * 30), code
        ):
            user.mfa_last_step = candidate
            return True
    recovery = RecoveryCode.query.filter_by(
        user_id=user.id, code_hash=digest(code)
    ).first()
    if recovery:
        db.session.delete(recovery)
        return True
    return False


def issue_session(user):
    token = secrets.token_urlsafe(48)
    s = Session(
        user_id=user.id,
        token_hash=digest(token),
        csrf=secrets.token_urlsafe(32),
        expires_at=now() + timedelta(hours=current_app.config["SESSION_HOURS"]),
    )
    db.session.add(s)
    return token, s
