import hashlib, io, os, socket, struct
from pathlib import Path
from flask import Blueprint, request, current_app, send_file, g
from PIL import Image, UnidentifiedImageError
from werkzeug.utils import secure_filename
from .models import *
from .common import *
from .security import login_required
from .records import record_context

bp = Blueprint("files", __name__, url_prefix="/api/v1")


def file_json(f):
    return {
        "id": f.id,
        "record_id": f.record_id,
        "filename": f.filename,
        "mime": f.mime,
        "size": f.size,
        "version": f.version,
        "scanned": f.scanned,
        "sha256": f.sha256,
        "created_at": f.created_at.isoformat(),
    }


def scan(data):
    host = current_app.config.get("CLAMAV_HOST")
    if not host:
        if current_app.config["ENVIRONMENT"] == "production":
            fail("Malware scanner is required", 503)
        return False
    try:
        with socket.create_connection((host, 3310), timeout=20) as sock:
            sock.sendall(b"zINSTREAM\0")
            for start in range(0, len(data), 65536):
                chunk = data[start : start + 65536]
                sock.sendall(struct.pack("!I", len(chunk)) + chunk)
            sock.sendall(struct.pack("!I", 0))
            result = sock.recv(1024)
            if b" OK" not in result:
                fail("File rejected by malware scanner", 422)
    except OSError:
        fail("Malware scanner unavailable", 503)
    return True


@bp.get("/records/<id>/files")
@login_required
def files(id):
    record_context(id)
    return ok(
        [
            file_json(f)
            for f in File.query.filter_by(record_id=id)
            .order_by(File.created_at.desc())
            .all()
        ]
    )


@bp.post("/records/<id>/files")
@login_required
def upload(id):
    r, m = record_context(id, "attach")
    if m.settings.get("attachments", True) is False:
        fail("Attachments disabled for this module")
    part = request.files.get("file")
    if not part:
        fail("File is required")
    name = secure_filename(part.filename or "")
    if not name:
        fail("Invalid filename")
    data = part.read(current_app.config["FILE_LIMIT"] + 1)
    if not data or len(data) > current_app.config["FILE_LIMIT"]:
        fail("File is empty or exceeds the size limit", 413)
    ext = Path(name).suffix.lower()
    if ext in (".png", ".jpg", ".jpeg", ".webp"):
        try:
            with Image.open(io.BytesIO(data)) as image:
                if image.width * image.height > 25000000:
                    fail("Image dimensions too large")
                image.verify()
                mime = Image.MIME[image.format]
                if image.format not in ("PNG", "JPEG", "WEBP"):
                    fail("Unsupported image format")
        except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
            fail("Invalid image")
    elif ext == ".pdf" and data.startswith(b"%PDF-"):
        mime = "application/pdf"
    elif ext in (".txt", ".csv", ".json"):
        try:
            data.decode("utf-8")
        except UnicodeDecodeError:
            fail("Text files must use UTF-8")
        mime = {".txt": "text/plain", ".csv": "text/csv", ".json": "application/json"}[
            ext
        ]
    else:
        fail("Allowed files: PDF, PNG, JPEG, WebP, TXT, CSV and JSON")
    scanned = scan(data)
    previous = None
    if request.form.get("previous_id"):
        previous = get(File, request.form["previous_id"])
        if previous.record_id != id:
            fail("Previous version belongs to another record")
    key = uid()
    path = Path(current_app.config["UPLOAD_DIR"]) / key
    with path.open("xb") as out:
        out.write(data)
    os.chmod(path, 0o600)
    f = File(
        record_id=id,
        owner_id=g.user.id,
        filename=name[:255],
        mime=mime,
        size=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
        storage_key=key,
        scanned=scanned,
        version=previous.version + 1 if previous else 1,
        previous_id=previous.id if previous else None,
    )
    try:
        db.session.add(f)
        db.session.flush()
        audit("file.uploaded", f.id, record_id=id)
        db.session.commit()
    except Exception:
        path.unlink(missing_ok=True)
        raise
    return ok(file_json(f), 201)


@bp.get("/files/<id>/download")
@login_required
def download(id):
    f = get(File, id)
    record_context(f.record_id)
    if current_app.config["ENVIRONMENT"] == "production" and not f.scanned:
        fail("File requires malware scanning", 423)
    audit("file.downloaded", id)
    db.session.commit()
    return send_file(
        Path(current_app.config["UPLOAD_DIR"]) / f.storage_key,
        as_attachment=True,
        download_name=f.filename,
        mimetype=f.mime,
    )


@bp.delete("/files/<id>")
@login_required
def delete_file(id):
    f = get(File, id)
    record_context(f.record_id, "delete")
    if File.query.filter_by(previous_id=id).first():
        fail("Delete newer file versions first", 409)
    key = f.storage_key
    db.session.delete(f)
    audit("file.deleted", id)
    db.session.commit()
    (Path(current_app.config["UPLOAD_DIR"]) / key).unlink(missing_ok=True)
    return ok()
