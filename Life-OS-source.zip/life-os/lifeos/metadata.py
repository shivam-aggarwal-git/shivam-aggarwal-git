from flask import Blueprint, g
from .models import *
from .security import login_required, admin_required, allowed, field_allowed
from .common import *

bp = Blueprint("metadata", __name__, url_prefix="/api/v1")
KINDS = [
    "text",
    "textarea",
    "number",
    "decimal",
    "currency",
    "date",
    "datetime",
    "time",
    "checkbox",
    "radio",
    "dropdown",
    "multiselect",
    "searchable",
    "linked_record",
    "linked_list",
    "nested_dropdown",
    "file",
    "attachment",
    "image",
    "url",
    "email",
    "phone",
    "secret",
    "richtext",
    "json",
    "formula",
]


def module_json(m):
    return {
        "id": m.id,
        "name": m.name,
        "label": m.label,
        "plural": m.plural,
        "description": m.description,
        "category": m.category,
        "settings": m.settings,
    }


def field_json(f):
    return {
        "id": f.id,
        "module_id": f.module_id,
        "global_id": f.global_id,
        "name": f.name,
        "label": f.label,
        "kind": f.kind,
        "scope": f.scope,
        "position": f.position,
        "settings": f.settings,
    }


def view_json(v):
    return {
        "id": v.id,
        "module_id": v.module_id,
        "name": v.name,
        "kind": v.kind,
        "settings": v.settings,
    }


def relationship_json(r):
    return {
        "id": r.id,
        "name": r.name,
        "source_module_id": r.source_module_id,
        "target_module_id": r.target_module_id,
        "cardinality": r.cardinality,
    }


def module_by_name(name):
    m = Module.query.filter_by(name=name).first()
    if not m:
        fail("Module not found", 404)
    return m


def check_settings(value):
    if not isinstance(value, dict):
        fail("Settings must be a JSON object")
    import json

    if len(json.dumps(value)) > 65536:
        fail("Settings exceed size limit")
    return value


@bp.get("/field-types")
@login_required
def field_types():
    return ok(KINDS)


@bp.get("/modules")
@login_required
def modules():
    return ok(
        [
            module_json(m)
            for m in Module.query.order_by(Module.category, Module.label).all()
            if allowed(m, "read") or g.user.admin
        ]
    )


@bp.post("/modules")
@admin_required
def create_module():
    d = body()
    m = Module(
        name=identifier(d.get("name")),
        label=required(d, "label"),
        plural=required(d, "plural"),
        description=d.get("description", ""),
        category=d.get("category", "Personal"),
        settings=check_settings(d.get("settings", {})),
    )
    db.session.add(m)
    db.session.flush()
    db.session.add(
        Field(
            module_id=m.id,
            name="name",
            label="Name",
            kind="text",
            settings={"required": True},
            position=0,
        )
    )
    db.session.add(
        View(
            module_id=m.id,
            name="Default",
            kind="list",
            settings={
                "columns": ["name"],
                "sort": "created_at",
                "direction": "desc",
                "page_size": 25,
            },
        )
    )
    audit("module.created", m.id)
    db.session.commit()
    return ok(module_json(m), 201)


@bp.patch("/modules/<id>")
@admin_required
def update_module(id):
    m = get(Module, id)
    d = body()
    if "name" in d and d["name"] != m.name:
        fail("Internal identifier is immutable")
    for k in ("label", "plural", "description", "category"):
        if k in d:
            setattr(m, k, required(d, k, 2000 if k == "description" else 120))
    if "settings" in d:
        m.settings = check_settings(d["settings"])
    audit("module.updated", id)
    db.session.commit()
    return ok(module_json(m))


@bp.delete("/modules/<id>")
@admin_required
def delete_module(id):
    m = get(Module, id)
    if Record.query.filter_by(module_id=id).first():
        fail("Module contains records; export and remove records first", 409)
    View.query.filter_by(module_id=id).delete()
    db.session.delete(m)
    audit("module.deleted", id)
    db.session.commit()
    return ok()


@bp.get("/modules/<name>/schema")
@login_required
def schema(name):
    m = module_by_name(name)
    if not allowed(m, "read"):
        fail("Permission denied", 403)
    return ok(
        {
            "module": module_json(m),
            "fields": [field_json(f) for f in m.fields if field_allowed(m, f, "read")],
            "views": [view_json(v) for v in View.query.filter_by(module_id=m.id).all()],
            "actions": [
                a
                for a in [
                    "create",
                    "read",
                    "update",
                    "delete",
                    "export",
                    "import",
                    "share",
                    "attach",
                    "configure",
                ]
                if allowed(m, a)
            ],
        }
    )


def field_from(d, module_id):
    if d.get("kind") not in KINDS:
        fail("Invalid field type")
    if d.get("scope", "module") not in (
        "module",
        "global",
        "reusable",
        "private",
        "system",
    ):
        fail("Invalid field scope")
    s = check_settings(d.get("settings", {}))
    if d.get("kind") == "secret" and "default" in s:
        fail("Secret fields cannot have public defaults")
    if "regex" in s:
        import regex

        try:
            regex.compile(s["regex"])
        except Exception:
            fail("Invalid regular expression")
    return Field(
        module_id=module_id,
        name=identifier(d.get("name")),
        label=required(d, "label"),
        kind=d["kind"],
        scope=d.get("scope", "module"),
        position=int(d.get("position", 0)),
        settings=s,
    )


@bp.post("/modules/<name>/fields")
@admin_required
def create_field(name):
    m = module_by_name(name)
    d = body()
    if d.get("global_id"):
        glob = get(GlobalField, d["global_id"])
        d = {
            **glob.definition,
            "name": glob.name,
            "scope": "global",
            "position": d.get("position", len(m.fields)),
        }
        f = field_from(d, m.id)
        f.global_id = glob.id
    else:
        f = field_from(d, m.id)
    db.session.add(f)
    db.session.flush()
    audit("field.created", f.id)
    db.session.commit()
    return ok(field_json(f), 201)


@bp.patch("/fields/<id>")
@admin_required
def update_field(id):
    f = get(Field, id)
    d = body()
    if d.get("name", f.name) != f.name or d.get("kind", f.kind) != f.kind:
        fail("Field name/type changes require a data migration")
    if "label" in d:
        f.label = required(d, "label")
    if "position" in d:
        f.position = int(d["position"])
    if "settings" in d:
        candidate = field_from({**field_json(f), **d}, f.module_id)
        f.settings = candidate.settings
    audit("field.updated", id)
    db.session.commit()
    return ok(field_json(f))


@bp.delete("/fields/<id>")
@admin_required
def delete_field(id):
    f = get(Field, id)
    if f.scope == "system":
        fail("System field cannot be deleted")
    if Record.query.filter_by(module_id=f.module_id).first():
        fail(
            "Archive the field by setting visible=false; deleting populated schema requires a migration",
            409,
        )
    db.session.delete(f)
    audit("field.deleted", id)
    db.session.commit()
    return ok()


@bp.put("/modules/<name>/form-layout")
@admin_required
def layout(name):
    m = module_by_name(name)
    ids = body().get("field_ids", [])
    if len(ids) != len(set(ids)) or set(ids) != {f.id for f in m.fields}:
        fail("Layout must contain each field exactly once")
    for f in m.fields:
        f.position = ids.index(f.id)
    audit("form.reordered", m.id)
    db.session.commit()
    return ok()


@bp.get("/global-fields")
@admin_required
def global_fields():
    return ok(
        [
            {"id": f.id, "name": f.name, "definition": f.definition}
            for f in GlobalField.query.all()
        ]
    )


@bp.post("/global-fields")
@admin_required
def create_global():
    d = body()
    field_from(d, None)
    f = GlobalField(name=identifier(d["name"]), definition=d)
    db.session.add(f)
    db.session.flush()
    audit("global_field.created", f.id)
    db.session.commit()
    return ok({"id": f.id, "name": f.name, "definition": f.definition}, 201)


@bp.get("/relationships")
@login_required
def relationships():
    return ok(
        [
            relationship_json(r)
            for r in Relationship.query.all()
            if allowed(get(Module, r.source_module_id), "read")
            and allowed(get(Module, r.target_module_id), "read")
        ]
    )


@bp.post("/relationships")
@admin_required
def create_relationship():
    d = body()
    get(Module, d.get("source_module_id"))
    get(Module, d.get("target_module_id"))
    if d.get("cardinality") not in (
        "one_to_one",
        "one_to_many",
        "many_to_one",
        "many_to_many",
    ):
        fail("Invalid cardinality")
    r = Relationship(
        name=required(d, "name"),
        source_module_id=d["source_module_id"],
        target_module_id=d["target_module_id"],
        cardinality=d["cardinality"],
    )
    db.session.add(r)
    db.session.flush()
    audit("relationship.created", r.id)
    db.session.commit()
    return ok(relationship_json(r), 201)


@bp.delete("/relationships/<id>")
@admin_required
def delete_relationship(id):
    r = get(Relationship, id)
    if Link.query.filter_by(relationship_id=id).first():
        fail("Unlink records before removing this relationship", 409)
    db.session.delete(r)
    audit("relationship.deleted", id)
    db.session.commit()
    return ok()


@bp.post("/modules/<name>/views")
@admin_required
def create_view(name):
    d = body()
    m = module_by_name(name)
    if d.get("kind") not in ("list", "detail", "create", "edit", "related"):
        fail("Invalid view kind")
    v = View(
        module_id=m.id,
        name=required(d, "name"),
        kind=d["kind"],
        settings=check_settings(d.get("settings", {})),
    )
    db.session.add(v)
    db.session.flush()
    audit("view.created", v.id)
    db.session.commit()
    return ok(view_json(v), 201)


@bp.patch("/views/<id>")
@admin_required
def update_view(id):
    v = get(View, id)
    d = body()
    if "name" in d:
        v.name = required(d, "name")
    if "settings" in d:
        v.settings = check_settings(d["settings"])
    audit("view.updated", id)
    db.session.commit()
    return ok(view_json(v))


@bp.delete("/views/<id>")
@admin_required
def delete_view(id):
    db.session.delete(get(View, id))
    audit("view.deleted", id)
    db.session.commit()
    return ok()
