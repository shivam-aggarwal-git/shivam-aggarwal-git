const $ = (s, p = document) => p.querySelector(s),
  $$ = (s, p = document) => [...p.querySelectorAll(s)];
const esc = (v) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const state = { user: null, csrf: "", modules: [], schema: null };
const labels = {
  text: "Text",
  textarea: "Text area",
  number: "Whole number",
  decimal: "Decimal",
  currency: "Currency",
  date: "Date",
  datetime: "Date & time",
  time: "Time",
  checkbox: "Checkbox",
  radio: "Radio group",
  dropdown: "Dropdown",
  multiselect: "Multiple choice",
  searchable: "Searchable list",
  linked_record: "Linked record",
  linked_list: "Linked list",
  nested_dropdown: "Nested dropdown",
  file: "File upload",
  attachment: "Attachment",
  image: "Image",
  url: "URL",
  email: "Email",
  phone: "Phone",
  secret: "Secret",
  richtext: "Rich text",
  json: "JSON document",
  formula: "Calculated field",
};
async function api(path, options = {}) {
  const headers = { ...options.headers };
  if (!(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
    if (options.body !== undefined) options.body = JSON.stringify(options.body);
  }
  if (state.csrf) headers["X-CSRF-Token"] = state.csrf;
  const r = await fetch("/api/v1" + path, {
    ...options,
    headers,
    credentials: "same-origin",
  });
  let d;
  try {
    d = await r.json();
  } catch {
    throw Error("Unexpected response from server");
  }
  if (!r.ok) throw Error(d.error?.message || "Request failed");
  return d;
}
function toast(text) {
  $("#toast").textContent = text;
  $("#toast").style.display = "block";
  setTimeout(() => ($("#toast").style.display = "none"), 4000);
}
function error(el, e) {
  const node = $(".error", el) || el;
  node.textContent = e.message || e;
}
function closeModal() {
  $("#modal").close();
}
function modal(title, html, bind) {
  $("#modal-content").innerHTML =
    `<div class="modal-head"><h2>${esc(title)}</h2><button type="button" class="close" aria-label="Close">×</button></div>${html}`;
  $(".close", $("#modal")).onclick = closeModal;
  $("#modal").showModal();
  bind?.($("#modal-content"));
}
const field = (name, label, type = "text", value = "", help = "") =>
  `<div class="field"><label for="f-${esc(name)}">${esc(label)}</label><input id="f-${esc(name)}" name="${esc(name)}" type="${type}" value="${esc(value)}">${help ? `<div class="help">${esc(help)}</div>` : ""}</div>`;
const select = (name, label, options, value = "") =>
  `<div class="field"><label for="f-${esc(name)}">${esc(label)}</label><select id="f-${esc(name)}" name="${esc(name)}">${options
    .map((o) => {
      const [v, t] = Array.isArray(o) ? o : [o, o];
      return `<option value="${esc(v)}" ${v === value ? "selected" : ""}>${esc(t)}</option>`;
    })
    .join("")}</select></div>`;
const check = (name, label, checked = false) =>
  `<div class="field"><label class="check-label"><input type="checkbox" name="${esc(name)}" ${checked ? "checked" : ""}>${esc(label)}</label></div>`;
const textArea = (name, label, value = "", code = false) =>
  `<div class="field"><label for="f-${esc(name)}">${esc(label)}</label><textarea class="${code ? "code" : ""}" id="f-${esc(name)}" name="${esc(name)}">${esc(typeof value === "string" ? value : JSON.stringify(value, null, 2))}</textarea></div>`;
const actions = (label = "Save") =>
  `<div class="error" role="alert"></div><div class="actions"><button type="button" class="cancel">Cancel</button><button class="primary" type="submit">${esc(label)}</button></div>`;
function formValues(form) {
  return Object.fromEntries(new FormData(form));
}
function parse(value, defaultValue = {}) {
  if (!value.trim()) return defaultValue;
  try {
    return JSON.parse(value);
  } catch {
    throw Error("Please enter valid JSON");
  }
}
function bindForm(root, fn) {
  const form = $("form", root);
  $(".cancel", form)?.addEventListener("click", closeModal);
  form.onsubmit = async (e) => {
    e.preventDefault();
    const button = $("button[type=submit]", form);
    button.disabled = true;
    try {
      await fn(form, formValues(form));
    } catch (e) {
      error(form, e);
    } finally {
      button.disabled = false;
    }
  };
}
function heading(title, sub = "", action = "") {
  return `<div class="page-head"><div><div class="eyebrow">Your personal workspace</div><h1>${esc(title)}</h1>${sub ? `<p>${esc(sub)}</p>` : ""}</div>${action}</div>`;
}
function table(columns, rows) {
  return `<div class="table-wrap"><table><thead><tr>${columns.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table>${!rows.length ? '<div class="empty"><h2>Nothing here yet</h2><p>Create your first item to get started.</p></div>' : ""}</div>`;
}
async function bootstrap() {
  try {
    const res = await api("/auth/me");
    state.user = res.data.user;
    state.csrf = res.data.csrf;
    await shell();
  } catch {
    await authScreen();
  }
}
async function authScreen(mode = "login") {
  const { data } = await api("/auth/bootstrap");
  state.csrf = data.csrf;
  if (data.setup_required) mode = "setup";
  const titles = {
    login: "Welcome back",
    setup: "Create your Life OS",
    forgot: "Recover your account",
    reset: "Set a new password",
  };
  $("#app").innerHTML =
    `<main class="auth"><div class="brand"><img src="/static/favicon.svg" alt="">Life OS</div><h1>${titles[mode]}</h1><p>${mode === "setup" ? "Create the first administrator account. Your setup token is in your local environment configuration." : "A private place for the details that matter."}</p><div class="panel"><form>${mode === "setup" ? field("setup_token", "Setup token", "password") : ""}${["setup", "login"].includes(mode) ? field("username", "Username") : ""}${["setup", "forgot"].includes(mode) ? field("email", "Email", "email") : ""}${mode === "reset" ? field("token", "Recovery token") : ""}${mode !== "forgot" ? field("password", mode === "reset" ? "New password" : "Password", "password", "", mode !== "login" ? "Use at least 12 characters." : "") : ""}${["login", "reset"].includes(mode) ? field("code", "Authenticator or recovery code", "text", "", "Leave blank if two-step verification is off.") : ""}<div class="error" role="alert"></div><button class="primary" type="submit">${{ login: "Sign in", setup: "Create administrator", forgot: "Send recovery email", reset: "Reset password" }[mode]}</button></form></div><div class="links"><a href="#" id="auth-login">Sign in</a><a href="#" id="auth-forgot">Forgot password?</a><a href="#" id="auth-reset">Use recovery token</a></div></main>`;
  for (const target of ["login", "forgot", "reset"])
    $("#auth-" + target).onclick = (e) => {
      e.preventDefault();
      authScreen(target);
    };
  bindForm($("#app"), async (form, d) => {
    const route = {
      login: "login",
      setup: "setup",
      forgot: "forgot-password",
      reset: "reset-password",
    }[mode];
    const result = await api("/auth/" + route, { method: "POST", body: d });
    if (mode === "login") {
      state.user = result.data.user;
      state.csrf = result.data.csrf;
      await shell();
    } else {
      toast(result.data?.message || "Saved. You can sign in now.");
      await authScreen("login");
    }
  });
}
async function shell() {
  state.modules = (await api("/modules")).data;
  $("#app").innerHTML =
    `<div class="shell"><aside class="sidebar"><div class="brand"><img src="/static/favicon.svg" alt=""> <div>Life OS<small>PERSONAL WORKSPACE</small></div></div><a class="nav-link" href="#dashboard">◈ &nbsp; Overview</a><a class="nav-link" href="#reports">▥ &nbsp; Reports & charts</a>${[
      ...new Set(state.modules.map((m) => m.category)),
    ]
      .map(
        (c) =>
          `<div class="nav-title">${esc(c)}</div>${state.modules
            .filter((m) => m.category === c && m.settings.visible !== false)
            .map(
              (m) =>
                `<a class="nav-link" href="#module/${esc(m.name)}">${esc(m.plural)}</a>`,
            )
            .join("")}`,
      )
      .join(
        "",
      )}${state.user.admin ? `<div class="nav-title">Workspace settings</div><a class="nav-link" href="#builder">Module & form builders</a><a class="nav-link" href="#relationships">Relationships</a><a class="nav-link" href="#users">Users & roles</a><a class="nav-link" href="#integrations">Integrations & automation</a><a class="nav-link" href="#audit">Audit trail</a><a class="nav-link" href="#settings">Settings & health</a>` : ""}<div class="nav-title">Account</div><a class="nav-link" href="#security">Security & sessions</a><a class="nav-link" href="/api/docs" target="_blank" rel="noopener">API documentation ↗</a></aside><main class="main"><header class="topbar"><button class="menu-toggle" aria-label="Toggle navigation">☰</button><p>Life OS / <span id="breadcrumb">Overview</span></p><div class="top-actions"><span class="badge">Private workspace</span><span class="avatar">${esc(state.user.username[0].toUpperCase())}</span><span class="user-name">${esc(state.user.username)}</span><button id="logout" class="subtle">Sign out</button></div></header><div id="content"></div></main></div>`;
  $(".menu-toggle").onclick = () => $(".sidebar").classList.toggle("open");
  $("#logout").onclick = async () => {
    await api("/auth/logout", { method: "POST" });
    state.user = null;
    location.hash = "";
    authScreen();
  };
  await route();
}
window.addEventListener("hashchange", () => {
  if (state.user) route();
});
async function route() {
  const [page = "dashboard", arg] = location.hash.slice(1).split("/");
  const content = $("#content");
  if (!content) return;
  $$(".nav-link").forEach((a) =>
    a.classList.toggle("active", a.hash === location.hash),
  );
  $(".sidebar").classList.remove("open");
  $("#breadcrumb").textContent =
    page === "module"
      ? state.modules.find((m) => m.name === arg)?.plural || arg
      : page;
  content.innerHTML = "<p>Loading…</p>";
  try {
    if (page === "dashboard") await dashboard();
    else if (page === "module") await modulePage(arg);
    else if (page === "record") await detail(arg);
    else if (page === "builder") await builder(arg);
    else if (page === "relationships") await relationships();
    else if (page === "users") await users();
    else if (page === "integrations") await integrations();
    else if (page === "reports") await reports();
    else if (page === "audit") await auditPage();
    else if (page === "settings") await settings();
    else if (page === "security") await security();
    else await dashboard();
  } catch (e) {
    content.innerHTML = `<div class="error">${esc(e.message)}</div>`;
  }
}
async function dashboard() {
  const { data } = await api("/dashboard");
  $("#content").innerHTML =
    heading(
      "A little more organised.",
      "Your people, plans and information, in one place.",
      state.user.admin
        ? '<button class="primary" id="new-module">＋ Create module</button>'
        : "",
    ) +
    `<div class="stats"><div class="stat"><small>Saved records</small><div class="number">${data.record_count}</div><small>Across your workspace</small></div><div class="stat"><small>Your modules</small><div class="number">${data.modules.length}</div><small>Ready to make your own</small></div><div class="stat"><small>Saved reports</small><div class="number">${data.reports.length}</div><small>Information with perspective</small></div></div><div class="page-head"><h2>Your workspace</h2><a href="#reports">View reports →</a></div><div class="grid">${data.modules.map((m) => `<a class="module-card" href="#module/${esc(m.name)}"><small>${esc(m.category)}</small><h3>${esc(m.label)}</h3><div class="count">${m.count} <small>records</small></div></a>`).join("")}</div>`;
  $("#new-module")?.addEventListener("click", () => moduleEditor());
}
async function modulePage(name, page = 1, q = "", viewId = "") {
  const schema = (await api(`/modules/${name}/schema`)).data;
  state.schema = schema;
  const listViews = schema.views.filter((v) => v.kind === "list");
  const v = listViews.find((v) => v.id === viewId) || listViews[0];
  viewId = v?.id || "";
  const query = new URLSearchParams({
    page,
    q,
    per_page: v?.settings.page_size || 25,
  });
  if (viewId) query.set("view_id", viewId);
  const res = await api(`/modules/${name}/records?${query}`);
  const fields = schema.fields.filter((f) =>
    (v?.settings.columns || schema.fields.map((x) => x.name)).includes(f.name),
  );
  fields.sort(
    (a, b) =>
      (v?.settings.columns || []).indexOf(a.name) -
      (v?.settings.columns || []).indexOf(b.name),
  );
  $("#content").innerHTML =
    heading(
      schema.module.plural,
      schema.module.description,
      `${schema.actions.includes("create") ? '<button id="new-record" class="primary">＋ Add record</button>' : ""}`,
    ) +
    `<div class="toolbar"><input id="search-records" aria-label="Search records" placeholder="Search ${esc(schema.module.plural.toLowerCase())}…" value="${esc(q)}"><button id="search-btn">Search</button><select id="view-select" aria-label="List view">${listViews.map((x) => `<option value="${x.id}" ${x.id === viewId ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>${schema.actions.includes("export") ? `<a class="button" href="/api/v1/modules/${name}/export">Export CSV</a>` : ""}${schema.actions.includes("import") ? '<button id="import-records">Import JSON</button>' : ""}${state.user.admin ? `<a class="button" href="#builder/${name}">Configure</a>` : ""}</div>` +
    table(
      [...fields.map((f) => f.label), ""],
      res.data.map(
        (r) =>
          `<tr>${fields.map((f) => `<td>${display(r.values[f.name], f.kind)}</td>`).join("")}<td><a href="#record/${r.id}">Open →</a></td></tr>`,
      ),
    ) +
    `<div class="pagination"><span>${res.meta.total} records · Page ${page}</span><button id="prev" ${page <= 1 ? "disabled" : ""}>Previous</button><button id="next" ${page * res.meta.per_page >= res.meta.total ? "disabled" : ""}>Next</button></div>`;
  $("#new-record")?.addEventListener("click", () => recordEditor(schema));
  $("#search-btn").onclick = () =>
    modulePage(name, 1, $("#search-records").value, viewId);
  $("#search-records").onkeydown = (e) => {
    if (e.key === "Enter") $("#search-btn").click();
  };
  $("#view-select").onchange = (e) => modulePage(name, 1, q, e.target.value);
  $("#prev").onclick = () => modulePage(name, page - 1, q, viewId);
  $("#next").onclick = () => modulePage(name, page + 1, q, viewId);
  $("#import-records")?.addEventListener("click", () =>
    modal(
      "Import records",
      `<p>Paste an array of field-value objects. Up to 500 records are saved together; invalid input cancels the batch.</p><form>${textArea("rows", "Records", [{ name: "Example record" }], true)}${actions("Import")}</form>`,
      (root) =>
        bindForm(root, async (f, d) => {
          await api(`/modules/${name}/import`, {
            method: "POST",
            body: { rows: parse(d.rows, []) },
          });
          closeModal();
          modulePage(name);
          toast("Records imported");
        }),
    ),
  );
}
function display(value, kind) {
  if (value === null || value === undefined)
    return '<span class="muted">—</span>';
  if (kind === "secret") return value.configured ? "••••••••" : "—";
  if (kind === "checkbox") return value ? "Yes" : "No";
  if (kind === "json") return '<span class="badge muted">Document</span>';
  return esc(typeof value === "object" ? JSON.stringify(value) : value);
}
function inputFor(f, value) {
  const s = f.settings;
  const k = f.kind;
  let html = "";
  const inputName = f.name;
  if (
    ["linked_record", "linked_list", "file", "attachment", "image"].includes(k)
  )
    return `<div class="field"><label>${esc(f.label)}</label><p class="help">Manage ${k.startsWith("linked") ? "relationships" : "attachments"} after saving this record.</p></div>`;
  if (k === "formula")
    return `<div class="field"><label>${esc(f.label)}</label><p class="help">Calculated on save: ${esc(s.formula || "0")}</p></div>`;
  if (k === "checkbox") html = check(inputName, f.label, value === true);
  else if (
    [
      "dropdown",
      "radio",
      "multiselect",
      "searchable",
      "nested_dropdown",
    ].includes(k)
  ) {
    let opts = s.options || [];
    if (k === "nested_dropdown") opts = [];
    html = select(inputName, f.label, [["", "Choose…"], ...opts], value);
    if (k === "multiselect")
      html = html
        .replace("<select ", "<select multiple ")
        .replace(
          "</select>",
          '</select><div class="help">Use Ctrl or Command to select multiple values.</div>',
        );
    if (k === "radio")
      html = `<div class="field"><label>${esc(f.label)}</label>${opts.map((o) => `<label class="check-label"><input type="radio" name="${esc(inputName)}" value="${esc(o)}" ${value === o ? "checked" : ""}>${esc(o)}</label>`).join("")}</div>`;
    if (k === "searchable")
      html =
        field(inputName, f.label, "text", value || "").replace(
          "<input ",
          '<input list="options-' + esc(inputName) + '" ',
        ) +
        `<datalist id="options-${esc(inputName)}">${opts.map((o) => `<option value="${esc(o)}">`).join("")}</datalist>`;
  } else if (["textarea", "richtext", "json"].includes(k))
    html = textArea(inputName, f.label, value ?? "", k === "json");
  else
    html = field(
      inputName,
      f.label,
      {
        number: "number",
        decimal: "number",
        currency: "number",
        datetime: "datetime-local",
        secret: "password",
        phone: "tel",
      }[k] || (["date", "time", "email", "url"].includes(k) ? k : "text"),
      k === "secret" ? "" : (value ?? ""),
    );
  return `<div class="record-field ${s.width === "full" ? "full" : ""}" data-field="${esc(f.name)}">${html}</div>`;
}
async function recordEditor(schema, record) {
  if (record) {
    record = structuredClone(record);
    for (const f of schema.fields) {
      if (f.kind === "json" && record.values[f.name]?.document_id) {
        try {
          record.values[f.name] = (
            await api(`/records/${record.id}/documents/${f.name}`)
          ).data;
        } catch (e) {
          toast(e.message);
          return;
        }
      }
    }
  }
  const kind = record ? "edit" : "create",
    view = schema.views.find((v) => v.kind === kind);
  let fs = schema.fields.filter((f) => f.settings.visible !== false);
  if (view?.settings.fields) {
    fs = fs.filter((f) => view.settings.fields.includes(f.name));
    fs.sort(
      (a, b) =>
        view.settings.fields.indexOf(a.name) -
        view.settings.fields.indexOf(b.name),
    );
  }
  modal(
    record ? "Edit record" : "Add " + schema.module.label,
    `<form><div class="form-grid">${fs.map((f) => inputFor(f, record?.values[f.name] ?? f.settings.default)).join("")}</div>${actions("Save record")}</form>`,
    (root) => {
      const form = $("form", root);
      for (const f of fs) {
        const input = form.elements[f.name];
        if (!input) continue;
        if (f.settings.read_only || f.settings.editable === false)
          input.disabled = true;
        if (["decimal", "currency"].includes(f.kind)) input.step = "any";
        if (f.settings.placeholder) input.placeholder = f.settings.placeholder;
        if (f.kind === "multiselect" && record?.values[f.name])
          $$("option", input).forEach(
            (o) => (o.selected = record.values[f.name].includes(o.value)),
          );
      }
      const conditions = () => {
        for (const f of fs) {
          const container = $(`[data-field="${f.name}"]`, form);
          if (f.settings.visible_when?.field && container) {
            const c = f.settings.visible_when;
            container.hidden =
              form.elements[c.field]?.value !== String(c.equals);
          }
          if (f.kind === "nested_dropdown") {
            const input = form.elements[f.name],
              parent = form.elements[f.settings.parent_field]?.value;
            const opts = f.settings.options_by_parent?.[parent] || [];
            const prev = input.value || record?.values[f.name];
            input.innerHTML =
              '<option value="">Choose…</option>' +
              opts
                .map(
                  (o) =>
                    `<option ${o === prev ? "selected" : ""}>${esc(o)}</option>`,
                )
                .join("");
          }
        }
      };
      form.addEventListener("change", conditions);
      conditions();
      bindForm(root, async (form, d) => {
        const values = {};
        for (const f of fs) {
          const input = form.elements[f.name];
          if (
            !input ||
            input.disabled ||
            [
              "formula",
              "linked_record",
              "linked_list",
              "file",
              "attachment",
              "image",
            ].includes(f.kind)
          )
            continue;
          if (f.kind === "secret" && !d[f.name]) continue;
          if (f.kind === "checkbox") values[f.name] = input.checked;
          else if (f.kind === "multiselect")
            values[f.name] = [...input.selectedOptions]
              .map((o) => o.value)
              .filter(Boolean);
          else if (f.kind === "json") {
            if (d[f.name]?.trim()) values[f.name] = parse(d[f.name]);
          } else values[f.name] = d[f.name] || null;
        }
        const result = await api(
          record
            ? `/records/${record.id}`
            : `/modules/${schema.module.name}/records`,
          {
            method: record ? "PATCH" : "POST",
            body: { values, ...(record ? { version: record.version } : {}) },
          },
        );
        closeModal();
        location.hash = "record/" + result.data.id;
        if (record) detail(record.id);
        toast("Record saved");
      });
    },
  );
}
async function detail(id) {
  const r = (await api("/records/" + id)).data;
  const m = state.modules.find((m) => m.id === r.module_id);
  const schema = (await api(`/modules/${m.name}/schema`)).data;
  const [files, links] = await Promise.all([
    api(`/records/${id}/files`),
    api(`/records/${id}/links`),
  ]);
  const view = schema.views.find((v) => v.kind === "detail");
  let fields = schema.fields.filter(
    (f) => !view?.settings.fields || view.settings.fields.includes(f.name),
  );
  $("#content").innerHTML =
    heading(
      r.values.name || m.label,
      `${m.plural} · Last updated ${new Date(r.updated_at + "Z").toLocaleString()}`,
      `<div class="toolbar"><a href="#module/${m.name}" class="button">Back to list</a>${schema.actions.includes("update") ? '<button id="edit-record" class="primary">Edit record</button>' : ""}</div>`,
    ) +
    `<div class="split"><div><section class="panel"><div class="details-title"><h2>Details</h2><span class="badge muted">Version ${r.version}</span></div><dl class="detail-values">${fields.map((f) => `<div><dt>${esc(f.label)}</dt><dd>${display(r.values[f.name], f.kind)}${f.kind === "json" && r.values[f.name] ? ` <button class="open-doc" data-field="${f.name}">Read</button>` : ""}</dd></div>`).join("")}</dl></section><section class="panel"><div class="details-title"><h2>Related records</h2>${schema.actions.includes("update") ? '<button id="add-link">＋ Link</button>' : ""}</div>${links.data.length ? links.data.map((l) => `<div class="toolbar"><a href="#record/${l.record.id}">${esc(l.record.values.name || l.module)}</a><span class="badge muted">${esc(l.module)}</span>${schema.actions.includes("update") ? `<button class="remove-link danger" data-id="${l.id}">Unlink</button>` : ""}</div>`).join("") : "<p>No linked records yet.</p>"}</section></div><div><section class="panel"><h2>Attachments</h2>${files.data.map((f) => `<div class="panel compact"><a href="/api/v1/files/${f.id}/download">${esc(f.filename)}</a><p>${(f.size / 1024).toFixed(1)} KB · v${f.version}</p>${schema.actions.includes("delete") ? `<button class="delete-file danger" data-id="${f.id}">Delete</button>` : ""}</div>`).join("") || "<p>No attachments yet.</p>"}${schema.actions.includes("attach") ? '<label for="upload">Upload a file</label><input type="file" id="upload" accept=".pdf,.png,.jpg,.jpeg,.webp,.txt,.csv,.json"><p class="help">Up to 10 MB. Files download privately.</p>' : ""}</section>${schema.actions.includes("share") ? '<button id="share-record">Share record</button>' : ""}${schema.actions.includes("delete") ? '<button id="delete-record" class="danger">Delete record</button>' : ""}</div></div>`;
  $("#edit-record")?.addEventListener("click", () => recordEditor(schema, r));
  $("#upload")?.addEventListener("change", async (e) => {
    try {
      const data = new FormData();
      data.append("file", e.target.files[0]);
      await api(`/records/${id}/files`, { method: "POST", body: data });
      await detail(id);
      toast("File uploaded");
    } catch (e) {
      toast(e.message);
    }
  });
  $$(".delete-file").forEach(
    (b) =>
      (b.onclick = () =>
        confirmAction("Delete this attachment?", async () => {
          await api("/files/" + b.dataset.id, { method: "DELETE" });
          detail(id);
        })),
  );
  $$(".remove-link").forEach(
    (b) =>
      (b.onclick = () =>
        confirmAction("Remove this relationship?", async () => {
          await api("/links/" + b.dataset.id, { method: "DELETE" });
          detail(id);
        })),
  );
  $("#delete-record")?.addEventListener("click", () =>
    confirmAction("Delete this record permanently?", async () => {
      await api("/records/" + id, {
        method: "DELETE",
        headers: { "If-Match": String(r.version) },
      });
      location.hash = "module/" + m.name;
    }),
  );
  $("#add-link")?.addEventListener("click", () => linkEditor(r));
  $("#share-record")?.addEventListener("click", () =>
    modal(
      "Share record",
      `<form>${field("user_id", "User ID")}${select("action", "Access", ["read", "update", "attach", "export"])}${actions("Share")}</form>`,
      (root) =>
        bindForm(root, async (f, d) => {
          await api(`/records/${id}/shares`, {
            method: "POST",
            body: { user_id: d.user_id, actions: ["read", d.action] },
          });
          closeModal();
          toast("Sharing updated");
        }),
    ),
  );
  $$(".open-doc").forEach(
    (b) =>
      (b.onclick = async () => {
        try {
          const data = (
            await api(`/records/${id}/documents/${b.dataset.field}`)
          ).data;
          modal(
            "JSON document",
            `<pre>${esc(JSON.stringify(data, null, 2))}</pre>`,
          );
        } catch (e) {
          toast(e.message);
        }
      }),
  );
}
function confirmAction(title, fn) {
  modal(
    title,
    `<p>This change will be saved immediately.</p><form>${actions("Confirm")}</form>`,
    (root) =>
      bindForm(root, async () => {
        await fn();
        closeModal();
        toast("Saved");
      }),
  );
}
async function linkEditor(record) {
  const rels = (await api("/relationships")).data.filter(
    (r) =>
      r.source_module_id === record.module_id ||
      r.target_module_id === record.module_id,
  );
  if (!rels.length) {
    toast("Create a relationship between modules first.");
    return;
  }
  modal(
    "Link a record",
    `<form>${select(
      "relationship_id",
      "Relationship",
      rels.map((r) => [r.id, r.name]),
    )}<div id="link-target"></div>${actions("Link record")}</form>`,
    (root) => {
      async function load() {
        const rel = rels.find(
          (r) => r.id === root.querySelector("[name=relationship_id]").value,
        );
        const targetId =
          rel.source_module_id === record.module_id
            ? rel.target_module_id
            : rel.source_module_id;
        const module = state.modules.find((m) => m.id === targetId);
        const rows = (await api(`/modules/${module.name}/records?per_page=100`))
          .data;
        $("#link-target", root).innerHTML = select(
          "other_id",
          "Record",
          rows.map((r) => [r.id, r.values.name || r.id]),
        );
      }
      root.querySelector("[name=relationship_id]").onchange = load;
      load();
      bindForm(root, async (f, d) => {
        const rel = rels.find((r) => r.id === d.relationship_id);
        await api("/links", {
          method: "POST",
          body: {
            relationship_id: rel.id,
            source_id:
              rel.source_module_id === record.module_id
                ? record.id
                : d.other_id,
            target_id:
              rel.source_module_id === record.module_id
                ? d.other_id
                : record.id,
          },
        });
        closeModal();
        detail(record.id);
      });
    },
  );
}
async function builder(name) {
  name = name || state.modules[0]?.name;
  if (!name) {
    moduleEditor();
    return;
  }
  const schema = (await api(`/modules/${name}/schema`)).data;
  state.schema = schema;
  $("#content").innerHTML =
    heading(
      "Build your workspace",
      "Add fields, arrange forms and choose how your information appears.",
      '<button class="primary" id="create-module">＋ New module</button>',
    ) +
    `<div class="toolbar"><select id="builder-module" aria-label="Module">${state.modules.map((m) => `<option value="${m.name}" ${m.name === name ? "selected" : ""}>${esc(m.label)}</option>`).join("")}</select><button id="module-settings">Module settings</button><a class="button" href="#module/${name}">Open records →</a></div><div class="tabs"><button class="active" data-tab="form">Form builder</button><button data-tab="fields">Field manager</button><button data-tab="views">View manager</button><button data-tab="global">Reusable fields</button></div><div id="builder-body"></div>`;
  $("#create-module").onclick = () => moduleEditor();
  $("#builder-module").onchange = (e) =>
    (location.hash = "builder/" + e.target.value);
  $("#module-settings").onclick = () => moduleEditor(schema.module);
  $$("[data-tab]").forEach(
    (b) =>
      (b.onclick = () => {
        $$("[data-tab]").forEach((x) => x.classList.toggle("active", x === b));
        draw(b.dataset.tab);
      }),
  );
  async function draw(tab) {
    const target = $("#builder-body");
    if (tab === "form") {
      target.innerHTML = `<div class="builder"><section class="panel palette"><h3>Components</h3><p class="help">Drag onto the form or click to add.</p>${Object.entries(
        labels,
      )
        .map(
          ([kind, label]) =>
            `<button draggable="true" data-kind="${kind}">＋ ${label}</button>`,
        )
        .join(
          "",
        )}</section><section><div class="toolbar"><h2>${esc(schema.module.label)} form</h2><span class="badge muted">Changes save automatically</span></div><div class="canvas" id="form-canvas">${schema.fields.map((f) => `<div class="field-block" draggable="true" data-id="${f.id}"><div><strong>${esc(f.label)}</strong>${f.settings.required ? ' <span class="badge muted">Required</span>' : ""}<div class="mini">${esc(labels[f.kind])} · ${esc(f.name)}</div><div class="field-preview"></div></div><div><button class="move-up" data-id="${f.id}" aria-label="Move ${esc(f.label)} up">↑</button><button class="edit-field" data-id="${f.id}">Edit</button></div></div>`).join("")}</div></section></div>`;
      $$("[data-kind]").forEach((b) => {
        b.onclick = () => fieldEditor(schema, null, b.dataset.kind);
        b.ondragstart = (e) =>
          e.dataTransfer.setData("component", b.dataset.kind);
      });
      $$(".field-block").forEach((b) => {
        b.ondragstart = (e) => {
          e.dataTransfer.setData("field-id", b.dataset.id);
          b.classList.add("dragging");
        };
        b.ondragend = () => b.classList.remove("dragging");
      });
      $("#form-canvas").ondragover = (e) => e.preventDefault();
      $("#form-canvas").ondrop = async (e) => {
        e.preventDefault();
        const kind = e.dataTransfer.getData("component");
        if (kind) {
          fieldEditor(schema, null, kind);
          return;
        }
        const id = e.dataTransfer.getData("field-id");
        const target = e.target.closest(".field-block");
        const ids = schema.fields.map((f) => f.id);
        if (!ids.includes(id)) return;
        ids.splice(ids.indexOf(id), 1);
        ids.splice(target ? ids.indexOf(target.dataset.id) : ids.length, 0, id);
        try {
          await api(`/modules/${name}/form-layout`, {
            method: "PUT",
            body: { field_ids: ids },
          });
          builder(name);
        } catch (e) {
          toast(e.message);
        }
      };
      $$(".move-up").forEach(
        (b) =>
          (b.onclick = async () => {
            const ids = schema.fields.map((f) => f.id),
              i = ids.indexOf(b.dataset.id);
            if (i > 0) {
              [ids[i - 1], ids[i]] = [ids[i], ids[i - 1]];
              await api(`/modules/${name}/form-layout`, {
                method: "PUT",
                body: { field_ids: ids },
              });
              builder(name);
            }
          }),
      );
      bindFields();
    } else if (tab === "fields") {
      target.innerHTML =
        `<div class="toolbar"><button class="primary" id="add-field">＋ Add field</button></div>` +
        table(
          ["Label", "Internal name", "Type", "Scope", ""],
          schema.fields.map(
            (f) =>
              `<tr><td>${esc(f.label)}</td><td>${esc(f.name)}</td><td>${esc(labels[f.kind])}</td><td>${esc(f.scope)}</td><td><button class="edit-field" data-id="${f.id}">Edit</button> <button class="remove-field danger" data-id="${f.id}">Delete</button></td></tr>`,
          ),
        );
      $("#add-field").onclick = () => fieldEditor(schema);
      bindFields();
      $$(".remove-field").forEach(
        (b) =>
          (b.onclick = () =>
            confirmAction("Delete field?", async () => {
              await api("/fields/" + b.dataset.id, { method: "DELETE" });
              builder(name);
            })),
      );
    } else if (tab === "views") {
      target.innerHTML =
        `<div class="toolbar"><button class="primary" id="add-view">＋ Add view</button></div>` +
        table(
          ["Name", "Type", "Columns / fields", ""],
          schema.views.map(
            (v) =>
              `<tr><td>${esc(v.name)}</td><td>${esc(v.kind)}</td><td>${esc((v.settings.columns || v.settings.fields || []).join(", "))}</td><td><button class="edit-view" data-id="${v.id}">Edit</button> <button class="delete-view danger" data-id="${v.id}">Delete</button></td></tr>`,
          ),
        );
      $("#add-view").onclick = () => viewEditor(schema);
      $$(".edit-view").forEach(
        (b) =>
          (b.onclick = () =>
            viewEditor(
              schema,
              schema.views.find((v) => v.id === b.dataset.id),
            )),
      );
      $$(".delete-view").forEach(
        (b) =>
          (b.onclick = () =>
            confirmAction("Delete view?", async () => {
              await api("/views/" + b.dataset.id, { method: "DELETE" });
              builder(name);
            })),
      );
    } else {
      const gs = (await api("/global-fields")).data;
      target.innerHTML =
        `<div class="toolbar"><button id="new-global" class="primary">＋ Create reusable field</button></div><p>Reusable definitions can be attached to multiple modules. Each attachment has its own layout settings.</p>` +
        table(
          ["Name", "Type", ""],
          gs.map(
            (f) =>
              `<tr><td>${esc(f.name)}</td><td>${esc(f.definition.kind)}</td><td><button class="attach-global" data-id="${f.id}">Add to ${esc(schema.module.label)}</button></td></tr>`,
          ),
        );
      $("#new-global").onclick = () => fieldEditor(schema, null, "text", true);
      $$(".attach-global").forEach(
        (b) =>
          (b.onclick = async () => {
            try {
              await api(`/modules/${name}/fields`, {
                method: "POST",
                body: {
                  global_id: b.dataset.id,
                  position: schema.fields.length,
                },
              });
              builder(name);
              toast("Reusable field added");
            } catch (e) {
              toast(e.message);
            }
          }),
      );
    }
  }
  function bindFields() {
    $$(".edit-field").forEach(
      (b) =>
        (b.onclick = () =>
          fieldEditor(
            schema,
            schema.fields.find((f) => f.id === b.dataset.id),
          )),
    );
  }
  await draw("form");
}
function moduleEditor(m) {
  const s = m?.settings || {};
  modal(
    m ? "Module settings" : "Create a module",
    `<form><div class="form-grid">${field("label", "Display name", "text", m?.label)}${field("plural", "Plural name", "text", m?.plural)}${field("name", "Internal identifier", "text", m?.name, "Lowercase letters and underscores; cannot change after creation.")}${field("category", "Category", "text", m?.category || "Personal")}${field("icon", "Icon identifier", "text", s.icon || "grid")}${field("navigation", "Navigation location", "text", s.navigation || "Personal")}</div>${textArea("description", "Description", m?.description || "")}<div class="form-grid">${check("visible", "Show in navigation", s.visible !== false)}${check("searchable", "Allow search", s.searchable !== false)}${check("attachments", "Allow attachments", s.attachments !== false)}${check("api_enabled", "Allow bearer API access", s.api_enabled !== false)}</div><p class="help">Ownership is user-based. Access is managed in Users & roles. Audit events are always enabled.</p>${actions(m ? "Save module" : "Create module")}</form>`,
    (root) => {
      if (m) root.querySelector("[name=name]").readOnly = true;
      bindForm(root, async (f, d) => {
        const settings = {
          ...s,
          icon: d.icon,
          navigation: d.navigation,
          ownership: "user",
          auditing: true,
        };
        for (const k of ["visible", "searchable", "attachments", "api_enabled"])
          settings[k] = f.elements[k].checked;
        await api(m ? "/modules/" + m.id : "/modules", {
          method: m ? "PATCH" : "POST",
          body: {
            name: d.name,
            label: d.label,
            plural: d.plural,
            description: d.description || " ",
            category: d.category,
            settings,
          },
        });
        closeModal();
        await shell();
        location.hash = "builder/" + d.name;
        toast("Module saved");
      });
    },
  );
}
function fieldEditor(schema, f, kind = "text", global = false) {
  const s = f?.settings || {};
  modal(
    global ? "Create reusable field" : f ? "Configure field" : "Add field",
    `<form><div class="form-grid">${field("label", "Label", "text", f?.label)}${field("name", "Internal name", "text", f?.name)}${select("kind", "Field type", Object.entries(labels), f?.kind || kind)}${select("scope", "Scope", ["module", "reusable", "private", "system"], f?.scope || "module")}${field("placeholder", "Placeholder", "text", s.placeholder)}${field("description", "Help text", "text", s.description)}${field("default", "Default value", "text", s.default ?? "")}${select("width", "Width", ["half", "full"], s.width || "half")}${field("min", "Minimum", "number", s.min ?? "")}${field("max", "Maximum", "number", s.max ?? "")}${field("max_length", "Maximum length", "number", s.max_length || 5000)}${field("regex", "Validation expression", "text", s.regex || "")}</div><div class="form-grid">${check("required", "Required", s.required)}${check("read_only", "Read-only", s.read_only)}${check("visible", "Visible", s.visible !== false)}</div>${textArea("options", "Options (one per line)", (s.options || []).join("\n"))}${field("formula", "Formula", "text", s.formula || "", "Example: amount * quantity. Arithmetic only; no code execution.")}${field("parent_field", "Parent field for nested dropdown", "text", s.parent_field || "")}${textArea("options_by_parent", "Nested options by parent (JSON)", s.options_by_parent || {}, true)}${textArea("visible_when", "Conditional visibility (JSON)", s.visible_when || {}, true)}<p class="help">Example visibility: {"field":"status","equals":"Active"}. Linked records and uploads are managed from the saved record. JSON fields require MongoDB.</p>${actions()}</form>`,
    (root) => {
      if (f) {
        root.querySelector("[name=name]").readOnly = true;
        root.querySelector("[name=kind]").disabled = true;
      }
      bindForm(root, async (form, d) => {
        const settings = {
          ...s,
          placeholder: d.placeholder,
          description: d.description,
          width: d.width,
          required: form.elements.required.checked,
          read_only: form.elements.read_only.checked,
          visible: form.elements.visible.checked,
          options: d.options
            .split("\n")
            .map((s) => s.trim())
            .filter(Boolean),
          options_by_parent: parse(d.options_by_parent),
          visible_when: parse(d.visible_when),
          parent_field: d.parent_field,
        };
        for (const key of ["min", "max", "max_length"]) {
          if (d[key] !== "") settings[key] = Number(d[key]);
          else delete settings[key];
        }
        if (d.default !== "") settings.default = d.default;
        else delete settings.default;
        if (d.regex) settings.regex = d.regex;
        else delete settings.regex;
        if (d.formula) settings.formula = d.formula;
        const payload = {
          name: d.name,
          label: d.label,
          kind: f?.kind || d.kind,
          scope: d.scope,
          position: f?.position ?? schema.fields.length,
          settings,
        };
        await api(
          global
            ? "/global-fields"
            : f
              ? "/fields/" + f.id
              : `/modules/${schema.module.name}/fields`,
          { method: f ? "PATCH" : "POST", body: payload },
        );
        closeModal();
        builder(schema.module.name);
        toast("Field saved");
      });
    },
  );
}
function viewEditor(schema, v) {
  const s = v?.settings || {};
  modal(
    v ? "Edit view" : "Create view",
    `<form>${field("name", "View name", "text", v?.name)}${select("kind", "View type", ["list", "detail", "create", "edit", "related"], v?.kind || "list")}${textArea("columns", "Fields in display order (one internal name per line)", (s.columns || s.fields || schema.fields.map((f) => f.name)).join("\n"))}<div class="form-grid">${select("sort", "Sort by", ["created_at", "updated_at", ...schema.fields.filter((f) => !["secret", "json", "formula"].includes(f.kind)).map((f) => f.name)], s.sort || "created_at")}${select(
      "direction",
      "Direction",
      [
        ["asc", "Ascending"],
        ["desc", "Descending"],
      ],
      s.direction || "desc",
    )}${field("page_size", "Records per page", "number", s.page_size || 25)}</div>${textArea("filters", "Default filters (JSON)", s.filters || [], true)}<p class="help">Filter example: [{"field":"status","op":"eq","value":"Active"}]. Supported operators: eq, ne, gt, lt.</p>${actions()}</form>`,
    (root) =>
      bindForm(root, async (f, d) => {
        const cols = d.columns
          .split("\n")
          .map((x) => x.trim())
          .filter(Boolean);
        if (cols.some((c) => !schema.fields.find((f) => f.name === c)))
          throw Error("One or more field names do not exist");
        const settings = {
          columns: cols,
          fields: cols,
          sort: d.sort,
          direction: d.direction,
          page_size: Math.max(1, Math.min(100, Number(d.page_size))),
          filters: parse(d.filters, []),
        };
        await api(
          v ? "/views/" + v.id : `/modules/${schema.module.name}/views`,
          {
            method: v ? "PATCH" : "POST",
            body: { name: d.name, kind: d.kind, settings },
          },
        );
        closeModal();
        builder(schema.module.name);
        toast("View saved");
      }),
  );
}
async function relationships() {
  const rows = (await api("/relationships")).data;
  const name = (id) => state.modules.find((m) => m.id === id)?.label || id;
  $("#content").innerHTML =
    heading(
      "Relationships",
      "Connect records across your workspace.",
      '<button class="primary" id="new-relationship">＋ Add relationship</button>',
    ) +
    table(
      ["Name", "From", "To", "Cardinality", ""],
      rows.map(
        (r) =>
          `<tr><td>${esc(r.name)}</td><td>${esc(name(r.source_module_id))}</td><td>${esc(name(r.target_module_id))}</td><td>${esc(r.cardinality.replaceAll("_", " "))}</td><td><button class="delete-rel danger" data-id="${r.id}">Delete</button></td></tr>`,
      ),
    );
  $("#new-relationship").onclick = () =>
    modal(
      "Create relationship",
      `<form>${field("name", "Relationship name")}${select(
        "source_module_id",
        "Source module",
        state.modules.map((m) => [m.id, m.label]),
      )}${select(
        "target_module_id",
        "Target module",
        state.modules.map((m) => [m.id, m.label]),
      )}${select("cardinality", "Cardinality", [
        ["one_to_one", "One to one"],
        ["one_to_many", "One to many"],
        ["many_to_one", "Many to one"],
        ["many_to_many", "Many to many"],
      ])}${actions()}</form>`,
      (root) =>
        bindForm(root, async (f, d) => {
          await api("/relationships", { method: "POST", body: d });
          closeModal();
          relationships();
          toast("Relationship created");
        }),
    );
  $$(".delete-rel").forEach(
    (b) =>
      (b.onclick = () =>
        confirmAction("Delete relationship definition?", async () => {
          await api("/relationships/" + b.dataset.id, { method: "DELETE" });
          relationships();
        })),
  );
}
async function users() {
  const [u, r] = await Promise.all([api("/users?per_page=100"), api("/roles")]);
  $("#content").innerHTML =
    heading(
      "Users & roles",
      "Choose who can access your workspace and what they can change.",
      '<button class="primary" id="new-user">＋ Add user</button>',
    ) +
    table(
      ["Username", "Email", "Access", "2FA", ""],
      u.data.map(
        (user) =>
          `<tr><td>${esc(user.username)}</td><td>${esc(user.email)}</td><td>${user.admin ? "Administrator" : user.active ? "Active" : "Disabled"}</td><td>${user.mfa_enabled ? "Enabled" : "Off"}</td><td><button data-user="${user.id}">Edit</button></td></tr>`,
      ),
    ) +
    `<div class="page-head"><h2>Roles</h2><button id="new-role">＋ Add role</button></div>` +
    table(
      ["Name", "Module grants", ""],
      r.data.map(
        (role) =>
          `<tr><td>${esc(role.name)}</td><td>${Object.keys(role.grants).length}</td><td><button data-role="${role.id}">Edit</button> <button data-delete-role="${role.id}" class="danger">Delete</button></td></tr>`,
      ),
    );
  $("#new-user").onclick = () => userEditor(null, r.data);
  $$("[data-user]").forEach(
    (b) =>
      (b.onclick = () =>
        userEditor(
          u.data.find((u) => u.id === b.dataset.user),
          r.data,
        )),
  );
  $("#new-role").onclick = () => roleEditor();
  $$("[data-role]").forEach(
    (b) =>
      (b.onclick = () =>
        roleEditor(r.data.find((r) => r.id === b.dataset.role))),
  );
  $$("[data-delete-role]").forEach(
    (b) =>
      (b.onclick = () =>
        confirmAction("Delete role?", async () => {
          await api("/roles/" + b.dataset.deleteRole, { method: "DELETE" });
          users();
        })),
  );
}
function userEditor(u, roles) {
  modal(
    u ? "Edit user" : "Add user",
    `<form>${field("username", "Username", "text", u?.username)}${field("email", "Email", "email", u?.email)}${field("password", u ? "New password (leave blank to keep)" : "Password", "password")}${check("admin", "Administrator", u?.admin)}${check("active", "Active", u?.active !== false)}<label>Roles</label>${roles.map((r) => check("role_" + r.id, r.name, u?.role_ids.includes(r.id))).join("")}<p class="help">Changing user access revokes existing sessions. Users manage their own two-step verification under Security.</p>${actions()}</form>`,
    (root) =>
      bindForm(root, async (f, d) => {
        const payload = {
          username: d.username,
          email: d.email,
          admin: f.elements.admin.checked,
          active: f.elements.active.checked,
          role_ids: roles
            .filter((r) => f.elements["role_" + r.id].checked)
            .map((r) => r.id),
        };
        if (d.password) payload.password = d.password;
        await api(u ? "/users/" + u.id : "/users", {
          method: u ? "PATCH" : "POST",
          body: payload,
        });
        closeModal();
        users();
        toast("User saved");
      }),
  );
}
function roleEditor(role) {
  const sample = {
    people: {
      actions: ["create", "read", "update"],
      scope: "own",
      fields: { "*": ["read", "write"] },
    },
  };
  modal(
    role ? "Edit role" : "Create role",
    `<form>${field("name", "Role name", "text", role?.name)}${textArea("grants", "Module permissions (JSON)", role?.grants || sample, true)}<p class="help">Use a module identifier or *. Actions: create, read, update, delete, export, import, share, attach, configure, administer. Scope: own or all. Field grants: read and write. Platform configuration is reserved for administrators.</p>${actions()}</form>`,
    (root) =>
      bindForm(root, async (f, d) => {
        await api(role ? "/roles/" + role.id : "/roles", {
          method: role ? "PATCH" : "POST",
          body: { name: d.name, grants: parse(d.grants) },
        });
        closeModal();
        users();
        toast("Role saved");
      }),
  );
}
async function integrations() {
  const [res, jobs] = await Promise.all([
    api("/integrations"),
    api("/deliveries"),
  ]);
  $("#content").innerHTML =
    heading(
      "Integrations & automation",
      "Connect services and deliver record events.",
      '<button class="primary" id="new-integration">＋ Add integration</button>',
    ) +
    `<div class="progress-note">n8n and webhooks support signed delivery. Telegram supports outbound alerts. Google Sheets appends events using a supplied access token. Tableau uses CSV exports. OAuth consent and Telegram commands are not yet implemented.</div>` +
    table(
      ["Name", "Provider", "Status", "Credentials", ""],
      res.data.map(
        (i) =>
          `<tr><td>${esc(i.name)}</td><td>${esc(i.kind)}</td><td>${i.enabled ? "Enabled" : "Disabled"}</td><td>${i.credentials_configured ? "Configured" : "Missing"}</td><td><button data-integration="${i.id}">Edit</button> <button data-test="${i.id}">Test</button></td></tr>`,
      ),
    ) +
    `<h2>Delivery queue</h2>` +
    table(
      ["Delivery", "Status", "Attempts", "Last error", ""],
      jobs.data.map(
        (j) =>
          `<tr><td>${esc(j.id.slice(0, 8))}</td><td>${esc(j.status)}</td><td>${j.attempts}</td><td>${esc(j.last_error || "—")}</td><td>${["pending", "failed"].includes(j.status) ? `<button data-retry="${j.id}">Retry</button>` : ""}</td></tr>`,
      ),
    );
  $("#new-integration").onclick = () => integrationEditor();
  $$("[data-integration]").forEach(
    (b) =>
      (b.onclick = () =>
        integrationEditor(
          res.data.find((i) => i.id === b.dataset.integration),
        )),
  );
  $$("[data-retry]").forEach(
    (b) =>
      (b.onclick = async () => {
        try {
          await api("/deliveries/" + b.dataset.retry + "/retry", {
            method: "POST",
          });
          integrations();
        } catch (e) {
          toast(e.message);
        }
      }),
  );
  $$("[data-test]").forEach(
    (b) =>
      (b.onclick = () =>
        modal(
          "Send a connection test",
          `<p>This sends a real test message to the configured provider. SMTP requires a recipient.</p><form>${field("to", "Test email recipient", "email")}${actions("Send test")}</form>`,
          (root) =>
            bindForm(root, async (f, d) => {
              await api("/integrations/" + b.dataset.test + "/test", {
                method: "POST",
                body: d,
              });
              closeModal();
              integrations();
              toast("Test queued");
            }),
        )),
  );
}
function integrationEditor(i) {
  modal(
    i ? "Edit integration" : "Add integration",
    `<form>${field("name", "Name", "text", i?.name)}${select("kind", "Provider", ["n8n", "webhook", "rest", "telegram", "smtp", "google_sheets", "tableau", "supabase", "mongodb", "oauth"], i?.kind || "n8n")}${check("enabled", "Enabled", i?.enabled)}${textArea("settings", "Public configuration (JSON)", i?.settings || { url: "https://your-n8n-host.example/webhook/lifeos", events: ["record.created", "record.updated"], module_ids: [] }, true)}${textArea("secrets", "Credentials (JSON; blank keeps existing credentials)", "", true)}<p class="help">n8n: webhook_secret, optional token. Telegram: bot_token; settings chat_id. SMTP: password; settings host, port, tls, username, sender, reply_to. Allowed hosts must be configured in the deployment environment.</p><details><summary>Module identifiers for event subscriptions</summary><pre>${esc(state.modules.map((m) => m.label + ": " + m.id).join("\n"))}</pre></details>${actions()}</form>`,
    (root) => {
      if (i) root.querySelector("[name=kind]").disabled = true;
      bindForm(root, async (f, d) => {
        const payload = {
          name: d.name,
          kind: i?.kind || d.kind,
          enabled: f.elements.enabled.checked,
          settings: parse(d.settings),
        };
        if (d.secrets.trim()) payload.secrets = parse(d.secrets);
        await api(i ? "/integrations/" + i.id : "/integrations", {
          method: i ? "PATCH" : "POST",
          body: payload,
        });
        closeModal();
        integrations();
        toast("Integration saved");
      });
    },
  );
}
async function reports() {
  const res = await api("/reports");
  $("#content").innerHTML =
    heading(
      "Reports & charts",
      "Group and aggregate the records you can access.",
      '<button class="primary" id="new-report">＋ Create report</button>',
    ) +
    `<div class="grid">${res.data.map((r) => `<section class="panel"><h2>${esc(r.name)}</h2><p>${esc(r.settings.aggregate || "count")} · ${esc(r.settings.group_by || "All records")}</p><div class="toolbar"><button data-run="${r.id}" class="primary">Run report</button><button data-edit-report="${r.id}">Edit</button><button data-delete-report="${r.id}" class="danger">Delete</button></div></section>`).join("") || '<div class="empty"><h2>Start with a question</h2><p>Create a report to compare totals or see how records are grouped.</p></div>'}</div><div id="report-result"></div>`;
  $("#new-report").onclick = () => reportEditor();
  $$("[data-edit-report]").forEach(
    (b) =>
      (b.onclick = () =>
        reportEditor(res.data.find((r) => r.id === b.dataset.editReport))),
  );
  $$("[data-delete-report]").forEach(
    (b) =>
      (b.onclick = () =>
        confirmAction("Delete report?", async () => {
          await api("/reports/" + b.dataset.deleteReport, { method: "DELETE" });
          reports();
        })),
  );
  $$("[data-run]").forEach(
    (b) =>
      (b.onclick = async () => {
        try {
          const result = await api("/reports/" + b.dataset.run + "/run");
          const report = res.data.find((r) => r.id === b.dataset.run);
          const values = result.data.map((r) => Number(r.value));
          const max = Math.max(1, ...values),
            min = Math.min(0, ...values);
          $("#report-result").innerHTML =
            `<section class="panel"><h2>${esc(report.name)}</h2><div class="bar-chart">${result.data.map((r) => `<div class="bar-row"><span>${esc(r.group)}</span><meter min="${min}" max="${max}" value="${Number(r.value)}">${esc(r.value)}</meter><strong>${esc(r.value)}</strong></div>`).join("") || "<p>No matching records.</p>"}</div></section>` +
            table(
              ["Group", "Value", "Record count"],
              result.data.map(
                (r) =>
                  `<tr><td>${esc(r.group)}</td><td>${esc(r.value)}</td><td>${r.count}</td></tr>`,
              ),
            );
        } catch (e) {
          toast(e.message);
        }
      }),
  );
}
function reportEditor(r) {
  modal(
    r ? "Edit report" : "Create report",
    `<form>${field("name", "Report name", "text", r?.name)}${select(
      "module_id",
      "Module",
      state.modules.map((m) => [m.id, m.label]),
      r?.module_id || state.modules[0].id,
    )}<div id="report-fields"></div>${select("aggregate", "Aggregate", ["count", "sum", "avg", "min", "max"], r?.settings.aggregate || "count")}${textArea("filters", "Filters (JSON)", r?.settings.filters || [], true)}${actions()}</form>`,
    (root) => {
      async function load() {
        const id = root.querySelector("[name=module_id]").value;
        const m = state.modules.find((m) => m.id === id);
        const s = (await api(`/modules/${m.name}/schema`)).data;
        const fs = s.fields.filter(
          (f) => !["secret", "json", "formula"].includes(f.kind),
        );
        $("#report-fields", root).innerHTML =
          select(
            "group_by",
            "Group by",
            [["", "All records"], ...fs.map((f) => [f.name, f.label])],
            r?.settings.group_by || "",
          ) +
          select(
            "value_field",
            "Numeric field",
            [
              ["", "Count only"],
              ...fs
                .filter((f) =>
                  ["currency", "number", "decimal"].includes(f.kind),
                )
                .map((f) => [f.name, f.label]),
            ],
            r?.settings.value_field || "",
          );
      }
      root.querySelector("[name=module_id]").onchange = load;
      load();
      bindForm(root, async (f, d) => {
        await api(r ? "/reports/" + r.id : "/reports", {
          method: r ? "PATCH" : "POST",
          body: {
            name: d.name,
            module_id: d.module_id,
            settings: {
              aggregate: d.aggregate,
              group_by: d.group_by || null,
              value_field: d.value_field || null,
              filters: parse(d.filters, []),
              chart: "bar",
            },
          },
        });
        closeModal();
        reports();
        toast("Report saved");
      });
    },
  );
}
async function auditPage(page = 1) {
  const res = await api("/audit-logs?page=" + page);
  $("#content").innerHTML =
    heading(
      "Audit trail",
      "A history of changes, without sensitive field values.",
    ) +
    table(
      ["Time", "Action", "Entity", "Actor"],
      res.data.map(
        (a) =>
          `<tr><td>${esc(new Date(a.created_at + "Z").toLocaleString())}</td><td>${esc(a.action)}</td><td>${esc(a.entity_id || "—")}</td><td>${esc(a.actor_id || "System")}</td></tr>`,
      ),
    ) +
    `<div class="pagination"><span>${res.meta.total} events</span><button id="audit-prev" ${page === 1 ? "disabled" : ""}>Previous</button><button id="audit-next" ${page * 25 >= res.meta.total ? "disabled" : ""}>Next</button></div>`;
  $("#audit-prev").onclick = () => auditPage(page - 1);
  $("#audit-next").onclick = () => auditPage(page + 1);
}
async function settings() {
  const { data } = await api("/settings");
  $("#content").innerHTML =
    heading(
      "Settings & health",
      "Workspace preferences and deployment information.",
    ) +
    `<div class="split"><section class="panel"><h2>Workspace preferences</h2><form>${field("application_name", "Application name", "text", data.settings.application_name || "Life OS")}${field("timezone", "Timezone", "text", data.settings.timezone || "Asia/Kolkata")}${field("currency", "Default currency", "text", data.settings.currency || "INR")}${field("date_format", "Date format", "text", data.settings.date_format || "DD/MM/YYYY")}<div class="error"></div><button type="submit" class="primary">Save settings</button></form></section><section class="panel"><h2>Deployment</h2><dl class="detail-values">${Object.entries(
      data,
    )
      .filter(([k]) => k !== "settings")
      .map(
        ([k, v]) =>
          `<div><dt>${esc(k.replaceAll("_", " "))}</dt><dd>${esc(v)}</dd></div>`,
      )
      .join(
        "",
      )}</dl><button id="health-check">Check application health</button><p id="health-result"></p><p class="help">Database connections, encryption keys, HTTPS and scanner settings are managed through deployment configuration. Changes require a restart.</p></section></div>`;
  bindForm($("#content"), async (f, d) => {
    await api("/settings", { method: "PUT", body: d });
    toast("Settings saved");
  });
  $("#health-check").onclick = async () => {
    try {
      const r = await fetch("/health/ready");
      $("#health-result").textContent = r.ok
        ? "Application dependencies are ready."
        : "One or more dependencies are unavailable.";
    } catch {
      $("#health-result").textContent = "Could not reach the application.";
    }
  };
}
async function security() {
  const [me, sessions] = await Promise.all([
    api("/auth/me"),
    api("/auth/sessions"),
  ]);
  state.user = me.data.user;
  $("#content").innerHTML =
    heading(
      "Security & sessions",
      "Protect access to your personal information.",
    ) +
    `<div class="grid"><section class="panel"><h2>Two-step verification</h2><span class="badge">${state.user.mfa_enabled ? "Enabled" : "Not enabled"}</span><p>Use an authenticator app and keep recovery codes in a safe place.</p><button id="mfa-action" class="primary">${state.user.mfa_enabled ? "Disable 2FA" : "Set up 2FA"}</button></section><section class="panel"><h2>Password</h2><p>Changing your password signs out other sessions.</p><button id="change-password">Change password</button></section><section class="panel"><h2>API access</h2><p>Create an expiring bearer token for trusted integrations.</p><button id="create-token">Create token</button></section></div><h2>Active sessions</h2>` +
    table(
      ["Created", "Expires", ""],
      sessions.data.map(
        (s) =>
          `<tr><td>${esc(s.created_at)}</td><td>${esc(s.expires_at)}</td><td>${s.current ? "This session" : `<button data-session="${s.id}">Revoke</button>`}</td></tr>`,
      ),
    );
  $$("[data-session]").forEach(
    (b) =>
      (b.onclick = async () => {
        await api("/auth/sessions/" + b.dataset.session, { method: "DELETE" });
        security();
      }),
  );
  $("#change-password").onclick = () =>
    modal(
      "Change password",
      `<form>${field("current_password", "Current password", "password")}${field("password", "New password", "password")}${field("code", "2FA or recovery code")}${actions("Change password")}</form>`,
      (root) =>
        bindForm(root, async (f, d) => {
          await api("/auth/password", { method: "POST", body: d });
          closeModal();
          toast("Password changed");
        }),
    );
  $("#create-token").onclick = () =>
    modal(
      "Create API token",
      `<form>${field("password", "Current password", "password")}${field("code", "2FA or recovery code")}${actions("Create token")}</form>`,
      (root) =>
        bindForm(root, async (f, d) => {
          const { data } = await api("/auth/tokens", {
            method: "POST",
            body: d,
          });
          closeModal();
          modal(
            "Save your API token",
            `<p>This is the only time the token is displayed. It expires at ${esc(data.expires_at)}.</p><pre>${esc(data.token)}</pre>`,
          );
        }),
    );
  $("#mfa-action").onclick = () => {
    if (state.user.mfa_enabled) {
      modal(
        "Disable two-step verification",
        `<form>${field("password", "Current password", "password")}${field("code", "Authenticator or recovery code")}${actions("Disable 2FA")}</form>`,
        (root) =>
          bindForm(root, async (f, d) => {
            await api("/auth/mfa", { method: "DELETE", body: d });
            closeModal();
            security();
          }),
      );
      return;
    }
    modal(
      "Set up two-step verification",
      `<form>${field("password", "Current password", "password")}${actions("Continue")}</form>`,
      (root) =>
        bindForm(root, async (f, d) => {
          const { data } = await api("/auth/mfa/setup", {
            method: "POST",
            body: d,
          });
          closeModal();
          modal(
            "Add Life OS to your authenticator",
            `<p>Enter this secret in your authenticator app, then confirm a code.</p><pre>${esc(data.secret)}</pre><form>${field("code", "Six-digit code")}${actions("Enable 2FA")}</form>`,
            (root) =>
              bindForm(root, async (f, d) => {
                const { data } = await api("/auth/mfa/confirm", {
                  method: "POST",
                  body: d,
                });
                closeModal();
                security();
                modal(
                  "Save your recovery codes",
                  `<p>Each code can be used once. Store these separately from Life OS.</p><pre>${esc(data.recovery_codes.join("\n"))}</pre>`,
                );
              }),
          );
        }),
    );
  };
}
bootstrap();
