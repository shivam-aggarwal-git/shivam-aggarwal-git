import os, logging, secrets
from pathlib import Path
from flask import Flask, request, jsonify, g, render_template
from flask_migrate import Migrate
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from sqlalchemy import event, text
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy.orm.exc import StaleDataError
from werkzeug.exceptions import HTTPException
from werkzeug.middleware.proxy_fix import ProxyFix
from dotenv import load_dotenv
from .models import db, Audit, Setting, now
from .common import ApiError, fail, ok, body, audit, paged
from .security import load_identity, admin_required, login_required


def env(name, default=None):
    path = os.getenv(name + "_FILE")
    return Path(path).read_text().strip() if path else os.getenv(name, default)


def create_app(test_config=None):
    load_dotenv()
    app = Flask(__name__)
    app.config.update(
        ENVIRONMENT=env("LIFEOS_ENV", "development"),
        SECRET_KEY=env("SECRET_KEY"),
        ENCRYPTION_KEYS=env("ENCRYPTION_KEYS"),
        SETUP_TOKEN=env("SETUP_TOKEN"),
        SQLALCHEMY_DATABASE_URI=env("DATABASE_URL", "sqlite:///lifeos.db"),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        MONGO_URI=env("MONGO_URI"),
        RATELIMIT_STORAGE_URI=env("REDIS_URL", "memory://"),
        RATELIMIT_HEADERS_ENABLED=True,
        COOKIE_SECURE=env("COOKIE_SECURE", "false").lower() == "true",
        SESSION_HOURS=int(env("SESSION_HOURS", "8")),
        MAX_CONTENT_LENGTH=12 * 1024 * 1024,
        FILE_LIMIT=10 * 1024 * 1024,
        UPLOAD_DIR=env("UPLOAD_DIR", str(Path(app.instance_path) / "uploads")),
        CLAMAV_HOST=env("CLAMAV_HOST"),
        INTEGRATION_ALLOWED_HOSTS=set(
            env("INTEGRATION_ALLOWED_HOSTS", "").lower().split(",")
        ),
        TRUSTED_HOSTS=env("TRUSTED_HOSTS", "localhost,127.0.0.1").split(","),
    )
    if test_config:
        app.config.update(test_config)
    if (
        not app.config["SECRET_KEY"]
        or len(app.config["SECRET_KEY"]) < 32
        or not app.config["ENCRYPTION_KEYS"]
    ):
        raise RuntimeError(
            "Provide SECRET_KEY (32+ characters) and ENCRYPTION_KEYS via environment or *_FILE"
        )
    from cryptography.fernet import Fernet

    for key in app.config["ENCRYPTION_KEYS"].split(","):
        Fernet(key.encode())
    if app.config["ENVIRONMENT"] == "production":
        if (
            not app.config["COOKIE_SECURE"]
            or app.config["SQLALCHEMY_DATABASE_URI"].startswith("sqlite")
            or not app.config["RATELIMIT_STORAGE_URI"].startswith("redis")
            or not app.config["CLAMAV_HOST"]
        ):
            raise RuntimeError(
                "Production requires secure cookies, PostgreSQL, Redis and ClamAV"
            )
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    Path(app.config["UPLOAD_DIR"]).mkdir(parents=True, exist_ok=True)
    db.init_app(app)
    Migrate(app, db)
    with app.app_context():
        if db.engine.dialect.name == "sqlite":

            @event.listens_for(db.engine, "connect")
            def foreign_keys(connection, _):
                connection.execute("PRAGMA foreign_keys=ON")

    if app.config["MONGO_URI"]:
        from pymongo import MongoClient

        app.extensions["mongo"] = MongoClient(
            app.config["MONGO_URI"],
            serverSelectionTimeoutMS=3000,
            connectTimeoutMS=3000,
        )
    if env("TRUST_PROXY", "false") == "true":
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=0)
    limiter = Limiter(
        get_remote_address,
        app=app,
        default_limits=["300 per minute"],
        storage_uri=app.config["RATELIMIT_STORAGE_URI"],
    )
    from . import auth, metadata, records, integrations, files, reporting

    for blueprint in (
        auth.bp,
        metadata.bp,
        records.bp,
        integrations.bp,
        files.bp,
        reporting.bp,
    ):
        app.register_blueprint(blueprint)
    app.extensions["lifeos_limiter"] = limiter
    for endpoint in (
        "auth.login",
        "auth.setup",
        "auth.forgot_password",
        "auth.reset_password",
        "auth.mfa_confirm",
    ):
        app.view_functions[endpoint] = limiter.limit("10 per minute; 100 per day")(
            app.view_functions[endpoint]
        )

    @app.before_request
    def before():
        g.request_id = secrets.token_hex(8)
        if request.path.startswith("/api/v1"):
            load_identity()

    @app.after_request
    def after(response):
        response.headers.update(
            {
                "X-Content-Type-Options": "nosniff",
                "X-Frame-Options": "DENY",
                "Referrer-Policy": "no-referrer",
                "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
                "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
                "X-Request-ID": getattr(g, "request_id", ""),
            }
        )
        if request.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        if app.config["COOKIE_SECURE"]:
            response.headers["Strict-Transport-Security"] = "max-age=31536000"
        # Route templates avoid logging user values, query strings and callback secrets.
        app.logger.info(
            "request id=%s method=%s route=%s status=%s",
            getattr(g, "request_id", ""),
            request.method,
            request.url_rule.rule if request.url_rule else "unmatched",
            response.status_code,
        )
        return response

    @app.errorhandler(ApiError)
    def api_error(e):
        db.session.rollback()
        return jsonify(error={"code": e.code, "message": e.message}), e.status

    @app.errorhandler(ValueError)
    @app.errorhandler(TypeError)
    def invalid_type(e):
        db.session.rollback()
        return (
            jsonify(
                error={
                    "code": "invalid_request",
                    "message": "A value has an invalid type or format.",
                }
            ),
            400,
        )

    @app.errorhandler(IntegrityError)
    def integrity(e):
        db.session.rollback()
        return (
            jsonify(
                error={
                    "code": "constraint_conflict",
                    "message": "A unique value, reference or relationship constraint was violated.",
                }
            ),
            409,
        )

    @app.errorhandler(StaleDataError)
    def stale(e):
        db.session.rollback()
        return (
            jsonify(
                error={
                    "code": "version_conflict",
                    "message": "This record changed. Reload before saving.",
                }
            ),
            409,
        )

    @app.errorhandler(HTTPException)
    def http_error(e):
        db.session.rollback()
        return (
            jsonify(
                error={
                    "code": e.name.lower().replace(" ", "_"),
                    "message": e.description,
                }
            ),
            e.code,
        )

    @app.errorhandler(Exception)
    def unexpected(e):
        if app.testing:
            raise e
        db.session.rollback()
        app.logger.error(
            "request_failed id=%s type=%s",
            getattr(g, "request_id", ""),
            type(e).__name__,
        )
        return (
            jsonify(
                error={
                    "code": "internal_error",
                    "message": "The request could not be completed. Reference: "
                    + getattr(g, "request_id", ""),
                }
            ),
            500,
        )

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/health/live")
    def live():
        return jsonify(status="ok")

    @app.get("/health/ready")
    def ready():
        try:
            db.session.execute(text("SELECT 1"))
            if app.config["MONGO_URI"]:
                app.extensions["mongo"].admin.command("ping")
            if app.config["RATELIMIT_STORAGE_URI"].startswith("redis"):
                import redis

                redis.Redis.from_url(app.config["RATELIMIT_STORAGE_URI"]).ping()
            return jsonify(status="ready")
        except Exception:
            return jsonify(status="unavailable"), 503

    @app.get("/api/v1/audit-logs")
    @admin_required
    def audit_logs():
        return paged(
            Audit.query.order_by(Audit.created_at.desc()),
            lambda a: {
                "id": a.id,
                "actor_id": a.actor_id,
                "action": a.action,
                "entity_id": a.entity_id,
                "details": a.details,
                "created_at": a.created_at.isoformat(),
            },
        )

    @app.get("/api/v1/settings")
    @admin_required
    def settings():
        return ok(
            {
                "settings": {x.key: x.value for x in Setting.query.all()},
                "environment": app.config["ENVIRONMENT"],
                "database": db.engine.dialect.name,
                "mongodb_configured": bool(app.config["MONGO_URI"]),
                "file_limit": app.config["FILE_LIMIT"],
                "scanner_configured": bool(app.config["CLAMAV_HOST"]),
                "https_cookies": app.config["COOKIE_SECURE"],
            }
        )

    @app.put("/api/v1/settings")
    @admin_required
    def set_settings():
        d = body()
        if set(d) - {
            "application_name",
            "timezone",
            "currency",
            "date_format",
            "dashboard_report_ids",
        }:
            fail(
                "Setting is not UI-editable; database, encryption and transport settings require deployment configuration"
            )
        for key, value in d.items():
            s = Setting.query.filter_by(key=key).first()
            if not s:
                s = Setting(key=key, value=value)
                db.session.add(s)
            else:
                s.value = value
        audit("settings.updated")
        db.session.commit()
        return ok(d)

    from .openapi import install_openapi

    install_openapi(app)

    @app.cli.command("seed")
    def seed_command():
        from .seed import seed

        seed()

    return app
