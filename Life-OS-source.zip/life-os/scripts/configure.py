"""One-time local setup. No credentials are printed or shipped."""

import secrets
from pathlib import Path
import base64, os

root = Path(__file__).resolve().parents[1]
target = root / ".env"
if target.exists():
    raise SystemExit(
        ".env already exists; refusing to overwrite keys or database credentials."
    )
values = {
    "LIFEOS_ENV": "development",
    "SECRET_KEY": secrets.token_urlsafe(48),
    "ENCRYPTION_KEYS": base64.urlsafe_b64encode(os.urandom(32)).decode(),
    "SETUP_TOKEN": secrets.token_urlsafe(32),
    "POSTGRES_PASSWORD": secrets.token_urlsafe(32),
    "MONGO_PASSWORD": secrets.token_urlsafe(32),
    "COOKIE_SECURE": "false",
    "TRUSTED_HOSTS": "localhost,127.0.0.1",
    "INTEGRATION_ALLOWED_HOSTS": "api.telegram.org,sheets.googleapis.com",
    "PORT": "8000",
}
target.write_text("\n".join(f"{k}={v}" for k, v in values.items()) + "\n")
target.chmod(0o600)
print(
    "Created .env. Keep this file private. Read SETUP_TOKEN from it when creating your administrator account."
)
